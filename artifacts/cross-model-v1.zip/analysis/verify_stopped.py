import json,sys
from pathlib import Path
from retrybench.evaluation import score_predictions
from verify_cross_model_pilot import resolve_attachments
root=Path(sys.argv[1]);summary=json.loads((root/'run/summary.json').read_text())
assert summary['status']=='stopped' and summary['stop_reason']=='invalid normalized decision'
for provider in ('openai','anthropic'):
 base=root/'run'/provider;path=base/'predictions.jsonl'
 rows=[json.loads(s) for s in path.read_text().splitlines()] if path.exists() else []
 saved=json.loads((base/'report.json').read_text());new=score_predictions(rows,model=saved['model'],settings=saved['settings'])
 for key in ('suite_sha256','prediction_sha256','metrics','per_condition','per_task','per_block','usage','raw_capture'):assert new.report[key]==saved[key],key
 assert new.cases==[json.loads(s) for s in (base/'case-scores.jsonl').read_text().splitlines()]
 if provider=='openai':
  assert len(rows)==1 and saved['metrics']['status_counts']=={'invalid':1,'missing':239}
  response=resolve_attachments(rows[0]['raw_calls'][0]['response'],rows[0]['transcript_attachments'])
  call=next(x for x in response['output'] if x['type']=='function_call')
  assert json.loads(call['arguments'])=={'action':rows[0]['action'],'idempotency_key':rows[0]['arguments']['idempotency_key']}
 else:assert len(rows)==0
print('Original stopped attempt preserved and independently rescored.')
