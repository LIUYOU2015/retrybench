# RetryBench cross-model evidence v1

Run `python3 verify.py` from a fresh extraction. Python 3.9+ and its standard library are sufficient; no API keys, provider packages or paid calls are needed.

The full collection contains 240 fresh responses per model (GPT-5.4 mini snapshot / Claude Sonnet 4.6), using the explicit v2 null-only-unkeyed interface. See comparison.md for exact results and limitations. This is a public reused suite, not a held-out or general-ranking claim.

full/, pilot-v2/ and pilot-v1/ preserve original plans, raw responses, outputs and collection-source snapshots. pilot-v1/ is the stopped first attempt, not discarded evidence. analysis/ audits native arguments/usage, score replay and the full collection's rolling budget. Original absolute paths remain in frozen provenance; the verifier uses bundled copies and does not require those paths.

Frozen source snapshots reflect collection-time code; the public package may have later maintenance changes. Dependency locks describe collection, not requirements for offline verification. FILE-HASHES.json covers every distributed file except itself. The existing PolyForm Noncommercial license applies.
