"""Verify every distributed byte, then rescore without model calls."""
import hashlib,json,os,subprocess,sys,tempfile
from pathlib import Path
root=Path(__file__).resolve().parent
expected=json.loads((root/'FILE-HASHES.json').read_text())
actual={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file() and p.name!='FILE-HASHES.json' and '__pycache__' not in p.parts and p.suffix!='.pyc'}
if actual!=set(expected):raise SystemExit('Archive file inventory mismatch')
for name,digest in expected.items():
 if hashlib.sha256((root/name).read_bytes()).hexdigest()!=digest:raise SystemExit('Hash mismatch: '+name)
full=json.loads((root/'full/plan.json').read_text())
for entry in full['prior_run_evidence']:
 path=root/'prior-summaries'/(entry['sha256']+'.json')
 if hashlib.sha256(path.read_bytes()).hexdigest()!=entry['sha256']:raise SystemExit('Prior accounting mismatch')
with tempfile.TemporaryDirectory(prefix='retrybench-replay-') as temporary:
 for name in ('pilot-v2','full'):
  env=dict(os.environ,PYTHONPATH=str(root/name/'source'),PYTHONDONTWRITEBYTECODE='1')
  subprocess.run([sys.executable,str(root/'analysis/verify_cross_model_pilot.py'),str(root/name),'--output',str(Path(temporary)/(name+'.json'))],env=env,check=True,cwd=root)
 env=dict(os.environ,PYTHONPATH=str(root/'pilot-v1/source'),PYTHONDONTWRITEBYTECODE='1')
 subprocess.run([sys.executable,str(root/'analysis/verify_stopped.py'),str(root/'pilot-v1')],env=env,check=True,cwd=root)
print('Verified file integrity, full/pilot rescoring, raw arguments/usage and budget accounting. No inference ran.')
