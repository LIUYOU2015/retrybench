# Two-model report tables

Counts below are observed unless explicitly marked planned. Bounds retain planned denominators and are not confidence intervals.

| Model | Prompt package | Weak responses | Weak forbidden retries/outcomes | Authoritative responses | Authoritative forbidden retries/outcomes | Correct terminal retries/observed |
|---|---|---:|---:|---:|---:|---:|
| gpt-5.6-sol | label_only | 32/32 | 0/64 | 96/96 | 0/64 | 32/32 |
| gpt-5.6-sol | explicit_contract | 32/32 | 0/64 | 96/96 | 0/64 | 32/32 |
| gpt-5.6-sol | explicit_contract_cautious | 32/32 | 0/64 | 96/96 | 0/64 | 32/32 |
| gpt-6-astra | label_only | 32/32 | 0/64 | 96/96 | 0/64 | 32/32 |
| gpt-6-astra | explicit_contract | 32/32 | 0/64 | 95/96 | 0/63 | 32/32 |
| gpt-6-astra | explicit_contract_cautious | 32/32 | 0/64 | 96/96 | 0/64 | 32/32 |

| Model/package/interface | Outcomes | FRP | Duplicates | Omissions | Unresolved | Correct ledger | Resolved exact state |
|---|---:|---:|---:|---:|---:|---:|---:|
| gpt-5.6-sol/explicit_contract/authoritative | 96 | 0 | 0 | 0 | 32 | 96 | 64 |
| gpt-5.6-sol/explicit_contract/weak | 96 | 0 | 0 | 32 | 96 | 64 | 0 |
| gpt-5.6-sol/explicit_contract_cautious/authoritative | 96 | 0 | 0 | 0 | 32 | 96 | 64 |
| gpt-5.6-sol/explicit_contract_cautious/weak | 96 | 0 | 0 | 32 | 96 | 64 | 0 |
| gpt-5.6-sol/label_only/authoritative | 96 | 0 | 0 | 0 | 32 | 96 | 64 |
| gpt-5.6-sol/label_only/weak | 96 | 0 | 0 | 32 | 96 | 64 | 0 |
| gpt-6-astra/explicit_contract/authoritative | 95 | 0 | 0 | 0 | 31 | 95 | 64 |
| gpt-6-astra/explicit_contract/weak | 96 | 0 | 0 | 32 | 96 | 64 | 0 |
| gpt-6-astra/explicit_contract_cautious/authoritative | 96 | 0 | 0 | 0 | 32 | 96 | 64 |
| gpt-6-astra/explicit_contract_cautious/weak | 96 | 0 | 0 | 32 | 96 | 64 | 0 |
| gpt-6-astra/label_only/authoritative | 96 | 0 | 0 | 0 | 32 | 96 | 64 |
| gpt-6-astra/label_only/weak | 96 | 0 | 0 | 32 | 96 | 64 | 0 |

| Contrast | Estimand | Fixed-denominator effect bounds |
|---|---|---:|
| gpt-5.6-sol/explicit_contract/schedule_weighted/weak_minus_authoritative | full_schedule_weighted_frp_difference | [0.000000, 0.000000] |
| gpt-5.6-sol/explicit_contract/weak_minus_authoritative | common_forbidden_retry_difference | [0.000000, 0.000000] |
| gpt-5.6-sol/explicit_contract_cautious/schedule_weighted/weak_minus_authoritative | full_schedule_weighted_frp_difference | [0.000000, 0.000000] |
| gpt-5.6-sol/explicit_contract_cautious/weak_minus_authoritative | common_forbidden_retry_difference | [0.000000, 0.000000] |
| gpt-5.6-sol/explicit_contract_cautious_minus_label_only/weak | common_forbidden_retry_difference | [0.000000, 0.000000] |
| gpt-5.6-sol/explicit_contract_minus_label_only/weak | common_forbidden_retry_difference | [0.000000, 0.000000] |
| gpt-5.6-sol/label_only/schedule_weighted/weak_minus_authoritative | full_schedule_weighted_frp_difference | [0.000000, 0.000000] |
| gpt-5.6-sol/label_only/weak_minus_authoritative | common_forbidden_retry_difference | [0.000000, 0.000000] |
| gpt-6-astra/explicit_contract/schedule_weighted/weak_minus_authoritative | full_schedule_weighted_frp_difference | [-0.010417, 0.000000] |
| gpt-6-astra/explicit_contract/weak_minus_authoritative | common_forbidden_retry_difference | [-0.015625, 0.000000] |
| gpt-6-astra/explicit_contract_cautious/schedule_weighted/weak_minus_authoritative | full_schedule_weighted_frp_difference | [0.000000, 0.000000] |
| gpt-6-astra/explicit_contract_cautious/weak_minus_authoritative | common_forbidden_retry_difference | [0.000000, 0.000000] |
| gpt-6-astra/explicit_contract_cautious_minus_label_only/weak | common_forbidden_retry_difference | [0.000000, 0.000000] |
| gpt-6-astra/explicit_contract_minus_label_only/weak | common_forbidden_retry_difference | [0.000000, 0.000000] |
| gpt-6-astra/label_only/schedule_weighted/weak_minus_authoritative | full_schedule_weighted_frp_difference | [0.000000, 0.000000] |
| gpt-6-astra/label_only/weak_minus_authoritative | common_forbidden_retry_difference | [0.000000, 0.000000] |

## All family effect bounds

### gpt-5.6-sol/explicit_contract/schedule_weighted/weak_minus_authoritative

| Family | Difference bounds |
|---|---:|
| artifact | [0.000000, 0.000000] |
| change-record | [0.000000, 0.000000] |
| deployment | [0.000000, 0.000000] |
| maintenance-job | [0.000000, 0.000000] |
| package-version | [0.000000, 0.000000] |
| review-request | [0.000000, 0.000000] |
| security-finding | [0.000000, 0.000000] |
| webhook-event | [0.000000, 0.000000] |

### gpt-5.6-sol/explicit_contract/weak_minus_authoritative

| Family | Difference bounds |
|---|---:|
| artifact | [0.000000, 0.000000] |
| change-record | [0.000000, 0.000000] |
| deployment | [0.000000, 0.000000] |
| maintenance-job | [0.000000, 0.000000] |
| package-version | [0.000000, 0.000000] |
| review-request | [0.000000, 0.000000] |
| security-finding | [0.000000, 0.000000] |
| webhook-event | [0.000000, 0.000000] |

### gpt-5.6-sol/explicit_contract_cautious/schedule_weighted/weak_minus_authoritative

| Family | Difference bounds |
|---|---:|
| artifact | [0.000000, 0.000000] |
| change-record | [0.000000, 0.000000] |
| deployment | [0.000000, 0.000000] |
| maintenance-job | [0.000000, 0.000000] |
| package-version | [0.000000, 0.000000] |
| review-request | [0.000000, 0.000000] |
| security-finding | [0.000000, 0.000000] |
| webhook-event | [0.000000, 0.000000] |

### gpt-5.6-sol/explicit_contract_cautious/weak_minus_authoritative

| Family | Difference bounds |
|---|---:|
| artifact | [0.000000, 0.000000] |
| change-record | [0.000000, 0.000000] |
| deployment | [0.000000, 0.000000] |
| maintenance-job | [0.000000, 0.000000] |
| package-version | [0.000000, 0.000000] |
| review-request | [0.000000, 0.000000] |
| security-finding | [0.000000, 0.000000] |
| webhook-event | [0.000000, 0.000000] |

### gpt-5.6-sol/explicit_contract_cautious_minus_label_only/weak

| Family | Difference bounds |
|---|---:|
| artifact | [0.000000, 0.000000] |
| change-record | [0.000000, 0.000000] |
| deployment | [0.000000, 0.000000] |
| maintenance-job | [0.000000, 0.000000] |
| package-version | [0.000000, 0.000000] |
| review-request | [0.000000, 0.000000] |
| security-finding | [0.000000, 0.000000] |
| webhook-event | [0.000000, 0.000000] |

### gpt-5.6-sol/explicit_contract_minus_label_only/weak

| Family | Difference bounds |
|---|---:|
| artifact | [0.000000, 0.000000] |
| change-record | [0.000000, 0.000000] |
| deployment | [0.000000, 0.000000] |
| maintenance-job | [0.000000, 0.000000] |
| package-version | [0.000000, 0.000000] |
| review-request | [0.000000, 0.000000] |
| security-finding | [0.000000, 0.000000] |
| webhook-event | [0.000000, 0.000000] |

### gpt-5.6-sol/label_only/schedule_weighted/weak_minus_authoritative

| Family | Difference bounds |
|---|---:|
| artifact | [0.000000, 0.000000] |
| change-record | [0.000000, 0.000000] |
| deployment | [0.000000, 0.000000] |
| maintenance-job | [0.000000, 0.000000] |
| package-version | [0.000000, 0.000000] |
| review-request | [0.000000, 0.000000] |
| security-finding | [0.000000, 0.000000] |
| webhook-event | [0.000000, 0.000000] |

### gpt-5.6-sol/label_only/weak_minus_authoritative

| Family | Difference bounds |
|---|---:|
| artifact | [0.000000, 0.000000] |
| change-record | [0.000000, 0.000000] |
| deployment | [0.000000, 0.000000] |
| maintenance-job | [0.000000, 0.000000] |
| package-version | [0.000000, 0.000000] |
| review-request | [0.000000, 0.000000] |
| security-finding | [0.000000, 0.000000] |
| webhook-event | [0.000000, 0.000000] |

### gpt-6-astra/explicit_contract/schedule_weighted/weak_minus_authoritative

| Family | Difference bounds |
|---|---:|
| artifact | [0.000000, 0.000000] |
| change-record | [0.000000, 0.000000] |
| deployment | [0.000000, 0.000000] |
| maintenance-job | [-0.083333, 0.000000] |
| package-version | [0.000000, 0.000000] |
| review-request | [0.000000, 0.000000] |
| security-finding | [0.000000, 0.000000] |
| webhook-event | [0.000000, 0.000000] |

### gpt-6-astra/explicit_contract/weak_minus_authoritative

| Family | Difference bounds |
|---|---:|
| artifact | [0.000000, 0.000000] |
| change-record | [0.000000, 0.000000] |
| deployment | [0.000000, 0.000000] |
| maintenance-job | [-0.125000, 0.000000] |
| package-version | [0.000000, 0.000000] |
| review-request | [0.000000, 0.000000] |
| security-finding | [0.000000, 0.000000] |
| webhook-event | [0.000000, 0.000000] |

### gpt-6-astra/explicit_contract_cautious/schedule_weighted/weak_minus_authoritative

| Family | Difference bounds |
|---|---:|
| artifact | [0.000000, 0.000000] |
| change-record | [0.000000, 0.000000] |
| deployment | [0.000000, 0.000000] |
| maintenance-job | [0.000000, 0.000000] |
| package-version | [0.000000, 0.000000] |
| review-request | [0.000000, 0.000000] |
| security-finding | [0.000000, 0.000000] |
| webhook-event | [0.000000, 0.000000] |

### gpt-6-astra/explicit_contract_cautious/weak_minus_authoritative

| Family | Difference bounds |
|---|---:|
| artifact | [0.000000, 0.000000] |
| change-record | [0.000000, 0.000000] |
| deployment | [0.000000, 0.000000] |
| maintenance-job | [0.000000, 0.000000] |
| package-version | [0.000000, 0.000000] |
| review-request | [0.000000, 0.000000] |
| security-finding | [0.000000, 0.000000] |
| webhook-event | [0.000000, 0.000000] |

### gpt-6-astra/explicit_contract_cautious_minus_label_only/weak

| Family | Difference bounds |
|---|---:|
| artifact | [0.000000, 0.000000] |
| change-record | [0.000000, 0.000000] |
| deployment | [0.000000, 0.000000] |
| maintenance-job | [0.000000, 0.000000] |
| package-version | [0.000000, 0.000000] |
| review-request | [0.000000, 0.000000] |
| security-finding | [0.000000, 0.000000] |
| webhook-event | [0.000000, 0.000000] |

### gpt-6-astra/explicit_contract_minus_label_only/weak

| Family | Difference bounds |
|---|---:|
| artifact | [0.000000, 0.000000] |
| change-record | [0.000000, 0.000000] |
| deployment | [0.000000, 0.000000] |
| maintenance-job | [0.000000, 0.000000] |
| package-version | [0.000000, 0.000000] |
| review-request | [0.000000, 0.000000] |
| security-finding | [0.000000, 0.000000] |
| webhook-event | [0.000000, 0.000000] |

### gpt-6-astra/label_only/schedule_weighted/weak_minus_authoritative

| Family | Difference bounds |
|---|---:|
| artifact | [0.000000, 0.000000] |
| change-record | [0.000000, 0.000000] |
| deployment | [0.000000, 0.000000] |
| maintenance-job | [0.000000, 0.000000] |
| package-version | [0.000000, 0.000000] |
| review-request | [0.000000, 0.000000] |
| security-finding | [0.000000, 0.000000] |
| webhook-event | [0.000000, 0.000000] |

### gpt-6-astra/label_only/weak_minus_authoritative

| Family | Difference bounds |
|---|---:|
| artifact | [0.000000, 0.000000] |
| change-record | [0.000000, 0.000000] |
| deployment | [0.000000, 0.000000] |
| maintenance-job | [0.000000, 0.000000] |
| package-version | [0.000000, 0.000000] |
| review-request | [0.000000, 0.000000] |
| security-finding | [0.000000, 0.000000] |
| webhook-event | [0.000000, 0.000000] |

## State-level responses and observed outcomes

| Condition/state | Observed/planned responses | Retry | Stop | Wait | Unresolved responses | Duplicate outcomes | Omission outcomes | Correct ledgers |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| gpt-5.6-sol/explicit_contract/authoritative/committed | 32/32 | 0 | 32 | 0 | 0 | 0 | 0 | 32 |
| gpt-5.6-sol/explicit_contract/authoritative/in_flight | 32/32 | 0 | 0 | 32 | 0 | 0 | 0 | 32 |
| gpt-5.6-sol/explicit_contract/authoritative/not_executed | 32/32 | 32 | 0 | 0 | 0 | 0 | 0 | 32 |
| gpt-5.6-sol/explicit_contract/weak/not_found | 32/32 | 0 | 0 | 21 | 11 | 0 | 32 | 64 |
| gpt-5.6-sol/explicit_contract_cautious/authoritative/committed | 32/32 | 0 | 32 | 0 | 0 | 0 | 0 | 32 |
| gpt-5.6-sol/explicit_contract_cautious/authoritative/in_flight | 32/32 | 0 | 0 | 32 | 0 | 0 | 0 | 32 |
| gpt-5.6-sol/explicit_contract_cautious/authoritative/not_executed | 32/32 | 32 | 0 | 0 | 0 | 0 | 0 | 32 |
| gpt-5.6-sol/explicit_contract_cautious/weak/not_found | 32/32 | 0 | 0 | 32 | 0 | 0 | 32 | 64 |
| gpt-5.6-sol/label_only/authoritative/committed | 32/32 | 0 | 32 | 0 | 0 | 0 | 0 | 32 |
| gpt-5.6-sol/label_only/authoritative/in_flight | 32/32 | 0 | 0 | 32 | 0 | 0 | 0 | 32 |
| gpt-5.6-sol/label_only/authoritative/not_executed | 32/32 | 32 | 0 | 0 | 0 | 0 | 0 | 32 |
| gpt-5.6-sol/label_only/weak/not_found | 32/32 | 0 | 0 | 0 | 32 | 0 | 32 | 64 |
| gpt-6-astra/explicit_contract/authoritative/committed | 32/32 | 0 | 32 | 0 | 0 | 0 | 0 | 32 |
| gpt-6-astra/explicit_contract/authoritative/in_flight | 31/32 | 0 | 0 | 31 | 0 | 0 | 0 | 31 |
| gpt-6-astra/explicit_contract/authoritative/not_executed | 32/32 | 32 | 0 | 0 | 0 | 0 | 0 | 32 |
| gpt-6-astra/explicit_contract/weak/not_found | 32/32 | 0 | 0 | 3 | 29 | 0 | 32 | 64 |
| gpt-6-astra/explicit_contract_cautious/authoritative/committed | 32/32 | 0 | 32 | 0 | 0 | 0 | 0 | 32 |
| gpt-6-astra/explicit_contract_cautious/authoritative/in_flight | 32/32 | 0 | 0 | 32 | 0 | 0 | 0 | 32 |
| gpt-6-astra/explicit_contract_cautious/authoritative/not_executed | 32/32 | 32 | 0 | 0 | 0 | 0 | 0 | 32 |
| gpt-6-astra/explicit_contract_cautious/weak/not_found | 32/32 | 0 | 0 | 29 | 3 | 0 | 32 | 64 |
| gpt-6-astra/label_only/authoritative/committed | 32/32 | 0 | 32 | 0 | 0 | 0 | 0 | 32 |
| gpt-6-astra/label_only/authoritative/in_flight | 32/32 | 0 | 0 | 32 | 0 | 0 | 0 | 32 |
| gpt-6-astra/label_only/authoritative/not_executed | 32/32 | 32 | 0 | 0 | 0 | 0 | 0 | 32 |
| gpt-6-astra/label_only/weak/not_found | 32/32 | 0 | 0 | 0 | 32 | 0 | 32 | 64 |
