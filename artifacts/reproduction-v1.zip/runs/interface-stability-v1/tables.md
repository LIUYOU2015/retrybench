# Interface stability

Kendall tau-b handles exact rate ties. Enumerate all feasible missing retry counts per endpoint/variant; no missing-as-nonretry imputation. Bounds are not rank confidence intervals and omit API sampling uncertainty. Five matched-none endpoints are primary; Astra-low is a separate descriptive sensitivity panel. Near-tie flips do not establish population ranking reversals.

## matched_none

| Variant comparison | Kendall tau-b bounds | Feasible pooled-count assignments |
| --- | --- | --- |
| canonical/labeled vs canonical/unlabeled | [0.738, 0.738] | 4 |
| canonical/labeled vs coded/labeled | [0.738, 0.738] | 72 |
| canonical/labeled vs coded/unlabeled | [0.738, 0.738] | 8 |
| canonical/unlabeled vs coded/labeled | [0.800, 0.800] | 72 |
| canonical/unlabeled vs coded/unlabeled | [1.000, 1.000] | 8 |
| coded/labeled vs coded/unlabeled | [0.800, 0.800] | 144 |

## including_astra_low

| Variant comparison | Kendall tau-b bounds | Feasible pooled-count assignments |
| --- | --- | --- |
| canonical/labeled vs canonical/unlabeled | [0.788, 0.828] | 8 |
| canonical/labeled vs coded/labeled | [0.690, 0.828] | 288 |
| canonical/labeled vs coded/unlabeled | [0.788, 0.828] | 16 |
| canonical/unlabeled vs coded/labeled | [0.733, 0.867] | 576 |
| canonical/unlabeled vs coded/unlabeled | [1.000, 1.000] | 32 |
| coded/labeled vs coded/unlabeled | [0.733, 0.867] | 1152 |

## Equal-variant descriptive summaries

Rates in percent. Brackets cover missing actions only.

| Endpoint | Min | Max | Mean (four equal weights) |
| --- | --- | --- | --- |
| gpt-5.4-mini-2026-03-17 | [80.469, 81.250] | [90.625, 90.625] | [84.766, 85.156] |
| gpt-5.4-2026-03-05 | [55.469, 57.031] | [78.125, 78.125] | [68.359, 68.750] |
| gpt-5.6-sol | [0.000, 0.781] | [21.094, 21.094] | [6.836, 7.812] |
| gpt-5.6-terra | [65.625, 67.188] | [100.000, 100.000] | [85.742, 86.133] |
| gpt-5.6-luna | [49.219, 49.219] | [78.125, 78.125] | [59.766, 60.742] |
| gpt-6-astra | [0.000, 0.000] | [0.000, 3.125] | [0.000, 1.562] |

## Canonical sample-size planning reference

Normal approximation, two independent binomial arms near p=.5, two-sided alpha=.05 and 80% target power. No multiplicity, missingness or clustering allowance. Not observed post-hoc power and not a guarantee that n=128 is decisive.

| Per-arm n | Approximate 80% detectable difference (pp) |
| --- | --- |
| 32 | 35.02 |
| 128 | 17.51 |
