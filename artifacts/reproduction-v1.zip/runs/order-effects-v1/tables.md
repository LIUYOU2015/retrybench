# Retrospective canonical order effects

Post-hoc other3orders-minus-historicalorder0 within labeled canonical prompts. Six endpoints form retrospective Holm family. This does not account for choosing this contrast after viewing heatmap. Alternatives equally sampled; mixture not all24 permutations. Nominal independent-call Newcombe intervals and task-conditional tests are distinct reference calculations. Four purposive tasks and serving dependence limit inference.

| Endpoint | Order0 retries | Other3orders retries | Difference (pp) | Nominal95% Newcombe (pp) | Exact task-stratified p | Holm6 p | Task sign p |
|---|---:|---:|---:|---|---:|---:|---:|
| gpt-5.4-2026-03-05 | 16/32 | 86/96 | +39.58 | [+21.49, +56.60] | 1.0469597e-08 | 5.2347983e-08 | 0.5 |
| gpt-5.4-mini-2026-03-17 | 30/32 | 91/96 | +1.04 | [-6.80, +15.25] | 1 | 1 | 1 |
| gpt-5.6-luna | 26/32 | 76/96 | -2.08 | [-15.55, +15.86] | 1 | 1 | 1 |
| gpt-5.6-sol | 0/32 | 0/96 | +0.00 | [-10.72, +3.85] | 1 | 1 | 1 |
| gpt-5.6-terra | 19/32 | 96/96 | +40.62 | [+25.04, +57.74] | 5.2876751e-11 | 3.172605e-10 | 0.5 |
| gpt-6-astra | 0/32 | 0/96 | +0.00 | [-10.72, +3.85] | 1 | 1 | 1 |
