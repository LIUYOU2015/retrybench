# Contemporaneous candidate-presence control

Contemporaneous fixed-schema candidate-presence factorial. Candidate is an optional invalid suggestion, not a mandatory parameter. Only one weak-label, explicit-semantics prompt and four purposive tasks. No general effect of offering valid keys, internal mechanism, or episode safety established. Marginal missing bounds need not be jointly attainable across metrics.

Returned 236/240; attempted 240; known cost $0.405149; unknown reserve $0.096581.

| Condition | Protected keyed | Unsupported | Retry | Keyed retry | Stop | Wait | Unresolved | Missing | Planned |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| gpt-5.6-luna/absent/omitted | 0 | 8 | 0 | 8 | 0 | 0 | 12 | 0 | 20 |
| gpt-5.6-luna/absent/present | 18 | 0 | 0 | 18 | 0 | 0 | 2 | 0 | 20 |
| gpt-5.6-luna/displayed/omitted | 0 | 1 | 0 | 1 | 0 | 0 | 18 | 1 | 20 |
| gpt-5.6-luna/displayed/present | 0 | 6 | 0 | 6 | 0 | 0 | 14 | 0 | 20 |
| gpt-5.6-sol/absent/omitted | 0 | 0 | 0 | 0 | 0 | 0 | 19 | 1 | 20 |
| gpt-5.6-sol/absent/present | 20 | 0 | 0 | 20 | 0 | 0 | 0 | 0 | 20 |
| gpt-5.6-sol/displayed/omitted | 0 | 0 | 0 | 0 | 0 | 0 | 20 | 0 | 20 |
| gpt-5.6-sol/displayed/present | 19 | 0 | 0 | 19 | 0 | 0 | 0 | 1 | 20 |
| gpt-5.6-terra/absent/omitted | 0 | 0 | 0 | 0 | 0 | 0 | 20 | 0 | 20 |
| gpt-5.6-terra/absent/present | 20 | 0 | 0 | 20 | 0 | 0 | 0 | 0 | 20 |
| gpt-5.6-terra/displayed/omitted | 0 | 0 | 0 | 0 | 0 | 0 | 19 | 1 | 20 |
| gpt-5.6-terra/displayed/present | 20 | 0 | 0 | 20 | 0 | 0 | 0 | 0 | 20 |

## Primary contrasts: displayed minus absent

| Endpoint / original state | Difference bounds (pp) | Nominal95% Newcombe (pp) | Six-way Holm exact conditional p |
|---|---|---|---:|
| gpt-5.6-sol/omitted | [-5.00, +0.00] | [-23.61, +16.11] | 1 |
| gpt-5.6-sol/present | [+0.00, +5.00] | [-16.11, +23.61] | 1 |
| gpt-5.6-terra/omitted | [+0.00, +5.00] | [-16.11, +23.61] | 1 |
| gpt-5.6-terra/present | [+0.00, +0.00] | [-16.11, +16.11] | 1 |
| gpt-5.6-luna/omitted | [-35.00, -30.00] | [-56.73, -2.94] | 0.3317901 |
| gpt-5.6-luna/present | [+30.00, +30.00] | [+7.68, +51.90] | 0.06349206 |

## Full replay vectors

| Condition | Outcomes | FRP | Duplicates | Omissions | Unresolved | Ledger correct | Resolved exact | Protected |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| gpt-5.6-luna/absent/omitted | 60 | 24 | 16 | 12 | 36 | 32 | 8 | 0 |
| gpt-5.6-luna/absent/present | 60 | 0 | 0 | 2 | 6 | 58 | 54 | 54 |
| gpt-5.6-luna/displayed/omitted | 57 | 3 | 2 | 18 | 54 | 37 | 1 | 0 |
| gpt-5.6-luna/displayed/present | 60 | 18 | 12 | 14 | 42 | 34 | 6 | 0 |
| gpt-5.6-sol/absent/omitted | 57 | 0 | 0 | 19 | 57 | 38 | 0 | 0 |
| gpt-5.6-sol/absent/present | 60 | 0 | 0 | 0 | 0 | 60 | 60 | 60 |
| gpt-5.6-sol/displayed/omitted | 60 | 0 | 0 | 20 | 60 | 40 | 0 | 0 |
| gpt-5.6-sol/displayed/present | 57 | 0 | 0 | 0 | 0 | 57 | 57 | 57 |
| gpt-5.6-terra/absent/omitted | 60 | 0 | 0 | 20 | 60 | 40 | 0 | 0 |
| gpt-5.6-terra/absent/present | 60 | 0 | 0 | 0 | 0 | 60 | 60 | 60 |
| gpt-5.6-terra/displayed/omitted | 57 | 0 | 0 | 19 | 57 | 38 | 0 | 0 |
| gpt-5.6-terra/displayed/present | 60 | 0 | 0 | 0 | 0 | 60 | 60 | 60 |

Three correlated worlds per response. Every task cell, supplied string, and missing-action bound is in report.json. No optional pooling or new primary family.
