"""Nominal exact binomial reference intervals, not cluster/population coverage."""
import math
from functools import lru_cache

def cdf(k,n,p):
    if p<=0:return 1.0
    if p>=1:return float(k>=n)
    return math.fsum(math.comb(n,j)*p**j*(1-p)**(n-j) for j in range(k+1))

@lru_cache(None)
def exact_interval(k,n,confidence=.95):
    if type(k) is not int or type(n) is not int or not 0<=k<=n or not n>0 or not 0<confidence<1:raise ValueError('invalid binomial count or confidence')
    alpha=(1-confidence)/2
    def upper(x):
        if x==n:return 1.0
        lo,hi=0.0,1.0
        for _ in range(64):
            mid=(lo+hi)/2
            if cdf(x,n,mid)>alpha:lo=mid
            else:hi=mid
        return (lo+hi)/2
    return [0.0 if k==0 else 1-upper(n-k),upper(k)]

def summary(k,n,missing=0):
    if not 0<=missing<=n-k:raise ValueError('invalid missing count')
    return {'events_observed':k,'planned_responses':n,'missing_responses':missing,'rate_bounds':[k/n,(k+missing)/n],'cp95_reference_envelope':[exact_interval(k,n)[0],exact_interval(k+missing,n)[1]],'interval_assumption':'Two-sided95% Clopper-Pearson under independent common-probability binomial calls. For heterogeneous pooled cells this is a reference calculation, not demonstrated coverage. No task/model-population coverage; missing-action envelope if missing>0.'}

def sign_diagnostic(effects):
    positives=sum(x>0 for x in effects);negatives=sum(x<0 for x in effects);n=positives+negatives
    return {'positive':positives,'negative':negatives,'ties':len(effects)-n,'two_sided_p':min(1.0,2*sum(math.comb(n,k) for k in range(min(positives,negatives)+1))/2**n) if n else 1.0,'minimum_p_if_all_four_nonzero_agree':.125,'interpretation':'Descriptive only; four purposive families, sign exchangeability not established. Ties excluded; p=1 when all tied is not evidence of equivalence.'}
