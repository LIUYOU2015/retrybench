"""Fixed historical weak-prompt label and action-representation study.

Independent endpoint shards preserve request order and spending. No retries,
replacement responses, or result-dependent additions are allowed.
"""
from __future__ import annotations
import argparse
import hashlib
import importlib.util
import json
import random
import shutil
import socket
import subprocess
import sys
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from retrybench.serialization import canonical_json_sha256, read_json_object, read_jsonl, write_json, write_jsonl

STUDY = 'historical-counterbalance-v1'
MODELS = ['gpt-5.4-mini-2026-03-17','gpt-5.4-2026-03-05','gpt-5.6-sol','gpt-5.6-terra','gpt-5.6-luna','gpt-6-astra']
CAPS = dict(zip(MODELS,[1,1,2,2,.5,4]))
RATES = dict(zip(MODELS,[(.75,.075,4.5),(2.5,.25,15),(4,.4,20),(2,.2,12),(.2,.02,1.2),(10,1,50)]))
ACTIONS = ['retry','stop','wait','unresolved']

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def now():return datetime.now(timezone.utc).isoformat()
def helper(path=Path('scripts/followup_studies.py')):
    spec=importlib.util.spec_from_file_location('counterbalance_helper',path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    module.RATES=RATES
    return module

def build_manifest():
    prior=read_jsonl(Path('protocol/historical-bridge-v1/manifest.jsonl'))
    base={r['task_id']:r for r in prior if r['evidence']=='weak'}
    cases=[]
    for model in MODELS:
        for task,original in sorted(base.items()):
            for label in ('labeled','unlabeled'):
                for representation in ('canonical','coded'):
                    for mapping_rotation in ([0] if representation=='canonical' else range(4)):
                        mapping={a:a if representation=='canonical' else 'ABCD'[(i+mapping_rotation)%4] for i,a in enumerate(ACTIONS)}
                        for order_rotation in range(4):
                            ordered=ACTIONS[order_rotation:]+ACTIONS[:order_rotation]
                            tokens=[mapping[a] for a in ordered]
                            prompt=original['prompt'].rsplit('Choose ',1)[0]
                            if label=='unlabeled':prompt=prompt.replace('Evidence contract: weak.\n','')
                            if representation=='coded':prompt+='Action code mapping: '+'; '.join(mapping[a]+' means '+a for a in ordered)+'.\n'
                            prompt+='Choose '+', '.join(tokens[:-1])+', or '+tokens[-1]+'.'
                            for repetition in (1,2):
                                c=dict(study=STUDY,requested_model=model,reasoning_effort='low' if model=='gpt-6-astra' else 'none',max_output_tokens=256,task_id=task,repetition=repetition,label=label,representation=representation,mapping_rotation=mapping_rotation,order_rotation=order_rotation,token_to_action={v:k for k,v in mapping.items()},allowed_actions=tokens,instructions=original['instructions'],prompt=prompt,evidence='weak',observed_state='not_found',schedules=original['schedules'])
                                c['transcript_sha256']=canonical_json_sha256({k:c[k] for k in ('instructions','prompt')})
                                c['case_id']=canonical_json_sha256(c)[:24]
                                cases.append(c)
    random.Random(2026100601).shuffle(cases)
    return cases

def prepare():
    pd=Path('protocol')/STUDY;rd=Path('runs')/STUDY
    if pd.exists() or rd.exists():raise ValueError('Refuse to overwrite frozen study')
    cases=build_manifest()
    protocol=dict(schema_version='retrybench-counterbalance-v1',study=STUDY,recorded_at_utc=now(),planned_requests=len(cases),planned_outcomes=3*len(cases),manifest_sha256=canonical_json_sha256(cases),implementation_sha256=sha(__file__),helper_sha256=sha('scripts/followup_studies.py'),source_sha256={p.name:sha(p) for p in sorted(Path('src/retrybench').glob('*.py'))},models=MODELS,endpoint_caps_usd=CAPS,total_cap_usd=sum(CAPS.values()),rates_per_million=RATES,price_sources=['https://developers.openai.com/api/docs/models/'+m for m in MODELS],prices_checked_date='2026-10-06',decoding='Responses API strict JSON, store=false, output limit256 for every endpoint. None reasoning except Astra low. No temperature or provider sampling seed. Order shuffle is not a sampling seed.',design='Four original tasks, two labels, two draws, four canonical cyclic action orders, plus four code mappings crossed independently with four cyclic semantic orders. Every semantic action occupies every position and coded token equally. Not all24permutations. Coded arms add mapping text, so representation contrasts do not isolate names alone.',primary_contrasts=['Unlabeled minus labeled retry rate within endpoint/canonical order0 (exact historical prompt anchor)','Unlabeled minus labeled retry rate, equal-task weighting within canonical and coded strata separately; all task and format cells retained','Canonical order rotations versus order0, and coded versus canonical within label; exploratory representation robustness, not a pure name effect'],analysis='Original planned response denominators. Missing choices enumerated jointly across three worlds. Raw per-task/cell rates, exact Clopper-Pearson reference intervals under independent binomial-call assumptions (not task-population confidence), all four-task effects. No selection of cells with nonzero observed effects. Nominal intervals unadjusted for multiple comparisons.',stopping='Each endpoint has one serial worker with its own cap and frozen manifest subsequence. At most4 transport timeouts per endpoint; fifth stops. Invalid/incomplete responses retained, no replacement. Auth/access/server/metadata errors stop that endpoint. Pending request refuses resume until explicit amendment. No automatic retries. All endpoints reported even with floor or missing results.',timeout_seconds=300,max_transport_missing_per_endpoint=4,scope='Weak not_found only. No authoritative or key-protection arms. Astra low is a separate setting, not matched-none. One sampled endpoint per model name, one collection window, four purposive reused tasks. API draws are not independent training/model replicates.')
    pd.mkdir(parents=True);rd.mkdir(parents=True)
    write_json(pd/'protocol.json',protocol);write_jsonl(pd/'manifest.jsonl',cases)
    source=rd/'collection-source/retrybench';source.mkdir(parents=True)
    for p in Path('src/retrybench').glob('*.py'):shutil.copyfile(p,source/p.name)
    code=rd/'collection-code';code.mkdir()
    for name in ('counterbalance_study.py','followup_studies.py'):shutil.copyfile(Path('scripts')/name,code/name)
    print(json.dumps({'planned_requests':len(cases),'per_endpoint':len(cases)//len(MODELS),'total_cap_usd':sum(CAPS.values())}))

def collect(model):
    pd=Path('protocol')/STUDY;rd=Path('runs')/STUDY
    protocol=read_json_object(pd/'protocol.json');allcases=read_jsonl(pd/'manifest.jsonl')
    if canonical_json_sha256(allcases)!=protocol['manifest_sha256'] or sha(__file__)!=protocol['implementation_sha256'] or sha('scripts/followup_studies.py')!=protocol['helper_sha256']:raise ValueError('frozen code/input mismatch')
    for name,digest in protocol['source_sha256'].items():
        if sha(Path('src/retrybench')/name)!=digest:raise ValueError('source changed')
    cases=[c for c in allcases if c['requested_model']==model];f=helper();ph=canonical_json_sha256(protocol)
    out=rd/'shards'/model;out.mkdir(parents=True,exist_ok=True);private=out/'private';private.mkdir(exist_ok=True)
    pending=private/'pending.json';journal=private/'requests.jsonl'
    if pending.exists():raise ValueError('Pending request must not be repeated')
    records=read_jsonl(journal) if journal.exists() else []
    if [r['case_id'] for r in records]!=[c['case_id'] for c in cases[:len(records)]] or any(r['protocol_sha256']!=ph for r in records):raise ValueError('journal mismatch')
    if any(r['status']=='failed' for r in records):raise ValueError('failure requires review')
    transport=sum(r['status']=='transport_timeout' for r in records)
    if transport>4:raise ValueError('transport missing cap')
    spent=sum(r.get('cost_usd',0)+r.get('unknown_cost_upper_reserve_usd',0) for r in records)
    def publish():
        write_jsonl(out/'requests.jsonl',records)
        write_json(out/'summary.json',dict(protocol_sha256=ph,model=model,planned=len(cases),attempted=len(records),complete=sum(r['status']=='complete' for r in records),missing=sum(r['status']!='complete' for r in records),known_cost_usd=sum(r.get('cost_usd',0) for r in records),unknown_cost_upper_reserve_usd=sum(r.get('unknown_cost_upper_reserve_usd',0) for r in records),attempted_all=len(records)==len(cases)))
    result=subprocess.run(['/usr/bin/security','find-generic-password','-a','retrybench','-s','retrybench-openai-api-key','-w'],capture_output=True,timeout=25)
    if result.returncode or not result.stdout.strip():raise ValueError('Keychain lookup failed')
    key=result.stdout.decode().strip();del result
    for c in cases[len(records):]:
        reserve=f.bounds_cost(c)
        if spent+reserve>CAPS[model]:publish();print(model+': budget stop',flush=True);return
        record=dict(case_id=c['case_id'],protocol_sha256=ph,collected_at_utc=now());write_json(pending,record)
        request=urllib.request.Request('https://api.openai.com/v1/responses',data=json.dumps(f.payload(c)).encode(),headers={'Authorization':'Bearer '+key,'Content-Type':'application/json'},method='POST')
        try:
            with urllib.request.urlopen(request,timeout=300) as response:raw=json.loads(response.read())
            with (private/'provider-responses.jsonl').open('a') as file:file.write(json.dumps({'case_id':c['case_id'],'response':raw},sort_keys=True)+'\n')
            record.update(f.decode(c,raw))
            if record['status']=='complete':
                record['selected_token']=record['decision']['action']
                record['decision']['action']=c['token_to_action'][record['selected_token']]
        except (TimeoutError,socket.timeout):record.update(status='transport_timeout',unknown_cost_upper_reserve_usd=reserve)
        except Exception as exc:record.update(status='failed',error_type=type(exc).__name__,http_status=getattr(exc,'code',None),unknown_cost_upper_reserve_usd=reserve)
        with journal.open('a') as file:file.write(json.dumps(record,sort_keys=True)+'\n')
        records.append(record);pending.unlink();spent+=record.get('cost_usd',0)+record.get('unknown_cost_upper_reserve_usd',0);transport+=record['status']=='transport_timeout'
        publish()
        if len(records)%40==0:print(json.dumps({'endpoint':model,'attempted':len(records),'spent_plus_reserve':round(spent,6)}),flush=True)
        if record['status']=='failed' or transport>4:print(model+': stopped under failure policy',flush=True);return
    print(model+': fixed manifest complete',flush=True)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('mode',choices=['prepare','collect']);ap.add_argument('--model',choices=MODELS);args=ap.parse_args()
    if args.mode=='collect' and args.model is None:ap.error('collect requires model')
    try:prepare() if args.mode=='prepare' else collect(args.model)
    except Exception as exc:print('Stopped safely: '+type(exc).__name__,flush=True);sys.exit(1)
