"""Offline later-block analysis, preserving fixed denominators and joint replay bounds."""
from collections import Counter
from pathlib import Path
import hashlib,importlib.util,json,math
from retrybench.serialization import canonical_json_sha256,read_json_object,read_jsonl,write_json,write_jsonl
from contrast_inference import analyze_terms,holm,mover
from response_intervals import summary
ROOT=Path(__file__).resolve().parents[1]
STUDY='candidate-presence-v1'
METRICS=('false_retry_permission','duplicates','omissions','unresolved','ledger_correct','resolved_exact_state','protected_recovery')

def analyze():
    pd=ROOT/'protocol'/STUDY;rd=ROOT/'runs'/STUDY;p=read_json_object(pd/'protocol.json');cases=read_jsonl(pd/'manifest.jsonl');requests=read_jsonl(rd/'requests.jsonl');col=read_json_object(rd/'collection-summary.json');ph=canonical_json_sha256(p)
    assert canonical_json_sha256(cases)==p['manifest_sha256'] and col['protocol_sha256']==ph
    assert col.get('pending_reserved_usd',0)==0 and not list((rd/'private').glob('pending-*.json'))
    assert col['attempted_all']==(len(requests)==len(cases))
    assert len({r['case_id'] for r in requests})==len(requests)
    byid={r['case_id']:r for r in requests};assert [r['case_id'] for r in requests]==[c['case_id'] for c in cases if c['case_id'] in byid]
    for name,h in p['collection_code_sha256'].items():assert hashlib.sha256((rd/'collection-code'/name).read_bytes()).hexdigest()==h
    import contrast_inference, response_intervals
    for path in (Path(__file__), Path(contrast_inference.__file__), Path(response_intervals.__file__)):
        assert hashlib.sha256(path.read_bytes()).hexdigest()==p['collection_code_sha256'][path.name]
    from retrybench import model
    for name,h in p['source_sha256'].items():assert hashlib.sha256((Path(model.__file__).parent/name).read_bytes()).hexdigest()==h
    spec=importlib.util.spec_from_file_location('frozen_candidate',rd/'collection-code/candidate_presence_study.py');f=importlib.util.module_from_spec(spec);spec.loader.exec_module(f)
    import counterbalance_study
    for module,name in ((f.prior,'followup_studies.py'),(counterbalance_study,'counterbalance_study.py')):
        assert hashlib.sha256(Path(module.__file__).read_bytes()).hexdigest()==p['collection_code_sha256'][name]
    assert col['attempted']==len(requests) and col['planned']==len(cases)
    for m in p['models']:
        selected=[r['case_id'] for r in requests if r['requested_model']==m]
        assert selected==[c['case_id'] for c in cases if c['requested_model']==m][:len(selected)]
    observations={};missing=[];options={};outcomes=[]
    for c in cases:
        r=byid.get(c['case_id']);d=None
        if r:
            assert r['protocol_sha256']==ph and r['requested_model']==c['requested_model'] and r['collected_at_utc']>=p['recorded_at_utc']
            if r['status'] in ('complete','invalid_output','incomplete'):
                assert 'usage' in r and 'cost_usd' in r
            if r['status'] in ('transport_error','failed'):
                reserve=r['unknown_cost_upper_reserve_usd']
                assert math.isfinite(reserve) and reserve>=0 and abs(reserve-f.reserve(c))<1e-10
            if r['status']!='complete':assert 'decision' not in r
            if 'usage' in r:
                u=r['usage'];i,ca,o=p['rates_per_million'][c['requested_model']]
                assert all(type(u[k]) is int and u[k]>=0 for k in ('input_tokens','output_tokens','cached_input_tokens','reasoning_tokens'))
                assert u['cached_input_tokens']<=u['input_tokens'] and u['reasoning_tokens']<=u['output_tokens']<=c['max_output_tokens']
                assert math.isfinite(r['cost_usd']) and r['cost_usd']>=0
                assert abs(r['cost_usd']-((u['input_tokens']-u['cached_input_tokens'])*i+u['cached_input_tokens']*ca+u['output_tokens']*o)/1e6)<1e-10
            if r['status']=='complete':
                d=r['decision'];assert isinstance(d,dict) and set(d)==({'action','rationale','idempotency_key'} if c['block']=='supplied_key' else {'action','rationale'}) and isinstance(d['rationale'],str)
                assert r['provider_status']=='completed' and d['action'] in c['allowed_actions']
                assert r['returned_model']==c['requested_model'] or r['returned_model'].startswith(c['requested_model']+'-')
                if c['block']=='supplied_key':
                    key=d['idempotency_key'];assert isinstance(key,str) and bool(key) if d['action']=='retry_with_key' else key is None
                observations[c['case_id']]=d
            else:assert r['status'] in ('invalid_output','incomplete','transport_error','failed')
        if d is None: missing.append(dict(case_id=c['case_id'],condition=c['condition'],task_id=c['task_id'],status=r['status'] if r else 'unattempted'))
        options[c['case_id']]=[f.score(c,x) for x in ([d] if d is not None else f.possible_decisions(c))]
        if d is not None: outcomes+=options[c['case_id']][0]
    assert col['complete']==len(observations)
    def cell(cs):
        observed=[c for c in cs if c['case_id'] in observations];rows=[r for c in observed for r in options[c['case_id']][0]]
        m=len(cs)-len(observed);frp=sum(any(r['false_retry_permission'] for r in options[c['case_id']][0]) for c in observed)
        keyed=sum(observations[c['case_id']]['action']=='retry_with_key' for c in observed)
        matching=sum(f.protected(c,observations[c['case_id']]) for c in observed)
        bounds={k:[sum(fn(sum(r[k] for r in opt) for opt in options[c['case_id']]) for c in cs) for fn in (min,max)] for k in METRICS}
        terminal=[r for r in rows if r['schedule']=='fail_before_execution']
        return dict(planned_responses=len(cs),observed_responses=len(observed),missing_responses=m,actions=dict(Counter(observations[c['case_id']]['action'] for c in observed)),
          supplied_key_counts=dict(Counter(observations[c['case_id']]['idempotency_key'] for c in observed if observations[c['case_id']]['action']=='retry_with_key')),
          protected_key_dispatches=matching,unprotected_key_dispatches=keyed-matching,
          frp_response_summary=summary(frp,len(cs),m),observed_outcomes=len(rows),outcomes={k:sum(r[k] for r in rows) for k in METRICS},outcome_bounds=bounds,
          terminal_progress=sum(r['resolved_exact_state'] for r in terminal),terminal_progress_bounds=[sum(fn(sum(r['resolved_exact_state'] for r in opt if r['schedule']=='fail_before_execution') for opt in options[c['case_id']]) for c in cs) for fn in (min,max)])
    groups={name:cell([c for c in cases if c['condition']==name]) for name in sorted({c['condition'] for c in cases})}
    tasks={name+'/'+task:cell([c for c in cases if c['condition']==name and c['task_id']==task]) for name in groups for task in sorted({c['task_id'] for c in cases})}
    contrast={}
    binary={c['case_id']:int(observations[c['case_id']]['action'] in ('retry','retry_with_key') and not f.protected(c,observations[c['case_id']])) for c in cases if c['case_id'] in observations}
    for model in p['models']:
        for state in ('omitted','present'):
            name=model+'/'+state
            arms=[(a,[c for c in cases if c['requested_model']==model and c['original_key_state']==state and c['candidate']==candidate]) for a,candidate in ((1,'displayed'),(-1,'absent'))]
            absent=sum(c['case_id'] not in binary for _,cs in arms for c in cs)
            if absent<=16:
                contrast[name]=analyze_terms(arms,binary,['task_id']);contrast[name]['event']='unsupported_dispatch'
            else:contrast[name]={'not_computed':'More than16 missing choices; no complete-study inferential claim.','missing_responses':absent}
    adjusted=holm({name:c.get('conditional_p_bounds',[1,1])[1] for name,c in contrast.items()})
    for name in contrast:contrast[name]['holm_worst_case_conditional_p']=adjusted[name]
    known=sum(r.get('cost_usd',0) for r in requests);unknown=sum(r.get('unknown_cost_upper_reserve_usd',0) for r in requests)
    assert abs(known-col['known_cost_usd'])<1e-9 and abs(unknown-col['unknown_cost_upper_reserve_usd'])<1e-9 and known+unknown<=p['cap_usd']+1e-9
    report=dict(schema_version='retrybench-candidate-presence-report-v1',planned_requests=len(cases),attempted_requests=len(requests),observed_responses=len(observations),missing_responses=len(missing),observed_outcomes=len(outcomes),attempted_all=col['attempted_all'],known_cost_usd=known,unknown_cost_upper_reserve_usd=unknown,
       groups=groups,task_cells=tasks,candidate_contrasts=contrast,missing_cases=missing,
       blocks={block:dict(planned=sum(c['block']==block for c in cases),returned=sum(c['block']==block and c['case_id'] in observations for c in cases),attempted=sum(c['block']==block and c['case_id'] in byid for c in cases),known_cost_usd=sum(byid[c['case_id']].get('cost_usd',0) for c in cases if c['block']==block and c['case_id'] in byid),unknown_cost_upper_reserve_usd=sum(byid[c['case_id']].get('unknown_cost_upper_reserve_usd',0) for c in cases if c['block']==block and c['case_id'] in byid)) for block in ('supplied_key',)},
       decoding_observed={m:dict(responses_with_usage=sum(r['requested_model']==m and 'usage' in r for r in requests),responses_with_reasoning_tokens=sum(r['requested_model']==m and r.get('usage',{}).get('reasoning_tokens',0)>0 for r in requests),maximum_output_tokens=max((r['usage']['output_tokens'] for r in requests if r['requested_model']==m and 'usage' in r),default=None)) for m in p['models']},
       collection_first_utc=min((r['collected_at_utc'] for r in requests),default=None),collection_last_utc=max((r['collected_at_utc'] for r in requests),default=None),
       interpretation='Contemporaneous fixed-schema candidate-presence factorial. Candidate is an optional invalid suggestion, not a mandatory parameter. Only one weak-label, explicit-semantics prompt and four purposive tasks. No general effect of offering valid keys, internal mechanism, or episode safety established. Marginal missing bounds need not be jointly attainable across metrics.',
       provenance=dict(protocol_sha256=ph,requests_sha256=hashlib.sha256((rd/'requests.jsonl').read_bytes()).hexdigest(),analysis_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),analysis_dependency_sha256={name:hashlib.sha256((ROOT/'scripts'/name).read_bytes()).hexdigest() for name in ('contrast_inference.py','response_intervals.py')}))
    return report,outcomes

def render(r):
    lines=['# Contemporaneous candidate-presence control','',r['interpretation'],'',f"Returned {r['observed_responses']}/{r['planned_requests']}; attempted {r['attempted_requests']}; known cost ${r['known_cost_usd']:.6f}; unknown reserve ${r['unknown_cost_upper_reserve_usd']:.6f}.",'', '| Condition | Protected keyed | Unsupported | Retry | Keyed retry | Stop | Wait | Unresolved | Missing | Planned |','|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|']
    for name,g in r['groups'].items():
        a=g['actions'];lines.append('| '+' | '.join(map(str,[name,g['protected_key_dispatches'],g['frp_response_summary']['events_observed']]+[a.get(k,0) for k in ('retry','retry_with_key','stop','wait','unresolved')]+[g['missing_responses'],g['planned_responses']]))+' |')
    lines+=['','## Primary contrasts: displayed minus absent','', '| Endpoint / original state | Difference bounds (pp) | Nominal95% Newcombe (pp) | Six-way Holm exact conditional p |','|---|---|---|---:|']
    for name,c in r['candidate_contrasts'].items():
        if 'difference_bounds' not in c:lines.append('| '+name+' | Uncomputed | Missing | Uncomputed |');continue
        a,b=c['difference_bounds'];l,u=c['mover95_reference_envelope'];lines.append(f"| {name} | [{100*a:+.2f}, {100*b:+.2f}] | [{100*l:+.2f}, {100*u:+.2f}] | {c['holm_worst_case_conditional_p']:.7g} |")
    lines+=['','## Full replay vectors','', '| Condition | Outcomes | FRP | Duplicates | Omissions | Unresolved | Ledger correct | Resolved exact | Protected |','|---|---:|---:|---:|---:|---:|---:|---:|---:|']
    for name,g in r['groups'].items():lines.append('| '+' | '.join(map(str,[name,g['observed_outcomes']]+[g['outcomes'][k] for k in METRICS]))+' |')
    lines+=['','Three correlated worlds per response. Every task cell, supplied string, and missing-action bound is in report.json. No optional pooling or new primary family.','']
    return '\n'.join(lines)

if __name__=='__main__':
    r,rows=analyze();rd=ROOT/'runs'/STUDY;write_json(rd/'report.json',r);write_jsonl(rd/'outcomes.jsonl',rows);(rd/'tables.md').write_text(render(r));print('Validated contemporaneous report and outcomes.')
