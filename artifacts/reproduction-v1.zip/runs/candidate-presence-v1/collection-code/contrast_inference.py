"""Conditional reference calculations for independent fixed-design API responses.

Wilson-MOVER follows Newcombe (1998) for two proportions and Zou et al.
(2009) for a linear combination. These are approximate, not exact intervals.
Exact conditional association tests convolve hypergeometric stratum margins.
Separate calls are never paired by repetition number.
"""
import math
from statistics import NormalDist
from itertools import product
from collections import defaultdict
from functools import lru_cache

NORMAL=NormalDist()

def wilson(k,n,z=1.959963984540054):
    if not (type(k) is int and type(n) is int and 0<=k<=n and n>0):raise ValueError('invalid counts')
    p=k/n;z2=z*z;den=1+z2/n
    mid=(p+z2/(2*n))/den;half=z*math.sqrt(p*(1-p)/n+z2/(4*n*n))/den
    return max(0.,mid-half),min(1.,mid+half)

def mover(terms,confidence=.95,z=None):
    """terms=(coefficient,events,n); independent samples, disjoint case sets."""
    if z is None:z=NORMAL.inv_cdf((1+confidence)/2)
    estimate=sum(a*k/n for a,k,n in terms);lo2=hi2=0.
    for a,k,n in terms:
        l,u=wilson(k,n,z);p=k/n
        lo2+=a*a*((p-l) if a>=0 else (u-p))**2
        hi2+=a*a*((u-p) if a>=0 else (p-l))**2
    return estimate,[estimate-math.sqrt(lo2),estimate+math.sqrt(hi2)]

def mover_p(terms):
    """Two-sided approximate reference p obtained by interval inversion."""
    estimate,_=mover(terms)
    if abs(estimate)<1e-15:return 1.
    def includes(z):
        _,ci=mover(terms,z=z);return ci[0]<=0<=ci[1]
    lo,hi=0.,2.
    while not includes(hi) and hi<1024:hi*=2
    if not includes(hi):return 0.
    for _ in range(70):
        mid=(lo+hi)/2
        if includes(mid):hi=mid
        else:lo=mid
    return math.erfc(((lo+hi)/2)/math.sqrt(2))

@lru_cache(None)
def conditional_p(tables):
    """Exact two-sided doubled-minimum-tail test for common odds ratio=1.

    Tables are (events1,n1,events0,n0); conditions on margins in each
    stratum, then convolves event counts in arm1. Degenerate margins retained.
    """
    pmf={0:1.};observed=0
    for k1,n1,k0,n0 in tables:
        total=n1+n0;events=k1+k0;den=math.comb(total,n1)
        hs={x:math.comb(events,x)*math.comb(total-events,n1-x)/den for x in range(max(0,n1-(total-events)),min(n1,events)+1)}
        nxt=defaultdict(float)
        for x,p in pmf.items():
            for y,q in hs.items():nxt[x+y]+=p*q
        pmf=dict(nxt);observed+=k1
    return min(1.,2*min(math.fsum(p for x,p in pmf.items() if x<=observed),math.fsum(p for x,p in pmf.items() if x>=observed)))

def holm(values):
    ordered=sorted(values,key=values.get);out={};floor=0.;m=len(values)
    for i,key in enumerate(ordered):floor=max(floor,min(1.,(m-i)*values[key]));out[key]=floor
    return out

def analyze_terms(arms,outcomes,stratum_fields=None):
    """arms=(coefficient,list of manifest cases). outcomes maps case_id to0/1.

    Enumerate every missing response as0/1, not only aggregate endpoints.
    CMH supported for (+1,-1) arms. No inference of pairing from draw number.
    """
    ids=[c['case_id'] for _,cs in arms for c in cs]
    if len(ids)!=len(set(ids)):raise ValueError('overlapping samples in linear contrast')
    missing=sorted(set(ids)-set(outcomes));estimates=[];intervals=[];pvalues=[];conditional=[]
    if len(missing)>16:raise ValueError('too many missing cases to enumerate')
    for bits in product((0,1),repeat=len(missing)):
        values={**outcomes,**dict(zip(missing,bits))}
        terms=[(coef,sum(values[c['case_id']] for c in cs),len(cs)) for coef,cs in arms]
        estimate,interval=mover(terms);estimates.append(estimate);intervals.append(interval);pvalues.append(mover_p(terms))
        if stratum_fields is not None:
            if [a for a,_ in arms]!=[1,-1]:raise ValueError('conditional test needs two arms')
            bins=[defaultdict(list),defaultdict(list)]
            for i,(_,cs) in enumerate(arms):
                for c in cs:bins[i][tuple(c[f] for f in stratum_fields)].append(values[c['case_id']])
            if set(bins[0])!=set(bins[1]):raise ValueError('unmatched strata')
            tables=tuple((sum(bins[0][k]),len(bins[0][k]),sum(bins[1][k]),len(bins[1][k])) for k in sorted(bins[0]))
            conditional.append(conditional_p(tables))
    out={'event':'retry','arm_sizes':[len(cs) for _,cs in arms],'coefficients':[a for a,_ in arms],'missing_responses':len(missing),'missing_assignments':2**len(missing),'difference_bounds':[min(estimates),max(estimates)],'mover95_reference_envelope':[min(c[0] for c in intervals),max(c[1] for c in intervals)],'mover_p_bounds':[min(pvalues),max(pvalues)]}
    if conditional:out.update(conditional_p_bounds=[min(conditional),max(conditional)],stratum_fields=stratum_fields)
    return out
