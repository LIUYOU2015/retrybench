"""Post-hoc Tier-1 diagnostics; no new model calls or production assumptions."""
from __future__ import annotations

import argparse
import hashlib
import itertools
import math
import random
from collections import defaultdict
from pathlib import Path

from .model import Action, EvidenceContract, Schedule, TASKS
from .scoring import score_exact_state
from .serialization import read_jsonl, write_json
from .service import AmbiguousTimeout, DeterministicService
from .task_robustness import ROBUSTNESS_TASKS


BLOCKS = ("confirmation-v2", "gpt54-replication-v1", "task-robustness-v1")


def mean(values):
    return sum(values) / len(values)


def interval(values):
    """Empirical percentile interval, with linear interpolation."""
    ordered = sorted(values)
    def quantile(q):
        pos = (len(ordered) - 1) * q
        left = int(pos)
        right = min(left + 1, len(ordered) - 1)
        return ordered[left] + (pos - left) * (ordered[right] - ordered[left])
    return [quantile(.025), quantile(.975)]


def family_statistics(effects):
    n = len(effects)
    # Exhaustive for four clusters, seeded Monte Carlo for eight.
    if n <= 4:
        samples = [mean(sample) for sample in itertools.product(effects, repeat=n)]
    else:
        rng = random.Random(20261004)
        samples = [mean(rng.choices(effects, k=n)) for _ in range(100000)]
    positive = sum(x > 0 for x in effects)
    negative = sum(x < 0 for x in effects)
    nonzero = positive + negative
    tail = sum(math.comb(nonzero, k) for k in range(min(positive, negative) + 1))
    p = min(1.0, 2 * tail / 2**nonzero) if nonzero else 1.0
    return {
        "families": n, "mean": mean(effects), "positive": positive,
        "negative": negative, "ties": n - nonzero,
        "cluster_percentile_95_interval": interval(samples),
        "bootstrap_replicates": len(samples), "bootstrap_seed": 20261004,
        "exact_two_sided_sign_p_excluding_ties": p,
        "interpretation": "Post-hoc family-level diagnostics. Resampling whole purposive families preserves within-family dependence but assumes exchangeability not supplied by the design; sign test assumes independent equiprobable signs. Neither licenses task-population inference.",
    }


def response_table(rows):
    groups = defaultdict(list)
    for row in rows:
        groups[row["response_group_id"]].append(row)
    table = defaultdict(list)
    for group in groups.values():
        first = group[0]
        if len({(r["transcript_sha256"], r["decision"]["action"]) for r in group}) != 1:
            raise ValueError("response sharing integrity failure")
        table[(first.get("prompt_condition", "neutral"), first["evidence"], first["observed_state"])].append(first)
    result = {}
    for key, selected in sorted(table.items()):
        inadmissible = [r for r in selected if not r["retry_permitted"]]
        admissible = [r for r in selected if r["retry_permitted"]]
        result["/".join(key)] = {
            "responses": len(selected),
            "actions": {action: sum(r["decision"]["action"] == action for r in selected) for action in ("retry", "stop", "wait", "unresolved")},
            "inadmissible_responses": len(inadmissible),
            "unsupported_retry_responses": sum(r["decision"]["action"] == "retry" for r in inadmissible),
            "admissible_responses": len(admissible),
            "correct_retry_responses": sum(r["decision"]["action"] == "retry" for r in admissible),
        }
    return result


def analyze_block(rows):
    selected = [r for r in rows if r.get("prompt_condition", "neutral") == "neutral"]
    families = defaultdict(list)
    for row in selected:
        families[row.get("family_id", row["task_id"])].append(row)
    effects = []
    common_effects = []
    lexical = []
    for family, group in sorted(families.items()):
        rates = {e: mean([r["false_retry_permission"] for r in group if r["evidence"] == e]) for e in ("weak", "authoritative")}
        effects.append({"family": family, "weak": rates["weak"], "authoritative": rates["authoritative"], "difference": rates["weak"] - rates["authoritative"]})
        common_rates = {e: mean([r["false_retry_permission"] for r in group if r["evidence"] == e and r["schedule"] != "fail_before_execution"]) for e in ("weak", "authoritative")}
        common_effects.append({"family": family, "weak": common_rates["weak"], "authoritative": common_rates["authoritative"], "difference": common_rates["weak"] - common_rates["authoritative"]})
        if "lexical_frame" in group[0]:
            frames = {f: mean([r["false_retry_permission"] for r in group if r["evidence"] == "weak" and r["lexical_frame"] == f]) for f in ("create", "noncreate")}
            lexical.append({"family": family, **frames, "difference": frames["create"] - frames["noncreate"]})
    result = {"response_table": response_table(rows), "family_effects": effects, "interface_statistics": family_statistics([r["difference"] for r in effects])}
    result.update(common_forbidden_family_effects=common_effects, common_forbidden_statistics=family_statistics([r["difference"] for r in common_effects]))
    if lexical:
        result.update(lexical_effects=lexical, lexical_statistics=family_statistics([r["difference"] for r in lexical]))
    return result


def replay_archives(root):
    tasks = {task.task_id: task for task in TASKS}
    tasks.update({item.task.task_id: item.task for item in ROBUSTNESS_TASKS})
    summary = {}
    for block in ("pilot-v1",) + BLOCKS:
        rows = read_jsonl(root / "runs" / block / "sanitized-outcomes.jsonl")
        checks = defaultdict(int)
        for row in rows:
            task = tasks[row["task_id"]]
            schedule, evidence = Schedule(row["schedule"]), EvidenceContract(row["evidence"])
            service = DeterministicService(task, schedule, evidence)
            operation_id = row["operation_id"]
            try:
                service.start(operation_id)
            except AmbiguousTimeout:
                pass
            observed = service.status()
            if observed.value != row["observed_state"]:
                raise ValueError("archived observation differs from logical simulator")
            pending = schedule == Schedule.IN_FLIGHT_LATE_COMMIT
            if pending:
                assert service.pending_original and not service.effects
                checks["pending_at_observation"] += 1
            action = Action(row["decision"]["action"])
            if action == Action.RETRY:
                if pending:
                    assert service.pending_original and not service.effects
                    checks["pending_at_retry_admission"] += 1
                service.retry(operation_id, stable_idempotency=False)
            service.settle()
            score = score_exact_state(task, operation_id, service.effects, action in {Action.WAIT, Action.UNRESOLVED})
            for name, value in score.to_dict().items():
                if row[name] != value:
                    raise ValueError("archived metric differs: " + name)
            if row["effect_count"] != len(service.effects):
                raise ValueError("archived ledger count differs")
            checks["matched_outcomes"] += 1
        summary[block] = dict(checks)
    return {"blocks": summary, "matched_outcomes": sum(x["matched_outcomes"] for x in summary.values()), "pending_at_observation": sum(x["pending_at_observation"] for x in summary.values()), "pending_at_retry_admission": sum(x.get("pending_at_retry_admission", 0) for x in summary.values()), "interpretation": "Deterministic re-execution of archived decisions; not a reconstruction or validation of original wall-clock ordering."}


def prior_sensitivity(root):
    rows = [r for r in read_jsonl(root / "runs/deterministic-baselines-v1/outcomes.jsonl") if r["evidence"] == "weak"]
    schedules = [s.value for s in Schedule]
    priors = {"uniform": [.25] * 4, "terminal_heavy": [.7, .1, .1, .1], "committed_heavy": [.1, .7, .1, .1], "pending_heavy": [.1, .1, .7, .1], "stale_heavy": [.1, .1, .1, .7]}
    output = {}
    for prior, weights in priors.items():
        output[prior] = {}
        for policy in sorted({r["policy"] for r in rows}):
            metrics = {}
            for metric in ("duplicate_effect", "omission", "unresolved", "probes"):
                metrics[metric] = sum(w * mean([r[metric] for r in rows if r["policy"] == policy and r["schedule"] == schedule]) for schedule, w in zip(schedules, weights))
            output[prior][policy] = {"expected_metrics": metrics, "loss_by_duplicate_cost": {str(ratio): ratio * metrics["duplicate_effect"] + metrics["omission"] for ratio in (1, 10, 100)}}
    return {"schedule_order": schedules, "hypothetical_priors": priors, "omission_cost": 1, "duplicate_costs": [1, 10, 100], "formula": "C = c_duplicate * P(duplicate) + c_omission * P(omission). Unresolved and probes reported separately; add c_unresolved*P(unresolved)+c_probe*E(probes) for other utilities.", "interpretation": "Illustrative sensitivity on weak-evidence deterministic controls, not estimated production priors, latency, money, or deployment-optimal policies. Perfect simulated idempotency is an idealized control.", "results": output}


def analyze(root):
    sources = [root / "runs" / name / "sanitized-outcomes.jsonl" for name in ("pilot-v1",) + BLOCKS]
    sources.append(root / "runs/deterministic-baselines-v1/outcomes.jsonl")
    paid = {}
    for name in ("pilot-v1",) + BLOCKS:
        rows = read_jsonl(root / "runs" / name / "sanitized-outcomes.jsonl")
        paid[name] = {"calls": len({r.get("response_group_id", r["cell_id"]) for r in rows}), "outcomes": len(rows)}
    controls = {}
    for name in ("deterministic-baselines-v1", "closest-work-v1", "langgraph-v1", "langchain-v1", "framework-matched-v2"):
        path = root / "runs" / name / "outcomes.jsonl"
        sources.append(path)
        controls[name] = len(read_jsonl(path))
    inventory = {"paid_blocks": paid, "total_archived_calls": sum(x["calls"] for x in paid.values()), "total_archived_outcomes": sum(x["outcomes"] for x in paid.values()), "deterministic_blocks": controls, "total_deterministic_episodes": sum(controls.values()), "scope": "Released completed blocks only; repeated validation runs and unavailable historical request-attempt records are not new independent data."}
    return {"schema_version": "retrybench-review-diagnostics-v1", "status": "post-hoc; no new model calls", "source_hashes": {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sources}, "blocks": {name: analyze_block(read_jsonl(root / "runs" / name / "sanitized-outcomes.jsonl")) for name in BLOCKS}, "logical_replay": replay_archives(root), "prior_sensitivity": prior_sensitivity(root), "experiment_inventory": inventory}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path('.'))
    args = parser.parse_args()
    root = args.root.resolve()
    write_json(root / 'runs/review-diagnostics-v1/analysis.json', analyze(root))


if __name__ == '__main__':
    main()
