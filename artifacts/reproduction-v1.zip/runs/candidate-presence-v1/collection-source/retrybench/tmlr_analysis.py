"""Read-only reanalysis and matched framework controls for the TMLR revision.

Historical runs are inputs, never overwritten. No model calls are made here.
"""

from __future__ import annotations

import argparse
import hashlib
from collections import Counter, defaultdict
from pathlib import Path

from .model import Schedule, TASKS
from .serialization import read_jsonl, write_json, write_jsonl


IDENTITY_ERRORS = (
    "wrong_operation_identity", "wrong_task", "wrong_tool",
    "wrong_target", "wrong_payload",
)


def ledger_correct(row):
    """External effect correctness, independently of the recovery decision."""
    return row["effect_count"] == 1 and not any(row[key] for key in IDENTITY_ERRORS)


def outcome_summary(rows):
    return {
        "outcomes": len(rows),
        "actions": dict(sorted(Counter(row["decision"]["action"] for row in rows).items())),
        "false_retry_permission": sum(row["false_retry_permission"] for row in rows),
        "duplicates": sum(row["duplicate_effect"] for row in rows),
        "omissions": sum(row["omission"] for row in rows),
        "unresolved": sum(row["unresolved"] for row in rows),
        "ledger_correct": sum(ledger_correct(row) for row in rows),
        "resolved_exact_state": sum(row["exact_state_success"] for row in rows),
        "response_groups": len({row["response_group_id"] for row in rows}),
    }


def reanalyze_archives(root):
    blocks = {}
    for name in ("confirmation-v2", "gpt54-replication-v1", "task-robustness-v1"):
        path = root / "runs" / name / "sanitized-outcomes.jsonl"
        rows = read_jsonl(path)
        grouped = defaultdict(list)
        for row in rows:
            grouped[(row.get("prompt_condition", "neutral"), row["evidence"])].append(row)
        summaries = {}
        for (prompt, evidence), selected in sorted(grouped.items()):
            common = [row for row in selected if row["schedule"] in {
                "in_flight_late_commit", "stale_negative_after_commit",
            }]
            if any(row["retry_permitted"] for row in common):
                raise ValueError("common-forbidden subset contains a permitted retry")
            summaries[prompt + "/" + evidence] = {
                **outcome_summary(selected),
                "common_forbidden_worlds": outcome_summary(common),
            }
        blocks[name] = {
            "source": str(path.relative_to(root)),
            "source_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            "models": sorted({row["model"] for row in rows}),
            "conditions": summaries,
        }
    return {
        "schema_version": "retrybench-tmlr-reanalysis-v1",
        "analysis_status": "post-hoc descriptive reanalysis; no new model samples",
        "dependence": "Weak responses remain shared across schedules; counts are outcomes, not independent samples.",
        "resolution": "Resolved means the runner received retry or stop, not independently verified knowledge of completion.",
        "blocks": blocks,
    }


def run_matched_framework_audit():
    from .langgraph_adapter import run_langgraph_episode
    from .langchain_adapter import run_langchain_episode

    rows = []
    for framework, runner, policy_name, completion_key in (
        ("langgraph", run_langgraph_episode, "langgraph_default_retry_policy", "graph_completed"),
        ("langchain", run_langchain_episode, "langchain_exception_retry", "runnable_completed"),
    ):
        for response in ("returned", "lost"):
            for policy in ("no_retry", policy_name, "stable_idempotency_retry"):
                for task in TASKS:
                    for schedule in Schedule:
                        row = runner(task, schedule, policy, retry_response=response).to_dict()
                        row.update({
                            "retry_response": response,
                            "framework_key": framework,
                            "completed": row[completion_key],
                            "ledger_correct": ledger_correct(row),
                        })
                        rows.append(row)
    groups = defaultdict(list)
    for row in rows:
        groups[(row["framework_key"], row["retry_response"], row["policy"])].append(row)
    summaries = {}
    for (framework, response, policy), selected in sorted(groups.items()):
        summaries["/".join((framework, response, policy))] = {
            "episodes": len(selected),
            **{key: sum(row[key] for row in selected) for key in (
                "completed", "ledger_correct", "duplicate_effect", "omission",
                "unresolved", "exact_state_success", "retries",
            )},
        }
    report = {
        "schema_version": "retrybench-matched-framework-v2",
        "episodes": len(rows),
        "versions": {row["framework"]: row["framework_version"] for row in rows},
        "response_schedules": ["returned", "lost"],
        "design": "Original response always lost; second response schedule identical for protected and unprotected retries in both runtimes.",
        "api_calls": 0,
        "by_condition": summaries,
    }
    return report, rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path("."))
    parser.add_argument("--frameworks", action="store_true")
    args = parser.parse_args()
    root = args.root.resolve()
    if args.frameworks:
        directory = root / "runs/framework-matched-v2"
        report, rows = run_matched_framework_audit()
        write_jsonl(directory / "outcomes.jsonl", rows)
        report["outcomes_sha256"] = hashlib.sha256((directory / "outcomes.jsonl").read_bytes()).hexdigest()
        write_json(directory / "analysis.json", report)
    else:
        write_json(root / "runs/tmlr-reanalysis-v1/analysis.json", reanalyze_archives(root))


if __name__ == "__main__":
    main()
