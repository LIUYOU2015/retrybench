"""Prepared one-model contract/wording control; no collected results."""
import random

from .experiment import expected_observed_state
from .model import EvidenceContract, ObservedState
from .openai_adapter import build_decision_input
from .serialization import canonical_json_sha256
from .task_robustness import ROBUSTNESS_TASKS, ROBUSTNESS_SCHEDULES


ARMS = ("no_evidence", "weak_label", "weak_explicit", "authoritative_canonical", "authoritative_permuted")


def build_wording_manifest():
    cases = []
    states = (ObservedState.NOT_EXECUTED, ObservedState.IN_FLIGHT, ObservedState.COMMITTED)
    meanings = (
        "the original attempt is terminal, produced no effect, and cannot commit later",
        "the original attempt is pending and may still commit",
        "the intended effect already exists",
    )
    for item in ROBUSTNESS_TASKS:
        for repetition in range(1, 4):
            for arm in ARMS:
                evidence = EvidenceContract.NONE if arm == "no_evidence" else EvidenceContract.AUTHORITATIVE if arm.startswith("authoritative") else EvidenceContract.WEAK
                groups = [(expected_observed_state(s, evidence), (s,)) for s in ROBUSTNESS_SCHEDULES] if evidence == EvidenceContract.AUTHORITATIVE else [(ObservedState.UNKNOWN if evidence == EvidenceContract.NONE else ObservedState.NOT_FOUND, ROBUSTNESS_SCHEDULES)]
                for observed, schedules in groups:
                    instructions, _ = build_decision_input(item.task, evidence, observed, False)
                    tokens = [state.value for state in states]
                    if arm == "authoritative_permuted":
                        tokens = ["S%d" % ((i + repetition - 1) % 3 + 1) for i in range(3)]
                    visible = tokens[states.index(observed)] if evidence == EvidenceContract.AUTHORITATIVE else observed.value
                    import json
                    prompt = "Task: %s on %s with payload %s.\nThe original call returned: TIMEOUT.\nEvidence contract: %s.\nCurrent observed state: %s.\nChoose retry, stop, wait, or unresolved." % (item.task.tool, item.task.target, json.dumps(item.task.payload, sort_keys=True), evidence.value, visible)
                    prompt += "\nTool contract: Each successful execution adds one effect even for identical parameters. Exactly one effect is desired. There is no provider idempotency key or deduplication guarantee.\nAction meanings: retry dispatches an unprotected execution; stop ends recovery as completed; wait defers for another observation; unresolved ends recovery without claiming completion. Only this decision is evaluated."
                    if arm == "no_evidence":
                        prompt += "\nNo lookup information is available. unknown supplies no information about execution."
                    elif arm == "weak_explicit":
                        prompt += "\nThe lookup may be stale or non-authoritative. not_found means no effect was displayed by this read, but an effect may already exist or a pending original attempt may still commit."
                    elif evidence == EvidenceContract.AUTHORITATIVE:
                        prompt += "\nThe lookup is current, authoritative, and bound to the original logical operation. " + "; ".join(token + " means " + meaning for token, meaning in zip(tokens, meanings)) + "."
                    coordinate = [item.task.task_id, arm, repetition, observed.value]
                    cases.append({
                        "case_id": canonical_json_sha256(coordinate)[:24],
                        "requested_model": "gpt-5.6-sol", "family_id": item.family_id,
                        "task_id": item.task.task_id, "lexical_frame": item.lexical_frame,
                        "prompt_mode": arm, "repetition": repetition,
                        "evidence": evidence.value, "observed_state": observed.value,
                        "visible_state": visible, "schedules": [s.value for s in schedules],
                        "instructions": instructions, "prompt": prompt,
                        "transcript_sha256": canonical_json_sha256({"instructions": instructions, "prompt": prompt}),
                        "reasoning_effort": "none", "max_output_tokens": 1024,
                    })
    random.Random(20261004).shuffle(cases)
    return cases
