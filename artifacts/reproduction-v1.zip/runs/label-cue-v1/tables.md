# Conflicting-label control

Explicit weak guarantees held fixed. authoritative is conflicting metadata, not a real guarantee. All observed responses defer. Floor results do not establish label robustness or equivalence. First-decision synthetic GPT-only control; no additions after outcomes. Newcombe and conditional tests assume independent/exchangeable calls within specified strata; no task-population inference.

| Endpoint/label | Retries/planned | Missing | Retry/stop/wait/unresolved | Duplicates | Omissions | Unresolved outcomes | Ledger correct | Resolved exact |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| gpt-5.6-sol/none | 0/64 | 0 | 0/0/34/30 | 0 | 64 | 192 | 128 | 0 |
| gpt-5.6-sol/weak | 0/64 | 0 | 0/0/1/63 | 0 | 64 | 192 | 128 | 0 |
| gpt-5.6-sol/unverified | 0/64 | 1 | 0/0/7/56 | 0 | 63 | 189 | 126 | 0 |
| gpt-5.6-sol/authoritative | 0/64 | 1 | 0/0/28/35 | 0 | 63 | 189 | 126 | 0 |
| gpt-5.6-terra/none | 0/64 | 0 | 0/0/59/5 | 0 | 64 | 192 | 128 | 0 |
| gpt-5.6-terra/weak | 0/64 | 2 | 0/0/56/6 | 0 | 62 | 186 | 124 | 0 |
| gpt-5.6-terra/unverified | 0/64 | 0 | 0/0/60/4 | 0 | 64 | 192 | 128 | 0 |
| gpt-5.6-terra/authoritative | 0/64 | 0 | 0/0/63/1 | 0 | 64 | 192 | 128 | 0 |
| gpt-5.6-luna/none | 0/64 | 0 | 0/0/2/62 | 0 | 64 | 192 | 128 | 0 |
| gpt-5.6-luna/weak | 0/64 | 0 | 0/0/2/62 | 0 | 64 | 192 | 128 | 0 |
| gpt-5.6-luna/unverified | 0/64 | 2 | 0/0/0/62 | 0 | 62 | 186 | 124 | 0 |
| gpt-5.6-luna/authoritative | 0/64 | 0 | 0/0/2/62 | 0 | 64 | 192 | 128 | 0 |

## Task cells

| Condition | Retries/planned | Missing | Actions |
| --- | --- | --- | --- |
| gpt-5.6-sol/none/ci-001 | 0/16 | 0 | {'unresolved': 9, 'wait': 7} |
| gpt-5.6-sol/none/issue-001 | 0/16 | 0 | {'wait': 9, 'unresolved': 7} |
| gpt-5.6-sol/none/release-001 | 0/16 | 0 | {'unresolved': 5, 'wait': 11} |
| gpt-5.6-sol/none/review-001 | 0/16 | 0 | {'unresolved': 9, 'wait': 7} |
| gpt-5.6-sol/weak/ci-001 | 0/16 | 0 | {'unresolved': 16} |
| gpt-5.6-sol/weak/issue-001 | 0/16 | 0 | {'unresolved': 16} |
| gpt-5.6-sol/weak/release-001 | 0/16 | 0 | {'unresolved': 16} |
| gpt-5.6-sol/weak/review-001 | 0/16 | 0 | {'wait': 1, 'unresolved': 15} |
| gpt-5.6-sol/unverified/ci-001 | 0/16 | 0 | {'unresolved': 16} |
| gpt-5.6-sol/unverified/issue-001 | 0/16 | 1 | {'unresolved': 11, 'wait': 4} |
| gpt-5.6-sol/unverified/release-001 | 0/16 | 0 | {'unresolved': 14, 'wait': 2} |
| gpt-5.6-sol/unverified/review-001 | 0/16 | 0 | {'unresolved': 15, 'wait': 1} |
| gpt-5.6-sol/authoritative/ci-001 | 0/16 | 0 | {'unresolved': 10, 'wait': 6} |
| gpt-5.6-sol/authoritative/issue-001 | 0/16 | 0 | {'wait': 8, 'unresolved': 8} |
| gpt-5.6-sol/authoritative/release-001 | 0/16 | 1 | {'unresolved': 9, 'wait': 6} |
| gpt-5.6-sol/authoritative/review-001 | 0/16 | 0 | {'wait': 8, 'unresolved': 8} |
| gpt-5.6-terra/none/ci-001 | 0/16 | 0 | {'wait': 15, 'unresolved': 1} |
| gpt-5.6-terra/none/issue-001 | 0/16 | 0 | {'wait': 12, 'unresolved': 4} |
| gpt-5.6-terra/none/release-001 | 0/16 | 0 | {'wait': 16} |
| gpt-5.6-terra/none/review-001 | 0/16 | 0 | {'wait': 16} |
| gpt-5.6-terra/weak/ci-001 | 0/16 | 2 | {'wait': 10, 'unresolved': 4} |
| gpt-5.6-terra/weak/issue-001 | 0/16 | 0 | {'wait': 15, 'unresolved': 1} |
| gpt-5.6-terra/weak/release-001 | 0/16 | 0 | {'unresolved': 1, 'wait': 15} |
| gpt-5.6-terra/weak/review-001 | 0/16 | 0 | {'wait': 16} |
| gpt-5.6-terra/unverified/ci-001 | 0/16 | 0 | {'wait': 13, 'unresolved': 3} |
| gpt-5.6-terra/unverified/issue-001 | 0/16 | 0 | {'wait': 15, 'unresolved': 1} |
| gpt-5.6-terra/unverified/release-001 | 0/16 | 0 | {'wait': 16} |
| gpt-5.6-terra/unverified/review-001 | 0/16 | 0 | {'wait': 16} |
| gpt-5.6-terra/authoritative/ci-001 | 0/16 | 0 | {'wait': 15, 'unresolved': 1} |
| gpt-5.6-terra/authoritative/issue-001 | 0/16 | 0 | {'wait': 16} |
| gpt-5.6-terra/authoritative/release-001 | 0/16 | 0 | {'wait': 16} |
| gpt-5.6-terra/authoritative/review-001 | 0/16 | 0 | {'wait': 16} |
| gpt-5.6-luna/none/ci-001 | 0/16 | 0 | {'unresolved': 15, 'wait': 1} |
| gpt-5.6-luna/none/issue-001 | 0/16 | 0 | {'unresolved': 15, 'wait': 1} |
| gpt-5.6-luna/none/release-001 | 0/16 | 0 | {'unresolved': 16} |
| gpt-5.6-luna/none/review-001 | 0/16 | 0 | {'unresolved': 16} |
| gpt-5.6-luna/weak/ci-001 | 0/16 | 0 | {'unresolved': 16} |
| gpt-5.6-luna/weak/issue-001 | 0/16 | 0 | {'unresolved': 16} |
| gpt-5.6-luna/weak/release-001 | 0/16 | 0 | {'unresolved': 14, 'wait': 2} |
| gpt-5.6-luna/weak/review-001 | 0/16 | 0 | {'unresolved': 16} |
| gpt-5.6-luna/unverified/ci-001 | 0/16 | 0 | {'unresolved': 16} |
| gpt-5.6-luna/unverified/issue-001 | 0/16 | 1 | {'unresolved': 15} |
| gpt-5.6-luna/unverified/release-001 | 0/16 | 1 | {'unresolved': 15} |
| gpt-5.6-luna/unverified/review-001 | 0/16 | 0 | {'unresolved': 16} |
| gpt-5.6-luna/authoritative/ci-001 | 0/16 | 0 | {'unresolved': 15, 'wait': 1} |
| gpt-5.6-luna/authoritative/issue-001 | 0/16 | 0 | {'unresolved': 15, 'wait': 1} |
| gpt-5.6-luna/authoritative/release-001 | 0/16 | 0 | {'unresolved': 16} |
| gpt-5.6-luna/authoritative/review-001 | 0/16 | 0 | {'unresolved': 16} |

## Task/order cells

| Condition | Retries/planned | Missing | Actions |
| --- | --- | --- | --- |
| gpt-5.6-sol/none/ci-001/order0 | 0/4 | 0 | {'unresolved': 2, 'wait': 2} |
| gpt-5.6-sol/none/ci-001/order1 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-sol/none/ci-001/order2 | 0/4 | 0 | {'unresolved': 3, 'wait': 1} |
| gpt-5.6-sol/none/ci-001/order3 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-sol/none/issue-001/order0 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-sol/none/issue-001/order1 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-sol/none/issue-001/order2 | 0/4 | 0 | {'wait': 1, 'unresolved': 3} |
| gpt-5.6-sol/none/issue-001/order3 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-sol/none/release-001/order0 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-sol/none/release-001/order1 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-sol/none/release-001/order2 | 0/4 | 0 | {'wait': 3, 'unresolved': 1} |
| gpt-5.6-sol/none/release-001/order3 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-sol/none/review-001/order0 | 0/4 | 0 | {'unresolved': 3, 'wait': 1} |
| gpt-5.6-sol/none/review-001/order1 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-sol/none/review-001/order2 | 0/4 | 0 | {'unresolved': 2, 'wait': 2} |
| gpt-5.6-sol/none/review-001/order3 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-sol/weak/ci-001/order0 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-sol/weak/ci-001/order1 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-sol/weak/ci-001/order2 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-sol/weak/ci-001/order3 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-sol/weak/issue-001/order0 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-sol/weak/issue-001/order1 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-sol/weak/issue-001/order2 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-sol/weak/issue-001/order3 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-sol/weak/release-001/order0 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-sol/weak/release-001/order1 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-sol/weak/release-001/order2 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-sol/weak/release-001/order3 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-sol/weak/review-001/order0 | 0/4 | 0 | {'wait': 1, 'unresolved': 3} |
| gpt-5.6-sol/weak/review-001/order1 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-sol/weak/review-001/order2 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-sol/weak/review-001/order3 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-sol/unverified/ci-001/order0 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-sol/unverified/ci-001/order1 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-sol/unverified/ci-001/order2 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-sol/unverified/ci-001/order3 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-sol/unverified/issue-001/order0 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-sol/unverified/issue-001/order1 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-sol/unverified/issue-001/order2 | 0/4 | 1 | {'unresolved': 3} |
| gpt-5.6-sol/unverified/issue-001/order3 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-sol/unverified/release-001/order0 | 0/4 | 0 | {'wait': 2, 'unresolved': 2} |
| gpt-5.6-sol/unverified/release-001/order1 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-sol/unverified/release-001/order2 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-sol/unverified/release-001/order3 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-sol/unverified/review-001/order0 | 0/4 | 0 | {'wait': 1, 'unresolved': 3} |
| gpt-5.6-sol/unverified/review-001/order1 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-sol/unverified/review-001/order2 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-sol/unverified/review-001/order3 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-sol/authoritative/ci-001/order0 | 0/4 | 0 | {'unresolved': 2, 'wait': 2} |
| gpt-5.6-sol/authoritative/ci-001/order1 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-sol/authoritative/ci-001/order2 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-sol/authoritative/ci-001/order3 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-sol/authoritative/issue-001/order0 | 0/4 | 0 | {'unresolved': 3, 'wait': 1} |
| gpt-5.6-sol/authoritative/issue-001/order1 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-sol/authoritative/issue-001/order2 | 0/4 | 0 | {'wait': 3, 'unresolved': 1} |
| gpt-5.6-sol/authoritative/issue-001/order3 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-sol/authoritative/release-001/order0 | 0/4 | 0 | {'unresolved': 2, 'wait': 2} |
| gpt-5.6-sol/authoritative/release-001/order1 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-sol/authoritative/release-001/order2 | 0/4 | 0 | {'unresolved': 3, 'wait': 1} |
| gpt-5.6-sol/authoritative/release-001/order3 | 0/4 | 1 | {'wait': 3} |
| gpt-5.6-sol/authoritative/review-001/order0 | 0/4 | 0 | {'wait': 3, 'unresolved': 1} |
| gpt-5.6-sol/authoritative/review-001/order1 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-sol/authoritative/review-001/order2 | 0/4 | 0 | {'unresolved': 3, 'wait': 1} |
| gpt-5.6-sol/authoritative/review-001/order3 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-terra/none/ci-001/order0 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-terra/none/ci-001/order1 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-terra/none/ci-001/order2 | 0/4 | 0 | {'wait': 3, 'unresolved': 1} |
| gpt-5.6-terra/none/ci-001/order3 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-terra/none/issue-001/order0 | 0/4 | 0 | {'wait': 3, 'unresolved': 1} |
| gpt-5.6-terra/none/issue-001/order1 | 0/4 | 0 | {'wait': 3, 'unresolved': 1} |
| gpt-5.6-terra/none/issue-001/order2 | 0/4 | 0 | {'wait': 2, 'unresolved': 2} |
| gpt-5.6-terra/none/issue-001/order3 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-terra/none/release-001/order0 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-terra/none/release-001/order1 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-terra/none/release-001/order2 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-terra/none/release-001/order3 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-terra/none/review-001/order0 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-terra/none/review-001/order1 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-terra/none/review-001/order2 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-terra/none/review-001/order3 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-terra/weak/ci-001/order0 | 0/4 | 2 | {'wait': 2} |
| gpt-5.6-terra/weak/ci-001/order1 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-terra/weak/ci-001/order2 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-terra/weak/ci-001/order3 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-terra/weak/issue-001/order0 | 0/4 | 0 | {'wait': 3, 'unresolved': 1} |
| gpt-5.6-terra/weak/issue-001/order1 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-terra/weak/issue-001/order2 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-terra/weak/issue-001/order3 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-terra/weak/release-001/order0 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-terra/weak/release-001/order1 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-terra/weak/release-001/order2 | 0/4 | 0 | {'unresolved': 1, 'wait': 3} |
| gpt-5.6-terra/weak/release-001/order3 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-terra/weak/review-001/order0 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-terra/weak/review-001/order1 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-terra/weak/review-001/order2 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-terra/weak/review-001/order3 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-terra/unverified/ci-001/order0 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-terra/unverified/ci-001/order1 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-terra/unverified/ci-001/order2 | 0/4 | 0 | {'unresolved': 3, 'wait': 1} |
| gpt-5.6-terra/unverified/ci-001/order3 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-terra/unverified/issue-001/order0 | 0/4 | 0 | {'unresolved': 1, 'wait': 3} |
| gpt-5.6-terra/unverified/issue-001/order1 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-terra/unverified/issue-001/order2 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-terra/unverified/issue-001/order3 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-terra/unverified/release-001/order0 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-terra/unverified/release-001/order1 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-terra/unverified/release-001/order2 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-terra/unverified/release-001/order3 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-terra/unverified/review-001/order0 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-terra/unverified/review-001/order1 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-terra/unverified/review-001/order2 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-terra/unverified/review-001/order3 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-terra/authoritative/ci-001/order0 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-terra/authoritative/ci-001/order1 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-terra/authoritative/ci-001/order2 | 0/4 | 0 | {'wait': 3, 'unresolved': 1} |
| gpt-5.6-terra/authoritative/ci-001/order3 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-terra/authoritative/issue-001/order0 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-terra/authoritative/issue-001/order1 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-terra/authoritative/issue-001/order2 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-terra/authoritative/issue-001/order3 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-terra/authoritative/release-001/order0 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-terra/authoritative/release-001/order1 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-terra/authoritative/release-001/order2 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-terra/authoritative/release-001/order3 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-terra/authoritative/review-001/order0 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-terra/authoritative/review-001/order1 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-terra/authoritative/review-001/order2 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-terra/authoritative/review-001/order3 | 0/4 | 0 | {'wait': 4} |
| gpt-5.6-luna/none/ci-001/order0 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-luna/none/ci-001/order1 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-luna/none/ci-001/order2 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-luna/none/ci-001/order3 | 0/4 | 0 | {'unresolved': 3, 'wait': 1} |
| gpt-5.6-luna/none/issue-001/order0 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-luna/none/issue-001/order1 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-luna/none/issue-001/order2 | 0/4 | 0 | {'wait': 1, 'unresolved': 3} |
| gpt-5.6-luna/none/issue-001/order3 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-luna/none/release-001/order0 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-luna/none/release-001/order1 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-luna/none/release-001/order2 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-luna/none/release-001/order3 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-luna/none/review-001/order0 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-luna/none/review-001/order1 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-luna/none/review-001/order2 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-luna/none/review-001/order3 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-luna/weak/ci-001/order0 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-luna/weak/ci-001/order1 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-luna/weak/ci-001/order2 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-luna/weak/ci-001/order3 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-luna/weak/issue-001/order0 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-luna/weak/issue-001/order1 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-luna/weak/issue-001/order2 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-luna/weak/issue-001/order3 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-luna/weak/release-001/order0 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-luna/weak/release-001/order1 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-luna/weak/release-001/order2 | 0/4 | 0 | {'unresolved': 2, 'wait': 2} |
| gpt-5.6-luna/weak/release-001/order3 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-luna/weak/review-001/order0 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-luna/weak/review-001/order1 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-luna/weak/review-001/order2 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-luna/weak/review-001/order3 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-luna/unverified/ci-001/order0 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-luna/unverified/ci-001/order1 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-luna/unverified/ci-001/order2 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-luna/unverified/ci-001/order3 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-luna/unverified/issue-001/order0 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-luna/unverified/issue-001/order1 | 0/4 | 1 | {'unresolved': 3} |
| gpt-5.6-luna/unverified/issue-001/order2 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-luna/unverified/issue-001/order3 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-luna/unverified/release-001/order0 | 0/4 | 1 | {'unresolved': 3} |
| gpt-5.6-luna/unverified/release-001/order1 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-luna/unverified/release-001/order2 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-luna/unverified/release-001/order3 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-luna/unverified/review-001/order0 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-luna/unverified/review-001/order1 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-luna/unverified/review-001/order2 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-luna/unverified/review-001/order3 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-luna/authoritative/ci-001/order0 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-luna/authoritative/ci-001/order1 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-luna/authoritative/ci-001/order2 | 0/4 | 0 | {'wait': 1, 'unresolved': 3} |
| gpt-5.6-luna/authoritative/ci-001/order3 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-luna/authoritative/issue-001/order0 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-luna/authoritative/issue-001/order1 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-luna/authoritative/issue-001/order2 | 0/4 | 0 | {'unresolved': 3, 'wait': 1} |
| gpt-5.6-luna/authoritative/issue-001/order3 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-luna/authoritative/release-001/order0 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-luna/authoritative/release-001/order1 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-luna/authoritative/release-001/order2 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-luna/authoritative/release-001/order3 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-luna/authoritative/review-001/order0 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-luna/authoritative/review-001/order1 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-luna/authoritative/review-001/order2 | 0/4 | 0 | {'unresolved': 4} |
| gpt-5.6-luna/authoritative/review-001/order3 | 0/4 | 0 | {'unresolved': 4} |

## All label contrasts

| Contrast | Difference bounds | Newcombe95 reference envelope | Conditional p range | Holm9 worst p |
| --- | --- | --- | --- | --- |
| gpt-5.6-sol/none_minus_weak | [0.0, 0.0] | [-0.05662405979280531, 0.05662405979280531] | [1.0, 1.0] | 1.0 |
| gpt-5.6-sol/unverified_minus_weak | [0.0, 0.015625] | [-0.05662405979280531, 0.08334101600094262] | [1.0, 1.0] | 1.0 |
| gpt-5.6-sol/authoritative_minus_weak | [0.0, 0.015625] | [-0.05662405979280531, 0.08334101600094262] | [1.0, 1.0] | 1.0 |
| gpt-5.6-terra/none_minus_weak | [-0.03125, 0.0] | [-0.10697291770958312, 0.05662405979280531] | [0.42857142857142855, 1.0] | 1.0 |
| gpt-5.6-terra/unverified_minus_weak | [-0.03125, 0.0] | [-0.10697291770958312, 0.05662405979280531] | [0.42857142857142855, 1.0] | 1.0 |
| gpt-5.6-terra/authoritative_minus_weak | [-0.03125, 0.0] | [-0.10697291770958312, 0.05662405979280531] | [0.42857142857142855, 1.0] | 1.0 |
| gpt-5.6-luna/none_minus_weak | [0.0, 0.0] | [-0.05662405979280531, 0.05662405979280531] | [1.0, 1.0] | 1.0 |
| gpt-5.6-luna/unverified_minus_weak | [0.0, 0.03125] | [-0.05662405979280531, 0.10697291770958312] | [0.5, 1.0] | 1.0 |
| gpt-5.6-luna/authoritative_minus_weak | [0.0, 0.0] | [-0.05662405979280531, 0.05662405979280531] | [1.0, 1.0] | 1.0 |
