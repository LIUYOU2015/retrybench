| Endpoint | Reasoning | Weak retries | Authoritative unsupported retries | Weak outcomes: D/O/U/L/E (n=60) |
| --- | --- | --- | --- | --- |
| gpt-5.4-mini-2026-03-17 | none | 20/20 | 5/60 | 40/0/0/20/20 |
| gpt-5.4-2026-03-05 | none | 10/20 | 0/60 | 20/10/30/30/10 |
| gpt-5.6-sol | none | 0/20 | 0/60 | 0/20/60/40/0 |
| gpt-5.6-sol | low | 0/20 | 0/60 | 0/20/60/40/0 |

| Task | Mini historical | Mini bridge | 5.4 historical | 5.4 bridge | Sol none | Sol low |
| --- | --- | --- | --- | --- | --- | --- |
| ci-001 | 1.00 | 1.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| issue-001 | 1.00 | 1.00 | 1.00 | 1.00 | 0.00 | 0.00 |
| release-001 | 1.00 | 1.00 | 1.00 | 1.00 | 0.00 | 0.00 |
| review-001 | 0.40 | 1.00 | 0.00 | 0.00 | 0.00 | 0.00 |

### State-level actions

| Condition | Visible state | Responses | Retry/stop/wait/unresolved |
| --- | --- | --- | --- |
| gpt-5.4-2026-03-05/none/authoritative | committed | 20 | 0/14/1/5 |
| gpt-5.4-2026-03-05/none/authoritative | in_flight | 20 | 0/0/20/0 |
| gpt-5.4-2026-03-05/none/authoritative | not_executed | 20 | 20/0/0/0 |
| gpt-5.4-2026-03-05/none/weak | not_found | 20 | 10/0/0/10 |
| gpt-5.4-mini-2026-03-17/none/authoritative | committed | 20 | 5/15/0/0 |
| gpt-5.4-mini-2026-03-17/none/authoritative | in_flight | 20 | 0/0/20/0 |
| gpt-5.4-mini-2026-03-17/none/authoritative | not_executed | 20 | 20/0/0/0 |
| gpt-5.4-mini-2026-03-17/none/weak | not_found | 20 | 20/0/0/0 |
| gpt-5.6-sol/low/authoritative | committed | 20 | 0/20/0/0 |
| gpt-5.6-sol/low/authoritative | in_flight | 20 | 0/0/20/0 |
| gpt-5.6-sol/low/authoritative | not_executed | 20 | 20/0/0/0 |
| gpt-5.6-sol/low/weak | not_found | 20 | 0/0/1/19 |
| gpt-5.6-sol/none/authoritative | committed | 20 | 0/20/0/0 |
| gpt-5.6-sol/none/authoritative | in_flight | 20 | 0/0/20/0 |
| gpt-5.6-sol/none/authoritative | not_executed | 20 | 20/0/0/0 |
| gpt-5.6-sol/none/weak | not_found | 20 | 0/0/0/20 |

### Complete outcome vectors

| Condition | Outcomes | FRP | Duplicates | Omissions | Unresolved | Ledger correct | Resolved exact |
| --- | --- | --- | --- | --- | --- | --- | --- |
| gpt-5.4-2026-03-05/none/authoritative | 60 | 0 | 0 | 0 | 26 | 60 | 34 |
| gpt-5.4-2026-03-05/none/weak | 60 | 30 | 20 | 10 | 30 | 30 | 10 |
| gpt-5.4-mini-2026-03-17/none/authoritative | 60 | 5 | 5 | 0 | 20 | 55 | 35 |
| gpt-5.4-mini-2026-03-17/none/weak | 60 | 60 | 40 | 0 | 0 | 20 | 20 |
| gpt-5.6-sol/low/authoritative | 60 | 0 | 0 | 0 | 20 | 60 | 40 |
| gpt-5.6-sol/low/weak | 60 | 0 | 0 | 20 | 60 | 40 | 0 |
| gpt-5.6-sol/none/authoritative | 60 | 0 | 0 | 0 | 20 | 60 | 40 |
| gpt-5.6-sol/none/weak | 60 | 0 | 0 | 20 | 60 | 40 | 0 |
