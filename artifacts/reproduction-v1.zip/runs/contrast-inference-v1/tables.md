# Difference intervals and interaction diagnostics

Intervals use Wilson-MOVER (Newcombe for two arms), with feasible missing-action assignments enumerated. They are approximate independent-binomial references, not demonstrated coverage for heterogeneous or dependent API calls. Exact doubled-tail conditional tests stratify label contrasts by task×order×mapping, and key contrasts by task; calls are not paired by repetition number. These test conditional odds-ratio=1, not the equal-task risk-difference estimand. Risk-difference interaction is (coded U−L)−(canonical U−L); its MOVER p is obtained by interval inversion. Holm uses worst-case p bounds in separate12-label/6-interaction families. All other comparisons are exploratory, unadjusted. No task-population inference.

## Historical label contrasts

| Endpoint/representation | Difference bounds (pp) | 95% Newcombe reference envelope (pp) | Exact stratified p range | Holm12 worst-case p |
| --- | --- | --- | --- | --- |
| gpt-5.4-2026-03-05/canonical/label_removal | [3.12, 3.12] | [-17.44, 23.38] | [1.0, 1.0] | 1 |
| gpt-5.4-2026-03-05/coded/label_removal | [7.81, 9.38] | [-4.10, 20.97] | [0.025169230037992124, 0.06411897957473364] | 0.64119 |
| gpt-5.4-mini-2026-03-17/canonical/label_removal | [-6.25, -6.25] | [-23.51, 10.99] | [0.6666666666666667, 0.6666666666666667] | 1 |
| gpt-5.4-mini-2026-03-17/coded/label_removal | [2.34, 3.91] | [-7.05, 13.25] | [0.43506835059701, 0.7003477706340113] | 1 |
| gpt-5.6-luna/canonical/label_removal | [-15.62, -12.50] | [-36.00, 9.41] | [0.1423611111111111, 0.23958333333333331] | 1 |
| gpt-5.6-luna/coded/label_removal | [0.00, 0.78] | [-12.07, 12.83] | [0.9999999999999998, 1.0] | 1 |
| gpt-5.6-sol/canonical/label_removal | [3.12, 6.25] | [-10.28, 20.15] | [0.5, 1.0] | 1 |
| gpt-5.6-sol/coded/label_removal | [20.31, 21.09] | [13.21, 28.95] | [3.876133989356296e-10, 9.108914874987296e-09] | 1.0931e-07 |
| gpt-5.6-terra/canonical/label_removal | [9.38, 9.38] | [-2.97, 24.22] | [0.16666666666666666, 0.16666666666666666] | 1 |
| gpt-5.6-terra/coded/label_removal | [19.53, 21.09] | [9.28, 30.93] | [2.9710361641541925e-06, 1.779440828513023e-05] | 0.00019574 |
| gpt-6-astra/canonical/label_removal | [0.00, 3.12] | [-10.72, 15.74] | [1.0, 1.0] | 1 |
| gpt-6-astra/coded/label_removal | [-2.34, 0.78] | [-6.66, 4.29] | [0.25, 1.0] | 1 |

## Risk-difference interactions

| Endpoint | Coded−canonical label effect (pp) | 95% MOVER reference envelope (pp) | Reference p range | Holm6 worst-case p |
| --- | --- | --- | --- | --- |
| gpt-5.4-2026-03-05 | [4.69, 6.25] | [-18.81, 29.86] | [0.6082731018261693, 0.7006402374385148] | 1 |
| gpt-5.4-mini-2026-03-17 | [8.59, 10.16] | [-11.03, 29.78] | [0.29337563821763585, 0.37166826739283915] | 1 |
| gpt-5.6-luna | [12.50, 16.41] | [-12.51, 40.08] | [0.20740168370994064, 0.33094293027569976] | 1 |
| gpt-5.6-sol | [14.06, 17.97] | [-1.54, 33.51] | [0.02921902047209586, 0.07076595113960768] | 0.4246 |
| gpt-5.6-terra | [10.16, 11.72] | [-7.88, 27.51] | [0.1761190984431467, 0.23089118579779894] | 1 |
| gpt-6-astra | [-5.47, 0.78] | [-18.81, 12.06] | [0.20791292860685734, 1.0] | 1 |

## All historical contrasts

| Contrast | Difference bounds (pp) | 95% Newcombe reference envelope (pp) | Exact conditional p range |
| --- | --- | --- | --- |
| gpt-5.4-2026-03-05/canonical/label_removal | [3.12, 3.12] | [-17.44, 23.38] | [1.0, 1.0] |
| gpt-5.4-2026-03-05/canonical/mapping0/order0/label_removal | [12.50, 12.50] | [-30.28, 49.62] | [1.0, 1.0] |
| gpt-5.4-2026-03-05/canonical/mapping0/order1/label_removal | [0.00, 0.00] | [-36.08, 36.08] | [1.0, 1.0] |
| gpt-5.4-2026-03-05/canonical/mapping0/order2/label_removal | [0.00, 0.00] | [-38.47, 38.47] | [1.0, 1.0] |
| gpt-5.4-2026-03-05/canonical/mapping0/order3/label_removal | [0.00, 0.00] | [-32.44, 32.44] | [1.0, 1.0] |
| gpt-5.4-2026-03-05/coded/label_removal | [7.81, 9.38] | [-4.10, 20.97] | [0.025169230037992124, 0.06411897957473364] |
| gpt-5.4-2026-03-05/coded/mapping0/order0/label_removal | [0.00, 0.00] | [-38.47, 38.47] | [1.0, 1.0] |
| gpt-5.4-2026-03-05/coded/mapping0/order1/label_removal | [12.50, 12.50] | [-30.28, 49.62] | [1.0, 1.0] |
| gpt-5.4-2026-03-05/coded/mapping0/order2/label_removal | [-12.50, -12.50] | [-49.62, 30.28] | [1.0, 1.0] |
| gpt-5.4-2026-03-05/coded/mapping0/order3/label_removal | [0.00, 0.00] | [-32.44, 32.44] | [1.0, 1.0] |
| gpt-5.4-2026-03-05/coded/mapping1/order0/label_removal | [0.00, 0.00] | [-38.47, 38.47] | [1.0, 1.0] |
| gpt-5.4-2026-03-05/coded/mapping1/order1/label_removal | [37.50, 37.50] | [-7.30, 67.77] | [0.16666666666666666, 0.16666666666666666] |
| gpt-5.4-2026-03-05/coded/mapping1/order2/label_removal | [0.00, 0.00] | [-39.83, 39.83] | [1.0, 1.0] |
| gpt-5.4-2026-03-05/coded/mapping1/order3/label_removal | [12.50, 12.50] | [-21.52, 47.09] | [1.0, 1.0] |
| gpt-5.4-2026-03-05/coded/mapping2/order0/label_removal | [0.00, 0.00] | [-32.44, 32.44] | [1.0, 1.0] |
| gpt-5.4-2026-03-05/coded/mapping2/order1/label_removal | [25.00, 25.00] | [-20.15, 58.68] | [0.5, 0.5] |
| gpt-5.4-2026-03-05/coded/mapping2/order2/label_removal | [50.00, 50.00] | [6.83, 78.48] | [0.05555555555555555, 0.05555555555555555] |
| gpt-5.4-2026-03-05/coded/mapping2/order3/label_removal | [-25.00, -12.50] | [-58.53, 29.07] | [0.5, 0.9999999999999999] |
| gpt-5.4-2026-03-05/coded/mapping3/order0/label_removal | [-12.50, -12.50] | [-49.62, 30.28] | [1.0, 1.0] |
| gpt-5.4-2026-03-05/coded/mapping3/order1/label_removal | [12.50, 12.50] | [-29.07, 49.08] | [0.9999999999999999, 0.9999999999999999] |
| gpt-5.4-2026-03-05/coded/mapping3/order2/label_removal | [50.00, 62.50] | [6.83, 86.32] | [0.027777777777777776, 0.05555555555555555] |
| gpt-5.4-2026-03-05/coded/mapping3/order3/label_removal | [-25.00, -25.00] | [-59.07, 12.03] | [0.3333333333333333, 0.3333333333333333] |
| gpt-5.4-2026-03-05/historical_anchor/label_removal | [12.50, 12.50] | [-30.28, 49.62] | [1.0, 1.0] |
| gpt-5.4-2026-03-05/labeled/coded_minus_canonical | [-19.53, -17.97] | [-34.12, 1.02] | [0.013630247231107276, 0.020952953736120578] |
| gpt-5.4-2026-03-05/labeled/order1_minus_order0 | [50.00, 50.00] | [2.93, 75.93] | [0.08333333333333333, 0.08333333333333333] |
| gpt-5.4-2026-03-05/labeled/order2_minus_order0 | [37.50, 37.50] | [-9.19, 67.26] | [0.25, 0.25] |
| gpt-5.4-2026-03-05/labeled/order3_minus_order0 | [62.50, 62.50] | [16.98, 86.32] | [0.027777777777777776, 0.027777777777777776] |
| gpt-5.4-2026-03-05/unlabeled/coded_minus_canonical | [-13.28, -13.28] | [-27.12, 5.28] | [0.0862909566506461, 0.0862909566506461] |
| gpt-5.4-2026-03-05/unlabeled/order1_minus_order0 | [37.50, 37.50] | [-7.30, 67.77] | [0.16666666666666666, 0.16666666666666666] |
| gpt-5.4-2026-03-05/unlabeled/order2_minus_order0 | [25.00, 25.00] | [-19.41, 58.61] | [0.5, 0.5] |
| gpt-5.4-2026-03-05/unlabeled/order3_minus_order0 | [50.00, 50.00] | [6.83, 78.48] | [0.05555555555555555, 0.05555555555555555] |
| gpt-5.4-mini-2026-03-17/canonical/label_removal | [-6.25, -6.25] | [-23.51, 10.99] | [0.6666666666666667, 0.6666666666666667] |
| gpt-5.4-mini-2026-03-17/canonical/mapping0/order0/label_removal | [-12.50, -12.50] | [-48.08, 26.42] | [1.0, 1.0] |
| gpt-5.4-mini-2026-03-17/canonical/mapping0/order1/label_removal | [12.50, 12.50] | [-26.42, 48.08] | [0.9999999999999999, 0.9999999999999999] |
| gpt-5.4-mini-2026-03-17/canonical/mapping0/order2/label_removal | [-12.50, -12.50] | [-47.09, 21.52] | [1.0, 1.0] |
| gpt-5.4-mini-2026-03-17/canonical/mapping0/order3/label_removal | [-12.50, -12.50] | [-47.09, 21.52] | [1.0, 1.0] |
| gpt-5.4-mini-2026-03-17/coded/label_removal | [2.34, 3.91] | [-7.05, 13.25] | [0.43506835059701, 0.7003477706340113] |
| gpt-5.4-mini-2026-03-17/coded/mapping0/order0/label_removal | [25.00, 25.00] | [-12.03, 59.07] | [0.5, 0.5] |
| gpt-5.4-mini-2026-03-17/coded/mapping0/order1/label_removal | [0.00, 0.00] | [-38.47, 38.47] | [1.0, 1.0] |
| gpt-5.4-mini-2026-03-17/coded/mapping0/order2/label_removal | [12.50, 12.50] | [-21.52, 47.09] | [1.0, 1.0] |
| gpt-5.4-mini-2026-03-17/coded/mapping0/order3/label_removal | [-37.50, -37.50] | [-67.77, 7.30] | [0.16666666666666666, 0.16666666666666666] |
| gpt-5.4-mini-2026-03-17/coded/mapping1/order0/label_removal | [-12.50, -12.50] | [-48.08, 26.42] | [1.0, 1.0] |
| gpt-5.4-mini-2026-03-17/coded/mapping1/order1/label_removal | [12.50, 12.50] | [-29.07, 49.08] | [0.9999999999999999, 0.9999999999999999] |
| gpt-5.4-mini-2026-03-17/coded/mapping1/order2/label_removal | [50.00, 62.50] | [6.83, 86.32] | [0.027777777777777776, 0.08333333333333333] |
| gpt-5.4-mini-2026-03-17/coded/mapping1/order3/label_removal | [0.00, 0.00] | [-36.08, 36.08] | [1.0, 1.0] |
| gpt-5.4-mini-2026-03-17/coded/mapping2/order0/label_removal | [0.00, 12.50] | [-36.08, 47.09] | [1.0, 1.0] |
| gpt-5.4-mini-2026-03-17/coded/mapping2/order1/label_removal | [37.50, 37.50] | [-9.19, 67.26] | [0.25, 0.25] |
| gpt-5.4-mini-2026-03-17/coded/mapping2/order2/label_removal | [0.00, 0.00] | [-32.44, 32.44] | [1.0, 1.0] |
| gpt-5.4-mini-2026-03-17/coded/mapping2/order3/label_removal | [-37.50, -37.50] | [-69.43, 2.74] | [0.16666666666666666, 0.16666666666666666] |
| gpt-5.4-mini-2026-03-17/coded/mapping3/order0/label_removal | [-12.50, -12.50] | [-47.09, 21.52] | [1.0, 1.0] |
| gpt-5.4-mini-2026-03-17/coded/mapping3/order1/label_removal | [25.00, 25.00] | [-12.03, 59.07] | [0.3333333333333333, 0.3333333333333333] |
| gpt-5.4-mini-2026-03-17/coded/mapping3/order2/label_removal | [-12.50, -12.50] | [-48.08, 26.42] | [0.9999999999999999, 0.9999999999999999] |
| gpt-5.4-mini-2026-03-17/coded/mapping3/order3/label_removal | [-12.50, -12.50] | [-47.09, 21.52] | [1.0, 1.0] |
| gpt-5.4-mini-2026-03-17/historical_anchor/label_removal | [-12.50, -12.50] | [-48.08, 26.42] | [1.0, 1.0] |
| gpt-5.4-mini-2026-03-17/labeled/coded_minus_canonical | [-10.16, -9.38] | [-20.01, 6.57] | [0.21593210747249902, 0.2558374376013961] |
| gpt-5.4-mini-2026-03-17/labeled/order1_minus_order0 | [-12.50, -12.50] | [-48.08, 26.42] | [0.9999999999999999, 0.9999999999999999] |
| gpt-5.4-mini-2026-03-17/labeled/order2_minus_order0 | [12.50, 12.50] | [-21.52, 47.09] | [1.0, 1.0] |
| gpt-5.4-mini-2026-03-17/labeled/order3_minus_order0 | [12.50, 12.50] | [-21.52, 47.09] | [1.0, 1.0] |
| gpt-5.4-mini-2026-03-17/unlabeled/coded_minus_canonical | [-0.78, 0.00] | [-12.23, 16.97] | [1.0, 1.0] |
| gpt-5.4-mini-2026-03-17/unlabeled/order1_minus_order0 | [12.50, 12.50] | [-26.42, 48.08] | [1.0, 1.0] |
| gpt-5.4-mini-2026-03-17/unlabeled/order2_minus_order0 | [12.50, 12.50] | [-26.42, 48.08] | [1.0, 1.0] |
| gpt-5.4-mini-2026-03-17/unlabeled/order3_minus_order0 | [12.50, 12.50] | [-26.42, 48.08] | [1.0, 1.0] |
| gpt-5.6-luna/canonical/label_removal | [-15.62, -12.50] | [-36.00, 9.41] | [0.1423611111111111, 0.23958333333333331] |
| gpt-5.6-luna/canonical/mapping0/order0/label_removal | [12.50, 25.00] | [-26.42, 59.07] | [0.3333333333333333, 0.9999999999999999] |
| gpt-5.6-luna/canonical/mapping0/order1/label_removal | [-12.50, -12.50] | [-48.08, 26.42] | [1.0, 1.0] |
| gpt-5.6-luna/canonical/mapping0/order2/label_removal | [-37.50, -37.50] | [-67.77, 7.30] | [0.16666666666666666, 0.16666666666666666] |
| gpt-5.6-luna/canonical/mapping0/order3/label_removal | [-25.00, -25.00] | [-58.68, 20.15] | [0.5, 0.5] |
| gpt-5.6-luna/coded/label_removal | [0.00, 0.78] | [-12.07, 12.83] | [0.9999999999999998, 1.0] |
| gpt-5.6-luna/coded/mapping0/order0/label_removal | [12.50, 12.50] | [-30.28, 49.62] | [1.0, 1.0] |
| gpt-5.6-luna/coded/mapping0/order1/label_removal | [12.50, 12.50] | [-29.07, 49.08] | [0.9999999999999999, 0.9999999999999999] |
| gpt-5.6-luna/coded/mapping0/order2/label_removal | [-25.00, -25.00] | [-58.61, 19.41] | [0.3333333333333333, 0.3333333333333333] |
| gpt-5.6-luna/coded/mapping0/order3/label_removal | [-12.50, -12.50] | [-49.62, 30.28] | [1.0, 1.0] |
| gpt-5.6-luna/coded/mapping1/order0/label_removal | [-12.50, 0.00] | [-49.62, 39.83] | [1.0, 1.0] |
| gpt-5.6-luna/coded/mapping1/order1/label_removal | [25.00, 25.00] | [-19.41, 58.61] | [0.5833333333333334, 0.5833333333333334] |
| gpt-5.6-luna/coded/mapping1/order2/label_removal | [0.00, 0.00] | [-39.83, 39.83] | [1.0, 1.0] |
| gpt-5.6-luna/coded/mapping1/order3/label_removal | [0.00, 0.00] | [-40.27, 40.27] | [1.0, 1.0] |
| gpt-5.6-luna/coded/mapping2/order0/label_removal | [0.00, 0.00] | [-40.27, 40.27] | [1.0, 1.0] |
| gpt-5.6-luna/coded/mapping2/order1/label_removal | [0.00, 0.00] | [-40.27, 40.27] | [1.0, 1.0] |
| gpt-5.6-luna/coded/mapping2/order2/label_removal | [0.00, 0.00] | [-40.27, 40.27] | [1.0, 1.0] |
| gpt-5.6-luna/coded/mapping2/order3/label_removal | [0.00, 0.00] | [-40.27, 40.27] | [1.0, 1.0] |
| gpt-5.6-luna/coded/mapping3/order0/label_removal | [0.00, 0.00] | [-40.27, 40.27] | [1.0, 1.0] |
| gpt-5.6-luna/coded/mapping3/order1/label_removal | [12.50, 12.50] | [-29.07, 49.08] | [0.9999999999999999, 0.9999999999999999] |
| gpt-5.6-luna/coded/mapping3/order2/label_removal | [-12.50, -12.50] | [-49.62, 30.28] | [1.0, 1.0] |
| gpt-5.6-luna/coded/mapping3/order3/label_removal | [0.00, 0.00] | [-40.27, 40.27] | [1.0, 1.0] |
| gpt-5.6-luna/historical_anchor/label_removal | [12.50, 25.00] | [-26.42, 59.07] | [0.3333333333333333, 0.9999999999999999] |
| gpt-5.6-luna/labeled/coded_minus_canonical | [-28.91, -28.91] | [-42.70, -9.98] | [2.5234113141289448e-05, 2.5234113141289448e-05] |
| gpt-5.6-luna/labeled/order1_minus_order0 | [12.50, 12.50] | [-26.42, 48.08] | [1.0, 1.0] |
| gpt-5.6-luna/labeled/order2_minus_order0 | [12.50, 12.50] | [-26.42, 48.08] | [1.0, 1.0] |
| gpt-5.6-luna/labeled/order3_minus_order0 | [-12.50, -12.50] | [-49.08, 29.07] | [1.0, 1.0] |
| gpt-5.6-luna/unlabeled/coded_minus_canonical | [-16.41, -12.50] | [-32.76, 6.74] | [0.011565073514945219, 0.06895565744246306] |
| gpt-5.6-luna/unlabeled/order1_minus_order0 | [-25.00, -12.50] | [-59.07, 26.42] | [0.3333333333333333, 0.9999999999999999] |
| gpt-5.6-luna/unlabeled/order2_minus_order0 | [-50.00, -37.50] | [-78.48, 7.30] | [0.05555555555555555, 0.27777777777777773] |
| gpt-5.6-luna/unlabeled/order3_minus_order0 | [-62.50, -50.00] | [-86.32, -2.93] | [0.027777777777777776, 0.12037037037037036] |
| gpt-5.6-sol/canonical/label_removal | [3.12, 6.25] | [-10.28, 20.15] | [0.5, 1.0] |
| gpt-5.6-sol/canonical/mapping0/order0/label_removal | [0.00, 0.00] | [-32.44, 32.44] | [1.0, 1.0] |
| gpt-5.6-sol/canonical/mapping0/order1/label_removal | [0.00, 0.00] | [-32.44, 32.44] | [1.0, 1.0] |
| gpt-5.6-sol/canonical/mapping0/order2/label_removal | [12.50, 12.50] | [-21.52, 47.09] | [1.0, 1.0] |
| gpt-5.6-sol/canonical/mapping0/order3/label_removal | [0.00, 12.50] | [-36.08, 47.09] | [1.0, 1.0] |
| gpt-5.6-sol/coded/label_removal | [20.31, 21.09] | [13.21, 28.95] | [3.876133989356296e-10, 9.108914874987296e-09] |
| gpt-5.6-sol/coded/mapping0/order0/label_removal | [0.00, 0.00] | [-32.44, 32.44] | [1.0, 1.0] |
| gpt-5.6-sol/coded/mapping0/order1/label_removal | [0.00, 0.00] | [-32.44, 32.44] | [1.0, 1.0] |
| gpt-5.6-sol/coded/mapping0/order2/label_removal | [25.00, 25.00] | [-12.03, 59.07] | [0.3333333333333333, 0.3333333333333333] |
| gpt-5.6-sol/coded/mapping0/order3/label_removal | [0.00, 0.00] | [-32.44, 32.44] | [1.0, 1.0] |
| gpt-5.6-sol/coded/mapping1/order0/label_removal | [25.00, 25.00] | [-12.03, 59.07] | [0.3333333333333333, 0.3333333333333333] |
| gpt-5.6-sol/coded/mapping1/order1/label_removal | [25.00, 25.00] | [-12.03, 59.07] | [0.3333333333333333, 0.3333333333333333] |
| gpt-5.6-sol/coded/mapping1/order2/label_removal | [37.50, 37.50] | [-2.74, 69.43] | [0.16666666666666666, 0.16666666666666666] |
| gpt-5.6-sol/coded/mapping1/order3/label_removal | [37.50, 37.50] | [-2.74, 69.43] | [0.16666666666666666, 0.16666666666666666] |
| gpt-5.6-sol/coded/mapping2/order0/label_removal | [25.00, 25.00] | [-12.03, 59.07] | [0.5, 0.5] |
| gpt-5.6-sol/coded/mapping2/order1/label_removal | [37.50, 37.50] | [-2.74, 69.43] | [0.16666666666666666, 0.16666666666666666] |
| gpt-5.6-sol/coded/mapping2/order2/label_removal | [50.00, 50.00] | [6.83, 78.48] | [0.05555555555555555, 0.05555555555555555] |
| gpt-5.6-sol/coded/mapping2/order3/label_removal | [12.50, 12.50] | [-21.52, 47.09] | [1.0, 1.0] |
| gpt-5.6-sol/coded/mapping3/order0/label_removal | [0.00, 0.00] | [-32.44, 32.44] | [1.0, 1.0] |
| gpt-5.6-sol/coded/mapping3/order1/label_removal | [25.00, 25.00] | [-12.03, 59.07] | [0.3333333333333333, 0.3333333333333333] |
| gpt-5.6-sol/coded/mapping3/order2/label_removal | [0.00, 12.50] | [-36.08, 47.09] | [1.0, 1.0] |
| gpt-5.6-sol/coded/mapping3/order3/label_removal | [25.00, 25.00] | [-12.03, 59.07] | [0.5, 0.5] |
| gpt-5.6-sol/historical_anchor/label_removal | [0.00, 0.00] | [-32.44, 32.44] | [1.0, 1.0] |
| gpt-5.6-sol/labeled/coded_minus_canonical | [-3.12, 0.78] | [-15.74, 4.29] | [0.4, 1.0] |
| gpt-5.6-sol/labeled/order1_minus_order0 | [0.00, 0.00] | [-32.44, 32.44] | [1.0, 1.0] |
| gpt-5.6-sol/labeled/order2_minus_order0 | [0.00, 0.00] | [-32.44, 32.44] | [1.0, 1.0] |
| gpt-5.6-sol/labeled/order3_minus_order0 | [0.00, 12.50] | [-32.44, 47.09] | [1.0, 1.0] |
| gpt-5.6-sol/unlabeled/coded_minus_canonical | [14.84, 14.84] | [-0.36, 23.91] | [0.05118066714220394, 0.05118066714220394] |
| gpt-5.6-sol/unlabeled/order1_minus_order0 | [0.00, 0.00] | [-32.44, 32.44] | [1.0, 1.0] |
| gpt-5.6-sol/unlabeled/order2_minus_order0 | [12.50, 12.50] | [-21.52, 47.09] | [1.0, 1.0] |
| gpt-5.6-sol/unlabeled/order3_minus_order0 | [12.50, 12.50] | [-21.52, 47.09] | [1.0, 1.0] |
| gpt-5.6-terra/canonical/label_removal | [9.38, 9.38] | [-2.97, 24.22] | [0.16666666666666666, 0.16666666666666666] |
| gpt-5.6-terra/canonical/mapping0/order0/label_removal | [37.50, 37.50] | [-2.74, 69.43] | [0.16666666666666666, 0.16666666666666666] |
| gpt-5.6-terra/canonical/mapping0/order1/label_removal | [0.00, 0.00] | [-32.44, 32.44] | [1.0, 1.0] |
| gpt-5.6-terra/canonical/mapping0/order2/label_removal | [0.00, 0.00] | [-32.44, 32.44] | [1.0, 1.0] |
| gpt-5.6-terra/canonical/mapping0/order3/label_removal | [0.00, 0.00] | [-32.44, 32.44] | [1.0, 1.0] |
| gpt-5.6-terra/coded/label_removal | [19.53, 21.09] | [9.28, 30.93] | [2.9710361641541925e-06, 1.779440828513023e-05] |
| gpt-5.6-terra/coded/mapping0/order0/label_removal | [0.00, 0.00] | [-32.44, 32.44] | [1.0, 1.0] |
| gpt-5.6-terra/coded/mapping0/order1/label_removal | [25.00, 25.00] | [-12.03, 59.07] | [0.5, 0.5] |
| gpt-5.6-terra/coded/mapping0/order2/label_removal | [25.00, 25.00] | [-12.03, 59.07] | [0.3333333333333333, 0.3333333333333333] |
| gpt-5.6-terra/coded/mapping0/order3/label_removal | [0.00, 0.00] | [-32.44, 32.44] | [1.0, 1.0] |
| gpt-5.6-terra/coded/mapping1/order0/label_removal | [25.00, 25.00] | [-20.15, 58.68] | [0.5, 0.5] |
| gpt-5.6-terra/coded/mapping1/order1/label_removal | [25.00, 25.00] | [-16.99, 58.53] | [0.5, 0.5] |
| gpt-5.6-terra/coded/mapping1/order2/label_removal | [12.50, 12.50] | [-21.52, 47.09] | [1.0, 1.0] |
| gpt-5.6-terra/coded/mapping1/order3/label_removal | [-25.00, -25.00] | [-59.07, 12.03] | [0.3333333333333333, 0.3333333333333333] |
| gpt-5.6-terra/coded/mapping2/order0/label_removal | [62.50, 62.50] | [16.98, 86.32] | [0.027777777777777776, 0.027777777777777776] |
| gpt-5.6-terra/coded/mapping2/order1/label_removal | [12.50, 12.50] | [-30.28, 49.62] | [1.0, 1.0] |
| gpt-5.6-terra/coded/mapping2/order2/label_removal | [12.50, 25.00] | [-26.42, 58.53] | [0.5833333333333333, 1.0] |
| gpt-5.6-terra/coded/mapping2/order3/label_removal | [12.50, 12.50] | [-26.42, 48.08] | [1.0, 1.0] |
| gpt-5.6-terra/coded/mapping3/order0/label_removal | [50.00, 50.00] | [2.93, 75.93] | [0.08333333333333333, 0.08333333333333333] |
| gpt-5.6-terra/coded/mapping3/order1/label_removal | [0.00, 0.00] | [-32.44, 32.44] | [1.0, 1.0] |
| gpt-5.6-terra/coded/mapping3/order2/label_removal | [50.00, 50.00] | [2.93, 75.93] | [0.125, 0.125] |
| gpt-5.6-terra/coded/mapping3/order3/label_removal | [25.00, 37.50] | [-16.99, 67.77] | [0.16666666666666666, 0.5] |
| gpt-5.6-terra/historical_anchor/label_removal | [37.50, 37.50] | [-2.74, 69.43] | [0.16666666666666666, 0.16666666666666666] |
| gpt-5.6-terra/labeled/coded_minus_canonical | [-25.00, -23.44] | [-35.54, -6.79] | [0.0031997150738352583, 0.005371582262876933] |
| gpt-5.6-terra/labeled/order1_minus_order0 | [37.50, 37.50] | [-2.74, 69.43] | [0.16666666666666666, 0.16666666666666666] |
| gpt-5.6-terra/labeled/order2_minus_order0 | [37.50, 37.50] | [-2.74, 69.43] | [0.16666666666666666, 0.16666666666666666] |
| gpt-5.6-terra/labeled/order3_minus_order0 | [37.50, 37.50] | [-2.74, 69.43] | [0.16666666666666666, 0.16666666666666666] |
| gpt-5.6-terra/unlabeled/coded_minus_canonical | [-13.28, -13.28] | [-20.24, -1.53] | [0.024982207996748457, 0.024982207996748457] |
| gpt-5.6-terra/unlabeled/order1_minus_order0 | [0.00, 0.00] | [-32.44, 32.44] | [1.0, 1.0] |
| gpt-5.6-terra/unlabeled/order2_minus_order0 | [0.00, 0.00] | [-32.44, 32.44] | [1.0, 1.0] |
| gpt-5.6-terra/unlabeled/order3_minus_order0 | [0.00, 0.00] | [-32.44, 32.44] | [1.0, 1.0] |
| gpt-6-astra/canonical/label_removal | [0.00, 3.12] | [-10.72, 15.74] | [1.0, 1.0] |
| gpt-6-astra/canonical/mapping0/order0/label_removal | [0.00, 0.00] | [-32.44, 32.44] | [1.0, 1.0] |
| gpt-6-astra/canonical/mapping0/order1/label_removal | [0.00, 12.50] | [-32.44, 47.09] | [1.0, 1.0] |
| gpt-6-astra/canonical/mapping0/order2/label_removal | [0.00, 0.00] | [-32.44, 32.44] | [1.0, 1.0] |
| gpt-6-astra/canonical/mapping0/order3/label_removal | [0.00, 0.00] | [-32.44, 32.44] | [1.0, 1.0] |
| gpt-6-astra/coded/label_removal | [-2.34, 0.78] | [-6.66, 4.29] | [0.25, 1.0] |
| gpt-6-astra/coded/mapping0/order0/label_removal | [0.00, 0.00] | [-32.44, 32.44] | [1.0, 1.0] |
| gpt-6-astra/coded/mapping0/order1/label_removal | [0.00, 0.00] | [-32.44, 32.44] | [1.0, 1.0] |
| gpt-6-astra/coded/mapping0/order2/label_removal | [0.00, 0.00] | [-32.44, 32.44] | [1.0, 1.0] |
| gpt-6-astra/coded/mapping0/order3/label_removal | [0.00, 0.00] | [-32.44, 32.44] | [1.0, 1.0] |
| gpt-6-astra/coded/mapping1/order0/label_removal | [0.00, 0.00] | [-32.44, 32.44] | [1.0, 1.0] |
| gpt-6-astra/coded/mapping1/order1/label_removal | [-12.50, 0.00] | [-47.09, 32.44] | [1.0, 1.0] |
| gpt-6-astra/coded/mapping1/order2/label_removal | [0.00, 0.00] | [-32.44, 32.44] | [1.0, 1.0] |
| gpt-6-astra/coded/mapping1/order3/label_removal | [0.00, 0.00] | [-32.44, 32.44] | [1.0, 1.0] |
| gpt-6-astra/coded/mapping2/order0/label_removal | [-12.50, 0.00] | [-47.09, 32.44] | [1.0, 1.0] |
| gpt-6-astra/coded/mapping2/order1/label_removal | [0.00, 0.00] | [-32.44, 32.44] | [1.0, 1.0] |
| gpt-6-astra/coded/mapping2/order2/label_removal | [-12.50, 0.00] | [-47.09, 32.44] | [1.0, 1.0] |
| gpt-6-astra/coded/mapping2/order3/label_removal | [0.00, 0.00] | [-32.44, 32.44] | [1.0, 1.0] |
| gpt-6-astra/coded/mapping3/order0/label_removal | [0.00, 0.00] | [-32.44, 32.44] | [1.0, 1.0] |
| gpt-6-astra/coded/mapping3/order1/label_removal | [0.00, 12.50] | [-32.44, 47.09] | [1.0, 1.0] |
| gpt-6-astra/coded/mapping3/order2/label_removal | [0.00, 0.00] | [-32.44, 32.44] | [1.0, 1.0] |
| gpt-6-astra/coded/mapping3/order3/label_removal | [0.00, 0.00] | [-32.44, 32.44] | [1.0, 1.0] |
| gpt-6-astra/historical_anchor/label_removal | [0.00, 0.00] | [-32.44, 32.44] | [1.0, 1.0] |
| gpt-6-astra/labeled/coded_minus_canonical | [0.00, 2.34] | [-10.72, 6.66] | [1.0, 1.0] |
| gpt-6-astra/labeled/order1_minus_order0 | [0.00, 0.00] | [-32.44, 32.44] | [1.0, 1.0] |
| gpt-6-astra/labeled/order2_minus_order0 | [0.00, 0.00] | [-32.44, 32.44] | [1.0, 1.0] |
| gpt-6-astra/labeled/order3_minus_order0 | [0.00, 0.00] | [-32.44, 32.44] | [1.0, 1.0] |
| gpt-6-astra/unlabeled/coded_minus_canonical | [-3.12, 0.78] | [-15.74, 4.29] | [0.4, 1.0] |
| gpt-6-astra/unlabeled/order1_minus_order0 | [0.00, 12.50] | [-32.44, 47.09] | [1.0, 1.0] |
| gpt-6-astra/unlabeled/order2_minus_order0 | [0.00, 0.00] | [-32.44, 32.44] | [1.0, 1.0] |
| gpt-6-astra/unlabeled/order3_minus_order0 | [0.00, 0.00] | [-32.44, 32.44] | [1.0, 1.0] |

## All key-study label contrasts

| Contrast | Difference bounds (pp) | 95% Newcombe reference envelope (pp) | Exact conditional p range |
| --- | --- | --- | --- |
| gpt-5.6-luna/unstated/none | [0.00, 0.00] | [-16.11, 16.11] | [1.0, 1.0] |
| gpt-5.6-luna/unstated/valid | [-10.00, -10.00] | [-30.10, 7.65] | [0.4444444444444444, 0.4444444444444444] |
| gpt-5.6-luna/unstated/changed | [5.00, 5.00] | [-17.35, 27.24] | [1.0, 1.0] |
| gpt-5.6-luna/stated/none | [25.00, 25.00] | [-1.25, 47.88] | [0.0767195767195767, 0.0767195767195767] |
| gpt-5.6-luna/stated/valid | [0.00, 0.00] | [-16.11, 16.11] | [1.0, 1.0] |
| gpt-5.6-luna/stated/changed | [15.00, 15.00] | [-14.11, 40.90] | [0.5208590784932431, 0.5208590784932431] |
| gpt-5.6-sol/unstated/none | [0.00, 0.00] | [-16.11, 16.11] | [1.0, 1.0] |
| gpt-5.6-sol/unstated/valid | [0.00, 0.00] | [-16.11, 16.11] | [1.0, 1.0] |
| gpt-5.6-sol/unstated/changed | [5.00, 5.00] | [-11.63, 23.61] | [1.0, 1.0] |
| gpt-5.6-sol/stated/none | [0.00, 0.00] | [-16.11, 16.11] | [1.0, 1.0] |
| gpt-5.6-sol/stated/valid | [0.00, 0.00] | [-16.11, 16.11] | [1.0, 1.0] |
| gpt-5.6-sol/stated/changed | [0.00, 0.00] | [-16.11, 16.11] | [1.0, 1.0] |
| gpt-5.6-terra/unstated/none | [0.00, 0.00] | [-16.11, 16.11] | [1.0, 1.0] |
| gpt-5.6-terra/unstated/valid | [0.00, 0.00] | [-16.11, 16.11] | [1.0, 1.0] |
| gpt-5.6-terra/unstated/changed | [5.00, 5.00] | [-21.78, 30.89] | [1.0, 1.0] |
| gpt-5.6-terra/stated/none | [0.00, 0.00] | [-16.11, 16.11] | [1.0, 1.0] |
| gpt-5.6-terra/stated/valid | [0.00, 0.00] | [-16.11, 16.11] | [1.0, 1.0] |
| gpt-5.6-terra/stated/changed | [20.00, 20.00] | [-9.09, 44.96] | [0.14285714285714285, 0.14285714285714285] |

## All original key-study contrasts

| Contrast | Difference bounds (pp) | 95% Newcombe reference envelope (pp) | Exact conditional p range |
| --- | --- | --- | --- |
| gpt-5.6-luna/label_removal | [0.00, 0.00] | [-16.11, 16.11] | [1.0, 1.0] |
| gpt-5.6-luna/labeled/semantics_added | [-90.00, -90.00] | [-97.21, -64.24] | [1.0414708701430795e-08, 1.0414708701430795e-08] |
| gpt-5.6-luna/labeled/stated/valid_minus_changed_keyed_selection | [45.00, 45.00] | [19.95, 65.79] | [0.0004409171075837742, 0.0004409171075837742] |
| gpt-5.6-luna/labeled/stated/valid_minus_changed_progress | [100.00, 100.00] | [77.21, 100.00] | [4.959385095919426e-10, 4.959385095919426e-10] |
| gpt-5.6-luna/labeled/unstated/valid_minus_changed_keyed_selection | [15.00, 15.00] | [-3.84, 36.04] | [0.2222222222222222, 0.2222222222222222] |
| gpt-5.6-luna/labeled/unstated/valid_minus_changed_progress | [100.00, 100.00] | [77.21, 100.00] | [4.959385095919426e-10, 4.959385095919426e-10] |
| gpt-5.6-luna/unlabeled/semantics_added | [-65.00, -65.00] | [-81.88, -37.96] | [3.4993421236807474e-06, 3.4993421236807474e-06] |
| gpt-5.6-luna/unlabeled/stated/valid_minus_changed_keyed_selection | [30.00, 30.00] | [7.68, 51.90] | [0.018518518518518517, 0.018518518518518517] |
| gpt-5.6-luna/unlabeled/stated/valid_minus_changed_progress | [100.00, 100.00] | [77.21, 100.00] | [4.959385095919426e-10, 4.959385095919426e-10] |
| gpt-5.6-luna/unlabeled/unstated/valid_minus_changed_keyed_selection | [0.00, 0.00] | [-21.36, 21.36] | [1.0, 1.0] |
| gpt-5.6-luna/unlabeled/unstated/valid_minus_changed_progress | [90.00, 90.00] | [64.24, 97.21] | [1.0414708701430797e-08, 1.0414708701430797e-08] |
| gpt-5.6-sol/label_removal | [0.00, 0.00] | [-16.11, 16.11] | [1.0, 1.0] |
| gpt-5.6-sol/labeled/semantics_added | [0.00, 0.00] | [-16.11, 16.11] | [1.0, 1.0] |
| gpt-5.6-sol/labeled/stated/valid_minus_changed_keyed_selection | [100.00, 100.00] | [77.21, 100.00] | [4.959385095919426e-10, 4.959385095919426e-10] |
| gpt-5.6-sol/labeled/stated/valid_minus_changed_progress | [100.00, 100.00] | [77.21, 100.00] | [4.959385095919426e-10, 4.959385095919426e-10] |
| gpt-5.6-sol/labeled/unstated/valid_minus_changed_keyed_selection | [100.00, 100.00] | [77.21, 100.00] | [4.959385095919426e-10, 4.959385095919426e-10] |
| gpt-5.6-sol/labeled/unstated/valid_minus_changed_progress | [100.00, 100.00] | [77.21, 100.00] | [4.959385095919426e-10, 4.959385095919426e-10] |
| gpt-5.6-sol/unlabeled/semantics_added | [0.00, 0.00] | [-16.11, 16.11] | [1.0, 1.0] |
| gpt-5.6-sol/unlabeled/stated/valid_minus_changed_keyed_selection | [100.00, 100.00] | [77.21, 100.00] | [4.959385095919426e-10, 4.959385095919426e-10] |
| gpt-5.6-sol/unlabeled/stated/valid_minus_changed_progress | [100.00, 100.00] | [77.21, 100.00] | [4.959385095919426e-10, 4.959385095919426e-10] |
| gpt-5.6-sol/unlabeled/unstated/valid_minus_changed_keyed_selection | [100.00, 100.00] | [77.21, 100.00] | [4.959385095919426e-10, 4.959385095919426e-10] |
| gpt-5.6-sol/unlabeled/unstated/valid_minus_changed_progress | [100.00, 100.00] | [77.21, 100.00] | [4.959385095919426e-10, 4.959385095919426e-10] |
| gpt-5.6-terra/label_removal | [0.00, 0.00] | [-16.11, 16.11] | [1.0, 1.0] |
| gpt-5.6-terra/labeled/semantics_added | [0.00, 0.00] | [-16.11, 16.11] | [1.0, 1.0] |
| gpt-5.6-terra/labeled/stated/valid_minus_changed_keyed_selection | [45.00, 45.00] | [19.95, 65.79] | [0.00018896447467876037, 0.00018896447467876037] |
| gpt-5.6-terra/labeled/stated/valid_minus_changed_progress | [100.00, 100.00] | [77.21, 100.00] | [4.959385095919426e-10, 4.959385095919426e-10] |
| gpt-5.6-terra/labeled/unstated/valid_minus_changed_keyed_selection | [30.00, 30.00] | [7.68, 51.90] | [0.013888888888888888, 0.013888888888888888] |
| gpt-5.6-terra/labeled/unstated/valid_minus_changed_progress | [100.00, 100.00] | [77.21, 100.00] | [4.959385095919426e-10, 4.959385095919426e-10] |
| gpt-5.6-terra/unlabeled/semantics_added | [0.00, 0.00] | [-16.11, 16.11] | [1.0, 1.0] |
| gpt-5.6-terra/unlabeled/stated/valid_minus_changed_keyed_selection | [25.00, 25.00] | [3.78, 46.87] | [0.037037037037037035, 0.037037037037037035] |
| gpt-5.6-terra/unlabeled/stated/valid_minus_changed_progress | [100.00, 100.00] | [77.21, 100.00] | [4.959385095919426e-10, 4.959385095919426e-10] |
| gpt-5.6-terra/unlabeled/unstated/valid_minus_changed_keyed_selection | [25.00, 25.00] | [3.78, 46.87] | [0.023809523809523808, 0.023809523809523808] |
| gpt-5.6-terra/unlabeled/unstated/valid_minus_changed_progress | [100.00, 100.00] | [77.21, 100.00] | [4.959385095919426e-10, 4.959385095919426e-10] |
