"""Recorded Astra-only transport amendment; never resend attempted requests."""
import argparse,hashlib,json,socket,subprocess,sys,urllib.request,urllib.error
from pathlib import Path
from datetime import datetime,timezone
from retrybench.serialization import read_json_object,read_jsonl,write_json,write_jsonl,canonical_json_sha256
from counterbalance_study import helper,STUDY
MODEL='gpt-6-astra'
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def now():return datetime.now(timezone.utc).isoformat()

def record_amendment():
    pd=Path('protocol')/STUDY;rd=Path('runs')/STUDY;shard=rd/'shards'/MODEL;p=read_json_object(pd/'protocol.json');rs=read_jsonl(shard/'requests.jsonl');cases=[c for c in read_jsonl(pd/'manifest.jsonl') if c['requested_model']==MODEL]
    if (pd/'amendment-1.json').exists():raise ValueError('Never replace recorded amendment')
    if (shard/'private/pending.json').exists():raise ValueError('Pending call requires separate resolution')
    if [r['case_id'] for r in rs]!=[c['case_id'] for c in cases[:len(rs)]]:raise ValueError('prefix mismatch')
    failed=[r for r in rs if r['status']=='failed']
    if len(failed)!=1 or failed[0].get('error_type')!='URLError' or failed[0].get('http_status') is not None:raise ValueError('unexpected error; no amendment')
    rawids={r['case_id'] for r in read_jsonl(shard/'private/provider-responses.jsonl')}
    if failed[0]['case_id'] in rawids:raise ValueError('raw response exists; inspect instead of treating unknown')
    amendment={'schema_version':'retrybench-counterbalance-transport-amendment-v1','recorded_at_utc':now(),'original_protocol_sha256':canonical_json_sha256(p),'endpoint':MODEL,'prior_attempted_requests':len(rs),'prior_public_requests_sha256':sha(shard/'requests.jsonl'),'prior_private_journal_sha256':sha(shard/'private/requests.jsonl'),'prior_summary_sha256':sha(shard/'summary.json'),'retained_failed_case_ids':[r['case_id'] for r in failed],'remaining_case_ids_in_order':[c['case_id'] for c in cases[len(rs):]],'resume_implementation_sha256':sha(__file__),'max_transport_missing_total':8,'reason':'The endpoint stopped on a recorded URLError without HTTP status or provider response. Exact transport cause was not retained. Preserve that attempted case and its unknown-charge reserve; do not recast it as an observed model response or replay it. Continue only unattempted suffix.','policy':'Astra only: allow up to8 total missing transport requests including historical timeouts and the retained URLError; ninth stops. New URLError without HTTP status is retained as transport_error. HTTP/auth/access/server or decode/provenance failures still stop. Invalid/incomplete outputs remain missing. No replacement calls. Original model/prompt/schema/order/cap256 and total$4 endpoint spending cap remain unchanged.','timing':'Recorded after inspecting transport metadata and progress, before inspecting this study model actions or computing treatment effects.','status':'Deviation from original stopping rule, not a complete execution of the original unamended protocol.'}
    write_json(pd/'amendment-1.json',amendment)
    import shutil
    shutil.copyfile(__file__,rd/'collection-code/resume_counterbalance.py')
    print('Recorded amendment for '+str(len(amendment['remaining_case_ids_in_order']))+' unattempted Astra cases.')

def collect():
    pd=Path('protocol')/STUDY;rd=Path('runs')/STUDY;out=rd/'shards'/MODEL;private=out/'private';pending=private/'pending.json';journal=private/'requests.jsonl'
    p=read_json_object(pd/'protocol.json');am=read_json_object(pd/'amendment-1.json');ph=canonical_json_sha256(p);ah=canonical_json_sha256(am)
    if sha(__file__)!=am['resume_implementation_sha256'] or am['original_protocol_sha256']!=ph:raise ValueError('amendment mismatch')
    for name,digest in p['source_sha256'].items():
        if sha(Path('src/retrybench')/name)!=digest:raise ValueError('source changed')
    if sha('scripts/followup_studies.py')!=p['helper_sha256'] or sha('scripts/counterbalance_study.py')!=p['implementation_sha256']:raise ValueError('collector/helper changed')
    allcases=read_jsonl(pd/'manifest.jsonl')
    if canonical_json_sha256(allcases)!=p['manifest_sha256']:raise ValueError('manifest changed')
    cases=[c for c in allcases if c['requested_model']==MODEL];records=read_jsonl(journal)
    if pending.exists():raise ValueError('Pending request must not be replayed')
    if [r['case_id'] for r in records]!=[c['case_id'] for c in cases[:len(records)]]:raise ValueError('order mismatch')
    prefix=b''.join(journal.read_bytes().splitlines(keepends=True)[:am['prior_attempted_requests']])
    if hashlib.sha256(prefix).hexdigest()!=am['prior_private_journal_sha256']:raise ValueError('historical journal prefix changed')
    if [c['case_id'] for c in cases[am['prior_attempted_requests']:]]!=am['remaining_case_ids_in_order']:raise ValueError('amended suffix mismatch')
    if any(r['status']=='failed' and r['case_id'] not in am['retained_failed_case_ids'] for r in records):raise ValueError('new failure requires review')
    transport=sum(r['status'] in ('transport_timeout','transport_error') or r['case_id'] in am['retained_failed_case_ids'] for r in records)
    if transport>am['max_transport_missing_total']:raise ValueError('transport limit exceeded')
    spent=sum(r.get('cost_usd',0)+r.get('unknown_cost_upper_reserve_usd',0) for r in records);f=helper()
    def publish():
        write_jsonl(out/'requests.jsonl',records)
        write_json(out/'summary.json',dict(protocol_sha256=ph,amendment_sha256=ah,model=MODEL,planned=len(cases),attempted=len(records),complete=sum(r['status']=='complete' for r in records),missing=sum(r['status']!='complete' for r in records),known_cost_usd=sum(r.get('cost_usd',0) for r in records),unknown_cost_upper_reserve_usd=sum(r.get('unknown_cost_upper_reserve_usd',0) for r in records),attempted_all=len(records)==len(cases)))
    result=subprocess.run(['/usr/bin/security','find-generic-password','-a','retrybench','-s','retrybench-openai-api-key','-w'],capture_output=True,timeout=25)
    if result.returncode or not result.stdout.strip():raise ValueError('Keychain lookup failed')
    key=result.stdout.decode().strip();del result
    for c in cases[len(records):]:
        reserve=f.bounds_cost(c)
        if spent+reserve>p['endpoint_caps_usd'][MODEL]:publish();print('Budget stop');return
        record=dict(case_id=c['case_id'],protocol_sha256=ph,amendment_sha256=ah,collected_at_utc=now());write_json(pending,record)
        request=urllib.request.Request('https://api.openai.com/v1/responses',data=json.dumps(f.payload(c)).encode(),headers={'Authorization':'Bearer '+key,'Content-Type':'application/json'},method='POST')
        try:
            with urllib.request.urlopen(request,timeout=300) as response:raw=json.loads(response.read())
            with (private/'provider-responses.jsonl').open('a') as file:file.write(json.dumps({'case_id':c['case_id'],'response':raw},sort_keys=True)+'\n')
            record.update(f.decode(c,raw))
            if record['status']=='complete':record['selected_token']=record['decision']['action'];record['decision']['action']=c['token_to_action'][record['selected_token']]
        except (TimeoutError,socket.timeout):record.update(status='transport_timeout',unknown_cost_upper_reserve_usd=reserve)
        except urllib.error.HTTPError as exc:record.update(status='failed',error_type=type(exc).__name__,http_status=exc.code,unknown_cost_upper_reserve_usd=reserve)
        except urllib.error.URLError as exc:record.update(status='transport_error',error_type=type(exc).__name__,reason_type=type(exc.reason).__name__,unknown_cost_upper_reserve_usd=reserve)
        except Exception as exc:record.update(status='failed',error_type=type(exc).__name__,http_status=getattr(exc,'code',None),unknown_cost_upper_reserve_usd=reserve)
        with journal.open('a') as file:file.write(json.dumps(record,sort_keys=True)+'\n')
        records.append(record);pending.unlink();spent+=record.get('cost_usd',0)+record.get('unknown_cost_upper_reserve_usd',0);transport+=record['status'] in ('transport_timeout','transport_error');publish()
        if len(records)%20==0:print(json.dumps({'attempted':len(records),'complete':sum(r['status']=='complete' for r in records),'transport_missing':transport,'spent_plus_reserve':round(spent,6)}),flush=True)
        if record['status']=='failed' or transport>am['max_transport_missing_total']:print('Failure policy stop',flush=True);return
    print('Amended fixed manifest complete.',flush=True)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('mode',choices=['record','collect']);args=ap.parse_args()
    try:record_amendment() if args.mode=='record' else collect()
    except Exception as exc:print('Stopped safely: '+type(exc).__name__,flush=True);sys.exit(1)
