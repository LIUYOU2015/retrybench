# Historical counterbalance results

Counts use planned distinct-response denominators. “+m missing” identifies unobserved actions rather than treating them as non-retries. Brackets next to counts are nominal two-sided95% exact-binomial reference limits (or missing-action envelopes), in percent. Effect brackets are missing-action identification bounds, not confidence intervals. Canonical and coded strata remain separate. All conditions are weak not_found.

## Exact historical-order anchors

| Endpoint | Labeled historical order | Unlabeled same order |
| --- | --- | --- |
| gpt-5.4-2026-03-05 | 3/8 [8.5, 75.5] | 4/8 [15.7, 84.3] |
| gpt-5.4-mini-2026-03-17 | 7/8 [47.3, 99.7] | 6/8 [34.9, 96.8] |
| gpt-5.6-luna | 6/8 [34.9, 96.8] | 7/8 +1 missing [47.3, 100.0] |
| gpt-5.6-sol | 0/8 [0.0, 36.9] | 0/8 [0.0, 36.9] |
| gpt-5.6-terra | 5/8 [24.5, 91.5] | 8/8 [63.1, 100.0] |
| gpt-6-astra | 0/8 [0.0, 36.9] | 0/8 [0.0, 36.9] |

## Balanced representation strata

| Endpoint | Representation | Labeled retry count | Unlabeled retry count | Unlabeled − labeled |
| --- | --- | --- | --- | --- |
| gpt-5.4-2026-03-05 | canonical | 24/32 [56.6, 88.5] | 25/32 [60.0, 90.7] | +0.031 |
| gpt-5.4-2026-03-05 | coded | 71/128 +2 missing [46.4, 65.7] | 83/128 [55.9, 73.1] | [+0.078, +0.094] |
| gpt-5.4-mini-2026-03-17 | canonical | 29/32 [75.0, 98.0] | 27/32 [67.2, 94.7] | -0.062 |
| gpt-5.4-mini-2026-03-17 | coded | 103/128 +1 missing [72.5, 87.6] | 107/128 +1 missing [76.0, 90.2] | [+0.023, +0.039] |
| gpt-5.6-luna | canonical | 25/32 [60.0, 90.7] | 20/32 +1 missing [43.7, 81.4] | [-0.156, -0.125] |
| gpt-5.6-luna | coded | 63/128 [40.3, 58.2] | 63/128 +1 missing [40.3, 59.0] | [+0.000, +0.008] |
| gpt-5.6-sol | canonical | 0/32 +1 missing [0.0, 16.2] | 2/32 [0.8, 20.8] | [+0.031, +0.062] |
| gpt-5.6-sol | coded | 0/128 +1 missing [0.0, 4.3] | 27/128 [14.4, 29.2] | [+0.203, +0.211] |
| gpt-5.6-terra | canonical | 29/32 [75.0, 98.0] | 32/32 [89.1, 100.0] | +0.094 |
| gpt-5.6-terra | coded | 84/128 +2 missing [56.7, 75.2] | 111/128 [79.6, 92.1] | [+0.195, +0.211] |
| gpt-6-astra | canonical | 0/32 [0.0, 10.9] | 0/32 +1 missing [0.0, 16.2] | [+0.000, +0.031] |
| gpt-6-astra | coded | 0/128 +3 missing [0.0, 6.7] | 0/128 +1 missing [0.0, 4.3] | [-0.023, +0.008] |

## All four-task label counts

| Endpoint | Representation | CI: labeled → unlabeled | Issue: labeled → unlabeled | Release: labeled → unlabeled | Review: labeled → unlabeled |
| --- | --- | --- | --- | --- | --- |
| gpt-5.4-2026-03-05 | canonical | 4/8 → 5/8 | 8/8 → 8/8 | 7/8 → 8/8 | 5/8 → 4/8 |
| gpt-5.4-2026-03-05 | coded | 6/32 +1 missing → 18/32 | 27/32 +1 missing → 30/32 | 25/32 → 28/32 | 13/32 → 7/32 |
| gpt-5.4-mini-2026-03-17 | canonical | 7/8 → 8/8 | 8/8 → 8/8 | 8/8 → 8/8 | 6/8 → 3/8 |
| gpt-5.4-mini-2026-03-17 | coded | 27/32 → 29/32 +1 missing | 29/32 → 31/32 | 28/32 +1 missing → 32/32 | 19/32 → 15/32 |
| gpt-5.6-luna | canonical | 7/8 → 4/8 | 8/8 → 6/8 +1 missing | 8/8 → 8/8 | 2/8 → 2/8 |
| gpt-5.6-luna | coded | 4/32 → 6/32 | 29/32 → 27/32 | 28/32 → 30/32 +1 missing | 2/32 → 0/32 |
| gpt-5.6-sol | canonical | 0/8 → 0/8 | 0/8 → 1/8 | 0/8 +1 missing → 1/8 | 0/8 → 0/8 |
| gpt-5.6-sol | coded | 0/32 → 0/32 | 0/32 +1 missing → 16/32 | 0/32 → 10/32 | 0/32 → 1/32 |
| gpt-5.6-terra | canonical | 7/8 → 8/8 | 8/8 → 8/8 | 8/8 → 8/8 | 6/8 → 8/8 |
| gpt-5.6-terra | coded | 17/32 +2 missing → 20/32 | 28/32 → 32/32 | 20/32 → 32/32 | 19/32 → 27/32 |
| gpt-6-astra | canonical | 0/8 → 0/8 | 0/8 → 0/8 | 0/8 → 0/8 +1 missing | 0/8 → 0/8 |
| gpt-6-astra | coded | 0/32 +1 missing → 0/32 | 0/32 +1 missing → 0/32 | 0/32 → 0/32 +1 missing | 0/32 +1 missing → 0/32 |

## Full format cells

| Endpoint/representation/label/mapping/order | Retry count [reference limits] | Retry/stop/wait/unresolved | Duplicates/omissions/unresolved/ledger/resolved |
| --- | --- | --- | --- |
| gpt-5.4-2026-03-05/canonical/labeled/mapping0/order0 | 3/8 [8.5, 75.5] | 3/0/0/5 | 6/5/15/13/3 |
| gpt-5.4-2026-03-05/canonical/labeled/mapping0/order1 | 7/8 [47.3, 99.7] | 7/0/0/1 | 14/1/3/9/7 |
| gpt-5.4-2026-03-05/canonical/labeled/mapping0/order2 | 6/8 [34.9, 96.8] | 6/0/0/2 | 12/2/6/10/6 |
| gpt-5.4-2026-03-05/canonical/labeled/mapping0/order3 | 8/8 [63.1, 100.0] | 8/0/0/0 | 16/0/0/8/8 |
| gpt-5.4-2026-03-05/canonical/unlabeled/mapping0/order0 | 4/8 [15.7, 84.3] | 4/0/0/4 | 8/4/12/12/4 |
| gpt-5.4-2026-03-05/canonical/unlabeled/mapping0/order1 | 7/8 [47.3, 99.7] | 7/0/0/1 | 14/1/3/9/7 |
| gpt-5.4-2026-03-05/canonical/unlabeled/mapping0/order2 | 6/8 [34.9, 96.8] | 6/0/0/2 | 12/2/6/10/6 |
| gpt-5.4-2026-03-05/canonical/unlabeled/mapping0/order3 | 8/8 [63.1, 100.0] | 8/0/0/0 | 16/0/0/8/8 |
| gpt-5.4-2026-03-05/coded/labeled/mapping0/order0 | 2/8 [3.2, 65.1] | 2/0/0/6 | 4/6/18/14/2 |
| gpt-5.4-2026-03-05/coded/labeled/mapping0/order1 | 4/8 [15.7, 84.3] | 4/0/0/4 | 8/4/12/12/4 |
| gpt-5.4-2026-03-05/coded/labeled/mapping0/order2 | 5/8 [24.5, 91.5] | 5/0/0/3 | 10/3/9/11/5 |
| gpt-5.4-2026-03-05/coded/labeled/mapping0/order3 | 8/8 [63.1, 100.0] | 8/0/0/0 | 16/0/0/8/8 |
| gpt-5.4-2026-03-05/coded/labeled/mapping1/order0 | 6/8 [34.9, 96.8] | 6/0/0/2 | 12/2/6/10/6 |
| gpt-5.4-2026-03-05/coded/labeled/mapping1/order1 | 4/8 [15.7, 84.3] | 4/0/0/4 | 8/4/12/12/4 |
| gpt-5.4-2026-03-05/coded/labeled/mapping1/order2 | 5/8 [24.5, 91.5] | 5/0/0/3 | 10/3/9/11/5 |
| gpt-5.4-2026-03-05/coded/labeled/mapping1/order3 | 7/8 [47.3, 99.7] | 7/0/0/1 | 14/1/3/9/7 |
| gpt-5.4-2026-03-05/coded/labeled/mapping2/order0 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-5.4-2026-03-05/coded/labeled/mapping2/order1 | 3/8 [8.5, 75.5] | 3/0/0/5 | 6/5/15/13/3 |
| gpt-5.4-2026-03-05/coded/labeled/mapping2/order2 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-5.4-2026-03-05/coded/labeled/mapping2/order3 | 6/8 +1 missing [34.9, 99.7] | 6/0/0/1 | 12/1/3/8/6 |
| gpt-5.4-2026-03-05/coded/labeled/mapping3/order0 | 5/8 [24.5, 91.5] | 5/0/0/3 | 10/3/9/11/5 |
| gpt-5.4-2026-03-05/coded/labeled/mapping3/order1 | 5/8 [24.5, 91.5] | 5/0/0/3 | 10/3/9/11/5 |
| gpt-5.4-2026-03-05/coded/labeled/mapping3/order2 | 3/8 +1 missing [8.5, 84.3] | 3/0/0/4 | 6/4/12/11/3 |
| gpt-5.4-2026-03-05/coded/labeled/mapping3/order3 | 8/8 [63.1, 100.0] | 8/0/0/0 | 16/0/0/8/8 |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping0/order0 | 2/8 [3.2, 65.1] | 2/0/0/6 | 4/6/18/14/2 |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping0/order1 | 5/8 [24.5, 91.5] | 5/0/0/3 | 10/3/9/11/5 |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping0/order2 | 4/8 [15.7, 84.3] | 4/0/0/4 | 8/4/12/12/4 |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping0/order3 | 8/8 [63.1, 100.0] | 8/0/0/0 | 16/0/0/8/8 |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping1/order0 | 6/8 [34.9, 96.8] | 6/0/0/2 | 12/2/6/10/6 |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping1/order1 | 7/8 [47.3, 99.7] | 7/0/0/1 | 14/1/3/9/7 |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping1/order2 | 5/8 [24.5, 91.5] | 5/0/0/3 | 10/3/9/11/5 |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping1/order3 | 8/8 [63.1, 100.0] | 8/0/0/0 | 16/0/0/8/8 |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping2/order0 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping2/order1 | 5/8 [24.5, 91.5] | 5/0/0/3 | 10/3/9/11/5 |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping2/order2 | 4/8 [15.7, 84.3] | 4/0/0/4 | 8/4/12/12/4 |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping2/order3 | 5/8 [24.5, 91.5] | 5/0/0/3 | 10/3/9/11/5 |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping3/order0 | 4/8 [15.7, 84.3] | 4/0/0/4 | 8/4/12/12/4 |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping3/order1 | 6/8 [34.9, 96.8] | 6/0/0/2 | 12/2/6/10/6 |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping3/order2 | 8/8 [63.1, 100.0] | 8/0/0/0 | 16/0/0/8/8 |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping3/order3 | 6/8 [34.9, 96.8] | 6/0/2/0 | 12/2/6/10/6 |
| gpt-5.4-mini-2026-03-17/canonical/labeled/mapping0/order0 | 7/8 [47.3, 99.7] | 7/0/0/1 | 14/1/3/9/7 |
| gpt-5.4-mini-2026-03-17/canonical/labeled/mapping0/order1 | 6/8 [34.9, 96.8] | 6/0/1/1 | 12/2/6/10/6 |
| gpt-5.4-mini-2026-03-17/canonical/labeled/mapping0/order2 | 8/8 [63.1, 100.0] | 8/0/0/0 | 16/0/0/8/8 |
| gpt-5.4-mini-2026-03-17/canonical/labeled/mapping0/order3 | 8/8 [63.1, 100.0] | 8/0/0/0 | 16/0/0/8/8 |
| gpt-5.4-mini-2026-03-17/canonical/unlabeled/mapping0/order0 | 6/8 [34.9, 96.8] | 6/0/0/2 | 12/2/6/10/6 |
| gpt-5.4-mini-2026-03-17/canonical/unlabeled/mapping0/order1 | 7/8 [47.3, 99.7] | 7/0/0/1 | 14/1/3/9/7 |
| gpt-5.4-mini-2026-03-17/canonical/unlabeled/mapping0/order2 | 7/8 [47.3, 99.7] | 7/1/0/0 | 14/1/0/9/9 |
| gpt-5.4-mini-2026-03-17/canonical/unlabeled/mapping0/order3 | 7/8 [47.3, 99.7] | 7/0/0/1 | 14/1/3/9/7 |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping0/order0 | 6/8 [34.9, 96.8] | 6/1/0/1 | 12/2/3/10/8 |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping0/order1 | 6/8 [34.9, 96.8] | 6/0/0/2 | 12/2/6/10/6 |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping0/order2 | 7/8 [47.3, 99.7] | 7/0/1/0 | 14/1/3/9/7 |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping0/order3 | 7/8 [47.3, 99.7] | 7/0/0/1 | 14/1/3/9/7 |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping1/order0 | 7/8 [47.3, 99.7] | 7/0/0/1 | 14/1/3/9/7 |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping1/order1 | 5/8 [24.5, 91.5] | 5/0/3/0 | 10/3/9/11/5 |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping1/order2 | 3/8 +1 missing [8.5, 84.3] | 3/0/4/0 | 6/4/12/11/3 |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping1/order3 | 7/8 [47.3, 99.7] | 7/0/0/1 | 14/1/3/9/7 |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping2/order0 | 7/8 [47.3, 99.7] | 7/0/1/0 | 14/1/3/9/7 |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping2/order1 | 3/8 [8.5, 75.5] | 3/2/1/2 | 6/5/9/13/7 |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping2/order2 | 8/8 [63.1, 100.0] | 8/0/0/0 | 16/0/0/8/8 |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping2/order3 | 8/8 [63.1, 100.0] | 8/0/0/0 | 16/0/0/8/8 |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping3/order0 | 8/8 [63.1, 100.0] | 8/0/0/0 | 16/0/0/8/8 |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping3/order1 | 6/8 [34.9, 96.8] | 6/0/0/2 | 12/2/6/10/6 |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping3/order2 | 7/8 [47.3, 99.7] | 7/0/1/0 | 14/1/3/9/7 |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping3/order3 | 8/8 [63.1, 100.0] | 8/0/0/0 | 16/0/0/8/8 |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping0/order0 | 8/8 [63.1, 100.0] | 8/0/0/0 | 16/0/0/8/8 |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping0/order1 | 6/8 [34.9, 96.8] | 6/0/0/2 | 12/2/6/10/6 |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping0/order2 | 8/8 [63.1, 100.0] | 8/0/0/0 | 16/0/0/8/8 |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping0/order3 | 4/8 [15.7, 84.3] | 4/0/0/4 | 8/4/12/12/4 |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping1/order0 | 6/8 [34.9, 96.8] | 6/2/0/0 | 12/2/0/10/10 |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping1/order1 | 6/8 [34.9, 96.8] | 6/0/0/2 | 12/2/6/10/6 |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping1/order2 | 8/8 [63.1, 100.0] | 8/0/0/0 | 16/0/0/8/8 |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping1/order3 | 7/8 [47.3, 99.7] | 7/0/0/1 | 14/1/3/9/7 |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping2/order0 | 7/8 +1 missing [47.3, 100.0] | 7/0/0/0 | 14/0/0/7/7 |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping2/order1 | 6/8 [34.9, 96.8] | 6/0/0/2 | 12/2/6/10/6 |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping2/order2 | 8/8 [63.1, 100.0] | 8/0/0/0 | 16/0/0/8/8 |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping2/order3 | 5/8 [24.5, 91.5] | 5/1/0/2 | 10/3/6/11/7 |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping3/order0 | 7/8 [47.3, 99.7] | 7/1/0/0 | 14/1/0/9/9 |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping3/order1 | 8/8 [63.1, 100.0] | 8/0/0/0 | 16/0/0/8/8 |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping3/order2 | 6/8 [34.9, 96.8] | 6/0/0/2 | 12/2/6/10/6 |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping3/order3 | 7/8 [47.3, 99.7] | 7/0/0/1 | 14/1/3/9/7 |
| gpt-5.6-luna/canonical/labeled/mapping0/order0 | 6/8 [34.9, 96.8] | 6/0/0/2 | 12/2/6/10/6 |
| gpt-5.6-luna/canonical/labeled/mapping0/order1 | 7/8 [47.3, 99.7] | 7/0/0/1 | 14/1/3/9/7 |
| gpt-5.6-luna/canonical/labeled/mapping0/order2 | 7/8 [47.3, 99.7] | 7/0/0/1 | 14/1/3/9/7 |
| gpt-5.6-luna/canonical/labeled/mapping0/order3 | 5/8 [24.5, 91.5] | 5/0/0/3 | 10/3/9/11/5 |
| gpt-5.6-luna/canonical/unlabeled/mapping0/order0 | 7/8 +1 missing [47.3, 100.0] | 7/0/0/0 | 14/0/0/7/7 |
| gpt-5.6-luna/canonical/unlabeled/mapping0/order1 | 6/8 [34.9, 96.8] | 6/0/0/2 | 12/2/6/10/6 |
| gpt-5.6-luna/canonical/unlabeled/mapping0/order2 | 4/8 [15.7, 84.3] | 4/0/0/4 | 8/4/12/12/4 |
| gpt-5.6-luna/canonical/unlabeled/mapping0/order3 | 3/8 [8.5, 75.5] | 3/0/0/5 | 6/5/15/13/3 |
| gpt-5.6-luna/coded/labeled/mapping0/order0 | 4/8 [15.7, 84.3] | 4/0/0/4 | 8/4/12/12/4 |
| gpt-5.6-luna/coded/labeled/mapping0/order1 | 2/8 [3.2, 65.1] | 2/0/0/6 | 4/6/18/14/2 |
| gpt-5.6-luna/coded/labeled/mapping0/order2 | 6/8 [34.9, 96.8] | 6/0/0/2 | 12/2/6/10/6 |
| gpt-5.6-luna/coded/labeled/mapping0/order3 | 4/8 [15.7, 84.3] | 4/0/0/4 | 8/4/12/12/4 |
| gpt-5.6-luna/coded/labeled/mapping1/order0 | 5/8 [24.5, 91.5] | 5/0/0/3 | 10/3/9/11/5 |
| gpt-5.6-luna/coded/labeled/mapping1/order1 | 2/8 [3.2, 65.1] | 2/0/0/6 | 4/6/18/14/2 |
| gpt-5.6-luna/coded/labeled/mapping1/order2 | 5/8 [24.5, 91.5] | 5/0/0/3 | 10/3/9/11/5 |
| gpt-5.6-luna/coded/labeled/mapping1/order3 | 4/8 [15.7, 84.3] | 4/1/0/3 | 8/4/9/12/6 |
| gpt-5.6-luna/coded/labeled/mapping2/order0 | 4/8 [15.7, 84.3] | 4/0/0/4 | 8/4/12/12/4 |
| gpt-5.6-luna/coded/labeled/mapping2/order1 | 4/8 [15.7, 84.3] | 4/0/0/4 | 8/4/12/12/4 |
| gpt-5.6-luna/coded/labeled/mapping2/order2 | 4/8 [15.7, 84.3] | 4/0/0/4 | 8/4/12/12/4 |
| gpt-5.6-luna/coded/labeled/mapping2/order3 | 4/8 [15.7, 84.3] | 4/0/0/4 | 8/4/12/12/4 |
| gpt-5.6-luna/coded/labeled/mapping3/order0 | 4/8 [15.7, 84.3] | 4/0/0/4 | 8/4/12/12/4 |
| gpt-5.6-luna/coded/labeled/mapping3/order1 | 2/8 [3.2, 65.1] | 2/0/0/6 | 4/6/18/14/2 |
| gpt-5.6-luna/coded/labeled/mapping3/order2 | 5/8 [24.5, 91.5] | 5/0/0/3 | 10/3/9/11/5 |
| gpt-5.6-luna/coded/labeled/mapping3/order3 | 4/8 [15.7, 84.3] | 4/0/0/4 | 8/4/12/12/4 |
| gpt-5.6-luna/coded/unlabeled/mapping0/order0 | 5/8 [24.5, 91.5] | 5/0/0/3 | 10/3/9/11/5 |
| gpt-5.6-luna/coded/unlabeled/mapping0/order1 | 3/8 [8.5, 75.5] | 3/0/0/5 | 6/5/15/13/3 |
| gpt-5.6-luna/coded/unlabeled/mapping0/order2 | 4/8 [15.7, 84.3] | 4/0/0/4 | 8/4/12/12/4 |
| gpt-5.6-luna/coded/unlabeled/mapping0/order3 | 3/8 [8.5, 75.5] | 3/0/0/5 | 6/5/15/13/3 |
| gpt-5.6-luna/coded/unlabeled/mapping1/order0 | 4/8 +1 missing [15.7, 91.5] | 4/0/0/3 | 8/3/9/10/4 |
| gpt-5.6-luna/coded/unlabeled/mapping1/order1 | 4/8 [15.7, 84.3] | 4/0/0/4 | 8/4/12/12/4 |
| gpt-5.6-luna/coded/unlabeled/mapping1/order2 | 5/8 [24.5, 91.5] | 5/0/0/3 | 10/3/9/11/5 |
| gpt-5.6-luna/coded/unlabeled/mapping1/order3 | 4/8 [15.7, 84.3] | 4/1/0/3 | 8/4/9/12/6 |
| gpt-5.6-luna/coded/unlabeled/mapping2/order0 | 4/8 [15.7, 84.3] | 4/0/0/4 | 8/4/12/12/4 |
| gpt-5.6-luna/coded/unlabeled/mapping2/order1 | 4/8 [15.7, 84.3] | 4/0/0/4 | 8/4/12/12/4 |
| gpt-5.6-luna/coded/unlabeled/mapping2/order2 | 4/8 [15.7, 84.3] | 4/0/0/4 | 8/4/12/12/4 |
| gpt-5.6-luna/coded/unlabeled/mapping2/order3 | 4/8 [15.7, 84.3] | 4/0/0/4 | 8/4/12/12/4 |
| gpt-5.6-luna/coded/unlabeled/mapping3/order0 | 4/8 [15.7, 84.3] | 4/0/0/4 | 8/4/12/12/4 |
| gpt-5.6-luna/coded/unlabeled/mapping3/order1 | 3/8 [8.5, 75.5] | 3/0/0/5 | 6/5/15/13/3 |
| gpt-5.6-luna/coded/unlabeled/mapping3/order2 | 4/8 [15.7, 84.3] | 4/0/0/4 | 8/4/12/12/4 |
| gpt-5.6-luna/coded/unlabeled/mapping3/order3 | 4/8 [15.7, 84.3] | 4/1/0/3 | 8/4/9/12/6 |
| gpt-5.6-sol/canonical/labeled/mapping0/order0 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-5.6-sol/canonical/labeled/mapping0/order1 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-5.6-sol/canonical/labeled/mapping0/order2 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-5.6-sol/canonical/labeled/mapping0/order3 | 0/8 +1 missing [0.0, 52.7] | 0/0/0/7 | 0/7/21/14/0 |
| gpt-5.6-sol/canonical/unlabeled/mapping0/order0 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-5.6-sol/canonical/unlabeled/mapping0/order1 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-5.6-sol/canonical/unlabeled/mapping0/order2 | 1/8 [0.3, 52.7] | 1/0/0/7 | 2/7/21/15/1 |
| gpt-5.6-sol/canonical/unlabeled/mapping0/order3 | 1/8 [0.3, 52.7] | 1/0/0/7 | 2/7/21/15/1 |
| gpt-5.6-sol/coded/labeled/mapping0/order0 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-5.6-sol/coded/labeled/mapping0/order1 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-5.6-sol/coded/labeled/mapping0/order2 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-5.6-sol/coded/labeled/mapping0/order3 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-5.6-sol/coded/labeled/mapping1/order0 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-5.6-sol/coded/labeled/mapping1/order1 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-5.6-sol/coded/labeled/mapping1/order2 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-5.6-sol/coded/labeled/mapping1/order3 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-5.6-sol/coded/labeled/mapping2/order0 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-5.6-sol/coded/labeled/mapping2/order1 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-5.6-sol/coded/labeled/mapping2/order2 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-5.6-sol/coded/labeled/mapping2/order3 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-5.6-sol/coded/labeled/mapping3/order0 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-5.6-sol/coded/labeled/mapping3/order1 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-5.6-sol/coded/labeled/mapping3/order2 | 0/8 +1 missing [0.0, 52.7] | 0/0/0/7 | 0/7/21/14/0 |
| gpt-5.6-sol/coded/labeled/mapping3/order3 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-5.6-sol/coded/unlabeled/mapping0/order0 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-5.6-sol/coded/unlabeled/mapping0/order1 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-5.6-sol/coded/unlabeled/mapping0/order2 | 2/8 [3.2, 65.1] | 2/0/0/6 | 4/6/18/14/2 |
| gpt-5.6-sol/coded/unlabeled/mapping0/order3 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-5.6-sol/coded/unlabeled/mapping1/order0 | 2/8 [3.2, 65.1] | 2/0/0/6 | 4/6/18/14/2 |
| gpt-5.6-sol/coded/unlabeled/mapping1/order1 | 2/8 [3.2, 65.1] | 2/0/0/6 | 4/6/18/14/2 |
| gpt-5.6-sol/coded/unlabeled/mapping1/order2 | 3/8 [8.5, 75.5] | 3/0/0/5 | 6/5/15/13/3 |
| gpt-5.6-sol/coded/unlabeled/mapping1/order3 | 3/8 [8.5, 75.5] | 3/0/0/5 | 6/5/15/13/3 |
| gpt-5.6-sol/coded/unlabeled/mapping2/order0 | 2/8 [3.2, 65.1] | 2/0/0/6 | 4/6/18/14/2 |
| gpt-5.6-sol/coded/unlabeled/mapping2/order1 | 3/8 [8.5, 75.5] | 3/0/0/5 | 6/5/15/13/3 |
| gpt-5.6-sol/coded/unlabeled/mapping2/order2 | 4/8 [15.7, 84.3] | 4/0/0/4 | 8/4/12/12/4 |
| gpt-5.6-sol/coded/unlabeled/mapping2/order3 | 1/8 [0.3, 52.7] | 1/0/0/7 | 2/7/21/15/1 |
| gpt-5.6-sol/coded/unlabeled/mapping3/order0 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-5.6-sol/coded/unlabeled/mapping3/order1 | 2/8 [3.2, 65.1] | 2/0/0/6 | 4/6/18/14/2 |
| gpt-5.6-sol/coded/unlabeled/mapping3/order2 | 1/8 [0.3, 52.7] | 1/0/0/7 | 2/7/21/15/1 |
| gpt-5.6-sol/coded/unlabeled/mapping3/order3 | 2/8 [3.2, 65.1] | 2/0/0/6 | 4/6/18/14/2 |
| gpt-5.6-terra/canonical/labeled/mapping0/order0 | 5/8 [24.5, 91.5] | 5/0/0/3 | 10/3/9/11/5 |
| gpt-5.6-terra/canonical/labeled/mapping0/order1 | 8/8 [63.1, 100.0] | 8/0/0/0 | 16/0/0/8/8 |
| gpt-5.6-terra/canonical/labeled/mapping0/order2 | 8/8 [63.1, 100.0] | 8/0/0/0 | 16/0/0/8/8 |
| gpt-5.6-terra/canonical/labeled/mapping0/order3 | 8/8 [63.1, 100.0] | 8/0/0/0 | 16/0/0/8/8 |
| gpt-5.6-terra/canonical/unlabeled/mapping0/order0 | 8/8 [63.1, 100.0] | 8/0/0/0 | 16/0/0/8/8 |
| gpt-5.6-terra/canonical/unlabeled/mapping0/order1 | 8/8 [63.1, 100.0] | 8/0/0/0 | 16/0/0/8/8 |
| gpt-5.6-terra/canonical/unlabeled/mapping0/order2 | 8/8 [63.1, 100.0] | 8/0/0/0 | 16/0/0/8/8 |
| gpt-5.6-terra/canonical/unlabeled/mapping0/order3 | 8/8 [63.1, 100.0] | 8/0/0/0 | 16/0/0/8/8 |
| gpt-5.6-terra/coded/labeled/mapping0/order0 | 8/8 [63.1, 100.0] | 8/0/0/0 | 16/0/0/8/8 |
| gpt-5.6-terra/coded/labeled/mapping0/order1 | 6/8 [34.9, 96.8] | 6/0/0/2 | 12/2/6/10/6 |
| gpt-5.6-terra/coded/labeled/mapping0/order2 | 6/8 [34.9, 96.8] | 6/0/0/2 | 12/2/6/10/6 |
| gpt-5.6-terra/coded/labeled/mapping0/order3 | 8/8 [63.1, 100.0] | 8/0/0/0 | 16/0/0/8/8 |
| gpt-5.6-terra/coded/labeled/mapping1/order0 | 3/8 [8.5, 75.5] | 3/0/0/5 | 6/5/15/13/3 |
| gpt-5.6-terra/coded/labeled/mapping1/order1 | 5/8 [24.5, 91.5] | 5/0/0/3 | 10/3/9/11/5 |
| gpt-5.6-terra/coded/labeled/mapping1/order2 | 7/8 [47.3, 99.7] | 7/0/0/1 | 14/1/3/9/7 |
| gpt-5.6-terra/coded/labeled/mapping1/order3 | 8/8 [63.1, 100.0] | 8/0/0/0 | 16/0/0/8/8 |
| gpt-5.6-terra/coded/labeled/mapping2/order0 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-5.6-terra/coded/labeled/mapping2/order1 | 4/8 [15.7, 84.3] | 4/0/0/4 | 8/4/12/12/4 |
| gpt-5.6-terra/coded/labeled/mapping2/order2 | 5/8 +1 missing [24.5, 96.8] | 5/0/0/2 | 10/2/6/9/5 |
| gpt-5.6-terra/coded/labeled/mapping2/order3 | 6/8 [34.9, 96.8] | 6/0/0/2 | 12/2/6/10/6 |
| gpt-5.6-terra/coded/labeled/mapping3/order0 | 3/8 [8.5, 75.5] | 3/0/0/5 | 6/5/15/13/3 |
| gpt-5.6-terra/coded/labeled/mapping3/order1 | 8/8 [63.1, 100.0] | 8/0/0/0 | 16/0/0/8/8 |
| gpt-5.6-terra/coded/labeled/mapping3/order2 | 3/8 [8.5, 75.5] | 3/0/0/5 | 6/5/15/13/3 |
| gpt-5.6-terra/coded/labeled/mapping3/order3 | 4/8 +1 missing [15.7, 91.5] | 4/0/0/3 | 8/3/9/10/4 |
| gpt-5.6-terra/coded/unlabeled/mapping0/order0 | 8/8 [63.1, 100.0] | 8/0/0/0 | 16/0/0/8/8 |
| gpt-5.6-terra/coded/unlabeled/mapping0/order1 | 8/8 [63.1, 100.0] | 8/0/0/0 | 16/0/0/8/8 |
| gpt-5.6-terra/coded/unlabeled/mapping0/order2 | 8/8 [63.1, 100.0] | 8/0/0/0 | 16/0/0/8/8 |
| gpt-5.6-terra/coded/unlabeled/mapping0/order3 | 8/8 [63.1, 100.0] | 8/0/0/0 | 16/0/0/8/8 |
| gpt-5.6-terra/coded/unlabeled/mapping1/order0 | 5/8 [24.5, 91.5] | 5/0/0/3 | 10/3/9/11/5 |
| gpt-5.6-terra/coded/unlabeled/mapping1/order1 | 7/8 [47.3, 99.7] | 7/0/0/1 | 14/1/3/9/7 |
| gpt-5.6-terra/coded/unlabeled/mapping1/order2 | 8/8 [63.1, 100.0] | 8/0/0/0 | 16/0/0/8/8 |
| gpt-5.6-terra/coded/unlabeled/mapping1/order3 | 6/8 [34.9, 96.8] | 6/0/0/2 | 12/2/6/10/6 |
| gpt-5.6-terra/coded/unlabeled/mapping2/order0 | 5/8 [24.5, 91.5] | 5/0/0/3 | 10/3/9/11/5 |
| gpt-5.6-terra/coded/unlabeled/mapping2/order1 | 5/8 [24.5, 91.5] | 5/0/0/3 | 10/3/9/11/5 |
| gpt-5.6-terra/coded/unlabeled/mapping2/order2 | 7/8 [47.3, 99.7] | 7/0/0/1 | 14/1/3/9/7 |
| gpt-5.6-terra/coded/unlabeled/mapping2/order3 | 7/8 [47.3, 99.7] | 7/0/0/1 | 14/1/3/9/7 |
| gpt-5.6-terra/coded/unlabeled/mapping3/order0 | 7/8 [47.3, 99.7] | 7/0/0/1 | 14/1/3/9/7 |
| gpt-5.6-terra/coded/unlabeled/mapping3/order1 | 8/8 [63.1, 100.0] | 8/0/0/0 | 16/0/0/8/8 |
| gpt-5.6-terra/coded/unlabeled/mapping3/order2 | 7/8 [47.3, 99.7] | 7/0/0/1 | 14/1/3/9/7 |
| gpt-5.6-terra/coded/unlabeled/mapping3/order3 | 7/8 [47.3, 99.7] | 7/0/0/1 | 14/1/3/9/7 |
| gpt-6-astra/canonical/labeled/mapping0/order0 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-6-astra/canonical/labeled/mapping0/order1 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-6-astra/canonical/labeled/mapping0/order2 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-6-astra/canonical/labeled/mapping0/order3 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-6-astra/canonical/unlabeled/mapping0/order0 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-6-astra/canonical/unlabeled/mapping0/order1 | 0/8 +1 missing [0.0, 52.7] | 0/0/0/7 | 0/7/21/14/0 |
| gpt-6-astra/canonical/unlabeled/mapping0/order2 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-6-astra/canonical/unlabeled/mapping0/order3 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-6-astra/coded/labeled/mapping0/order0 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-6-astra/coded/labeled/mapping0/order1 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-6-astra/coded/labeled/mapping0/order2 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-6-astra/coded/labeled/mapping0/order3 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-6-astra/coded/labeled/mapping1/order0 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-6-astra/coded/labeled/mapping1/order1 | 0/8 +1 missing [0.0, 52.7] | 0/0/0/7 | 0/7/21/14/0 |
| gpt-6-astra/coded/labeled/mapping1/order2 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-6-astra/coded/labeled/mapping1/order3 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-6-astra/coded/labeled/mapping2/order0 | 0/8 +1 missing [0.0, 52.7] | 0/0/0/7 | 0/7/21/14/0 |
| gpt-6-astra/coded/labeled/mapping2/order1 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-6-astra/coded/labeled/mapping2/order2 | 0/8 +1 missing [0.0, 52.7] | 0/0/0/7 | 0/7/21/14/0 |
| gpt-6-astra/coded/labeled/mapping2/order3 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-6-astra/coded/labeled/mapping3/order0 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-6-astra/coded/labeled/mapping3/order1 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-6-astra/coded/labeled/mapping3/order2 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-6-astra/coded/labeled/mapping3/order3 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-6-astra/coded/unlabeled/mapping0/order0 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-6-astra/coded/unlabeled/mapping0/order1 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-6-astra/coded/unlabeled/mapping0/order2 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-6-astra/coded/unlabeled/mapping0/order3 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-6-astra/coded/unlabeled/mapping1/order0 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-6-astra/coded/unlabeled/mapping1/order1 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-6-astra/coded/unlabeled/mapping1/order2 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-6-astra/coded/unlabeled/mapping1/order3 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-6-astra/coded/unlabeled/mapping2/order0 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-6-astra/coded/unlabeled/mapping2/order1 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-6-astra/coded/unlabeled/mapping2/order2 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-6-astra/coded/unlabeled/mapping2/order3 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-6-astra/coded/unlabeled/mapping3/order0 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-6-astra/coded/unlabeled/mapping3/order1 | 0/8 +1 missing [0.0, 52.7] | 0/0/0/7 | 0/7/21/14/0 |
| gpt-6-astra/coded/unlabeled/mapping3/order2 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |
| gpt-6-astra/coded/unlabeled/mapping3/order3 | 0/8 [0.0, 36.9] | 0/0/0/8 | 0/8/24/16/0 |

## Complete task/format cells

| Condition/task | Retry count [reference limits] |
| --- | --- |
| gpt-5.4-2026-03-05/canonical/labeled/ci-001 | 4/8 [15.7, 84.3] |
| gpt-5.4-2026-03-05/canonical/labeled/issue-001 | 8/8 [63.1, 100.0] |
| gpt-5.4-2026-03-05/canonical/labeled/mapping0/order0/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-2026-03-05/canonical/labeled/mapping0/order0/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/canonical/labeled/mapping0/order0/release-001 | 1/2 [1.3, 98.7] |
| gpt-5.4-2026-03-05/canonical/labeled/mapping0/order0/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-2026-03-05/canonical/labeled/mapping0/order1/ci-001 | 1/2 [1.3, 98.7] |
| gpt-5.4-2026-03-05/canonical/labeled/mapping0/order1/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/canonical/labeled/mapping0/order1/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/canonical/labeled/mapping0/order1/review-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/canonical/labeled/mapping0/order2/ci-001 | 1/2 [1.3, 98.7] |
| gpt-5.4-2026-03-05/canonical/labeled/mapping0/order2/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/canonical/labeled/mapping0/order2/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/canonical/labeled/mapping0/order2/review-001 | 1/2 [1.3, 98.7] |
| gpt-5.4-2026-03-05/canonical/labeled/mapping0/order3/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/canonical/labeled/mapping0/order3/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/canonical/labeled/mapping0/order3/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/canonical/labeled/mapping0/order3/review-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/canonical/labeled/release-001 | 7/8 [47.3, 99.7] |
| gpt-5.4-2026-03-05/canonical/labeled/review-001 | 5/8 [24.5, 91.5] |
| gpt-5.4-2026-03-05/canonical/unlabeled/ci-001 | 5/8 [24.5, 91.5] |
| gpt-5.4-2026-03-05/canonical/unlabeled/issue-001 | 8/8 [63.1, 100.0] |
| gpt-5.4-2026-03-05/canonical/unlabeled/mapping0/order0/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-2026-03-05/canonical/unlabeled/mapping0/order0/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/canonical/unlabeled/mapping0/order0/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/canonical/unlabeled/mapping0/order0/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-2026-03-05/canonical/unlabeled/mapping0/order1/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/canonical/unlabeled/mapping0/order1/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/canonical/unlabeled/mapping0/order1/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/canonical/unlabeled/mapping0/order1/review-001 | 1/2 [1.3, 98.7] |
| gpt-5.4-2026-03-05/canonical/unlabeled/mapping0/order2/ci-001 | 1/2 [1.3, 98.7] |
| gpt-5.4-2026-03-05/canonical/unlabeled/mapping0/order2/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/canonical/unlabeled/mapping0/order2/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/canonical/unlabeled/mapping0/order2/review-001 | 1/2 [1.3, 98.7] |
| gpt-5.4-2026-03-05/canonical/unlabeled/mapping0/order3/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/canonical/unlabeled/mapping0/order3/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/canonical/unlabeled/mapping0/order3/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/canonical/unlabeled/mapping0/order3/review-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/canonical/unlabeled/release-001 | 8/8 [63.1, 100.0] |
| gpt-5.4-2026-03-05/canonical/unlabeled/review-001 | 4/8 [15.7, 84.3] |
| gpt-5.4-2026-03-05/coded/labeled/ci-001 | 6/32 +1 missing [7.2, 40.0] |
| gpt-5.4-2026-03-05/coded/labeled/issue-001 | 27/32 +1 missing [67.2, 96.5] |
| gpt-5.4-2026-03-05/coded/labeled/mapping0/order0/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-2026-03-05/coded/labeled/mapping0/order0/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/labeled/mapping0/order0/release-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-2026-03-05/coded/labeled/mapping0/order0/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-2026-03-05/coded/labeled/mapping0/order1/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-2026-03-05/coded/labeled/mapping0/order1/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/labeled/mapping0/order1/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/labeled/mapping0/order1/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-2026-03-05/coded/labeled/mapping0/order2/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-2026-03-05/coded/labeled/mapping0/order2/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/labeled/mapping0/order2/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/labeled/mapping0/order2/review-001 | 1/2 [1.3, 98.7] |
| gpt-5.4-2026-03-05/coded/labeled/mapping0/order3/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/labeled/mapping0/order3/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/labeled/mapping0/order3/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/labeled/mapping0/order3/review-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/labeled/mapping1/order0/ci-001 | 1/2 [1.3, 98.7] |
| gpt-5.4-2026-03-05/coded/labeled/mapping1/order0/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/labeled/mapping1/order0/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/labeled/mapping1/order0/review-001 | 1/2 [1.3, 98.7] |
| gpt-5.4-2026-03-05/coded/labeled/mapping1/order1/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-2026-03-05/coded/labeled/mapping1/order1/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/labeled/mapping1/order1/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/labeled/mapping1/order1/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-2026-03-05/coded/labeled/mapping1/order2/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-2026-03-05/coded/labeled/mapping1/order2/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/labeled/mapping1/order2/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/labeled/mapping1/order2/review-001 | 1/2 [1.3, 98.7] |
| gpt-5.4-2026-03-05/coded/labeled/mapping1/order3/ci-001 | 1/2 [1.3, 98.7] |
| gpt-5.4-2026-03-05/coded/labeled/mapping1/order3/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/labeled/mapping1/order3/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/labeled/mapping1/order3/review-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/labeled/mapping2/order0/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-2026-03-05/coded/labeled/mapping2/order0/issue-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-2026-03-05/coded/labeled/mapping2/order0/release-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-2026-03-05/coded/labeled/mapping2/order0/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-2026-03-05/coded/labeled/mapping2/order1/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-2026-03-05/coded/labeled/mapping2/order1/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/labeled/mapping2/order1/release-001 | 1/2 [1.3, 98.7] |
| gpt-5.4-2026-03-05/coded/labeled/mapping2/order1/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-2026-03-05/coded/labeled/mapping2/order2/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-2026-03-05/coded/labeled/mapping2/order2/issue-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-2026-03-05/coded/labeled/mapping2/order2/release-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-2026-03-05/coded/labeled/mapping2/order2/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-2026-03-05/coded/labeled/mapping2/order3/ci-001 | 0/2 +1 missing [0.0, 98.7] |
| gpt-5.4-2026-03-05/coded/labeled/mapping2/order3/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/labeled/mapping2/order3/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/labeled/mapping2/order3/review-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/labeled/mapping3/order0/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-2026-03-05/coded/labeled/mapping3/order0/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/labeled/mapping3/order0/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/labeled/mapping3/order0/review-001 | 1/2 [1.3, 98.7] |
| gpt-5.4-2026-03-05/coded/labeled/mapping3/order1/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-2026-03-05/coded/labeled/mapping3/order1/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/labeled/mapping3/order1/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/labeled/mapping3/order1/review-001 | 1/2 [1.3, 98.7] |
| gpt-5.4-2026-03-05/coded/labeled/mapping3/order2/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-2026-03-05/coded/labeled/mapping3/order2/issue-001 | 1/2 +1 missing [1.3, 100.0] |
| gpt-5.4-2026-03-05/coded/labeled/mapping3/order2/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/labeled/mapping3/order2/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-2026-03-05/coded/labeled/mapping3/order3/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/labeled/mapping3/order3/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/labeled/mapping3/order3/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/labeled/mapping3/order3/review-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/labeled/release-001 | 25/32 [60.0, 90.7] |
| gpt-5.4-2026-03-05/coded/labeled/review-001 | 13/32 [23.7, 59.4] |
| gpt-5.4-2026-03-05/coded/unlabeled/ci-001 | 18/32 [37.7, 73.6] |
| gpt-5.4-2026-03-05/coded/unlabeled/issue-001 | 30/32 [79.2, 99.2] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping0/order0/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping0/order0/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping0/order0/release-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping0/order0/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping0/order1/ci-001 | 1/2 [1.3, 98.7] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping0/order1/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping0/order1/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping0/order1/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping0/order2/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping0/order2/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping0/order2/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping0/order2/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping0/order3/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping0/order3/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping0/order3/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping0/order3/review-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping1/order0/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping1/order0/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping1/order0/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping1/order0/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping1/order1/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping1/order1/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping1/order1/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping1/order1/review-001 | 1/2 [1.3, 98.7] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping1/order2/ci-001 | 1/2 [1.3, 98.7] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping1/order2/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping1/order2/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping1/order2/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping1/order3/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping1/order3/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping1/order3/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping1/order3/review-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping2/order0/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping2/order0/issue-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping2/order0/release-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping2/order0/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping2/order1/ci-001 | 1/2 [1.3, 98.7] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping2/order1/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping2/order1/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping2/order1/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping2/order2/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping2/order2/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping2/order2/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping2/order2/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping2/order3/ci-001 | 1/2 [1.3, 98.7] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping2/order3/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping2/order3/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping2/order3/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping3/order0/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping3/order0/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping3/order0/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping3/order0/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping3/order1/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping3/order1/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping3/order1/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping3/order1/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping3/order2/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping3/order2/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping3/order2/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping3/order2/review-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping3/order3/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping3/order3/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping3/order3/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-2026-03-05/coded/unlabeled/mapping3/order3/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-2026-03-05/coded/unlabeled/release-001 | 28/32 [71.0, 96.5] |
| gpt-5.4-2026-03-05/coded/unlabeled/review-001 | 7/32 [9.3, 40.0] |
| gpt-5.4-mini-2026-03-17/canonical/labeled/ci-001 | 7/8 [47.3, 99.7] |
| gpt-5.4-mini-2026-03-17/canonical/labeled/issue-001 | 8/8 [63.1, 100.0] |
| gpt-5.4-mini-2026-03-17/canonical/labeled/mapping0/order0/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/canonical/labeled/mapping0/order0/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/canonical/labeled/mapping0/order0/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/canonical/labeled/mapping0/order0/review-001 | 1/2 [1.3, 98.7] |
| gpt-5.4-mini-2026-03-17/canonical/labeled/mapping0/order1/ci-001 | 1/2 [1.3, 98.7] |
| gpt-5.4-mini-2026-03-17/canonical/labeled/mapping0/order1/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/canonical/labeled/mapping0/order1/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/canonical/labeled/mapping0/order1/review-001 | 1/2 [1.3, 98.7] |
| gpt-5.4-mini-2026-03-17/canonical/labeled/mapping0/order2/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/canonical/labeled/mapping0/order2/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/canonical/labeled/mapping0/order2/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/canonical/labeled/mapping0/order2/review-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/canonical/labeled/mapping0/order3/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/canonical/labeled/mapping0/order3/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/canonical/labeled/mapping0/order3/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/canonical/labeled/mapping0/order3/review-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/canonical/labeled/release-001 | 8/8 [63.1, 100.0] |
| gpt-5.4-mini-2026-03-17/canonical/labeled/review-001 | 6/8 [34.9, 96.8] |
| gpt-5.4-mini-2026-03-17/canonical/unlabeled/ci-001 | 8/8 [63.1, 100.0] |
| gpt-5.4-mini-2026-03-17/canonical/unlabeled/issue-001 | 8/8 [63.1, 100.0] |
| gpt-5.4-mini-2026-03-17/canonical/unlabeled/mapping0/order0/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/canonical/unlabeled/mapping0/order0/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/canonical/unlabeled/mapping0/order0/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/canonical/unlabeled/mapping0/order0/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-mini-2026-03-17/canonical/unlabeled/mapping0/order1/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/canonical/unlabeled/mapping0/order1/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/canonical/unlabeled/mapping0/order1/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/canonical/unlabeled/mapping0/order1/review-001 | 1/2 [1.3, 98.7] |
| gpt-5.4-mini-2026-03-17/canonical/unlabeled/mapping0/order2/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/canonical/unlabeled/mapping0/order2/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/canonical/unlabeled/mapping0/order2/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/canonical/unlabeled/mapping0/order2/review-001 | 1/2 [1.3, 98.7] |
| gpt-5.4-mini-2026-03-17/canonical/unlabeled/mapping0/order3/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/canonical/unlabeled/mapping0/order3/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/canonical/unlabeled/mapping0/order3/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/canonical/unlabeled/mapping0/order3/review-001 | 1/2 [1.3, 98.7] |
| gpt-5.4-mini-2026-03-17/canonical/unlabeled/release-001 | 8/8 [63.1, 100.0] |
| gpt-5.4-mini-2026-03-17/canonical/unlabeled/review-001 | 3/8 [8.5, 75.5] |
| gpt-5.4-mini-2026-03-17/coded/labeled/ci-001 | 27/32 [67.2, 94.7] |
| gpt-5.4-mini-2026-03-17/coded/labeled/issue-001 | 29/32 [75.0, 98.0] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping0/order0/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping0/order0/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping0/order0/release-001 | 1/2 [1.3, 98.7] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping0/order0/review-001 | 1/2 [1.3, 98.7] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping0/order1/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping0/order1/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping0/order1/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping0/order1/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping0/order2/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping0/order2/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping0/order2/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping0/order2/review-001 | 1/2 [1.3, 98.7] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping0/order3/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping0/order3/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping0/order3/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping0/order3/review-001 | 1/2 [1.3, 98.7] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping1/order0/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping1/order0/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping1/order0/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping1/order0/review-001 | 1/2 [1.3, 98.7] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping1/order1/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping1/order1/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping1/order1/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping1/order1/review-001 | 1/2 [1.3, 98.7] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping1/order2/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping1/order2/issue-001 | 1/2 [1.3, 98.7] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping1/order2/release-001 | 0/2 +1 missing [0.0, 98.7] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping1/order2/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping1/order3/ci-001 | 1/2 [1.3, 98.7] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping1/order3/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping1/order3/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping1/order3/review-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping2/order0/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping2/order0/issue-001 | 1/2 [1.3, 98.7] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping2/order0/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping2/order0/review-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping2/order1/ci-001 | 1/2 [1.3, 98.7] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping2/order1/issue-001 | 1/2 [1.3, 98.7] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping2/order1/release-001 | 1/2 [1.3, 98.7] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping2/order1/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping2/order2/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping2/order2/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping2/order2/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping2/order2/review-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping2/order3/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping2/order3/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping2/order3/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping2/order3/review-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping3/order0/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping3/order0/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping3/order0/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping3/order0/review-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping3/order1/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping3/order1/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping3/order1/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping3/order1/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping3/order2/ci-001 | 1/2 [1.3, 98.7] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping3/order2/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping3/order2/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping3/order2/review-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping3/order3/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping3/order3/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping3/order3/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/labeled/mapping3/order3/review-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/labeled/release-001 | 28/32 +1 missing [71.0, 98.0] |
| gpt-5.4-mini-2026-03-17/coded/labeled/review-001 | 19/32 [40.6, 76.3] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/ci-001 | 29/32 +1 missing [75.0, 99.2] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/issue-001 | 31/32 [83.8, 99.9] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping0/order0/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping0/order0/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping0/order0/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping0/order0/review-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping0/order1/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping0/order1/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping0/order1/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping0/order1/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping0/order2/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping0/order2/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping0/order2/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping0/order2/review-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping0/order3/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping0/order3/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping0/order3/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping0/order3/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping1/order0/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping1/order0/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping1/order0/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping1/order0/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping1/order1/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping1/order1/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping1/order1/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping1/order1/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping1/order2/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping1/order2/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping1/order2/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping1/order2/review-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping1/order3/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping1/order3/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping1/order3/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping1/order3/review-001 | 1/2 [1.3, 98.7] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping2/order0/ci-001 | 1/2 +1 missing [1.3, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping2/order0/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping2/order0/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping2/order0/review-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping2/order1/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping2/order1/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping2/order1/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping2/order1/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping2/order2/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping2/order2/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping2/order2/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping2/order2/review-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping2/order3/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping2/order3/issue-001 | 1/2 [1.3, 98.7] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping2/order3/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping2/order3/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping3/order0/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping3/order0/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping3/order0/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping3/order0/review-001 | 1/2 [1.3, 98.7] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping3/order1/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping3/order1/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping3/order1/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping3/order1/review-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping3/order2/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping3/order2/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping3/order2/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping3/order2/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping3/order3/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping3/order3/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping3/order3/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/mapping3/order3/review-001 | 1/2 [1.3, 98.7] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/release-001 | 32/32 [89.1, 100.0] |
| gpt-5.4-mini-2026-03-17/coded/unlabeled/review-001 | 15/32 [29.1, 65.3] |
| gpt-5.6-luna/canonical/labeled/ci-001 | 7/8 [47.3, 99.7] |
| gpt-5.6-luna/canonical/labeled/issue-001 | 8/8 [63.1, 100.0] |
| gpt-5.6-luna/canonical/labeled/mapping0/order0/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/canonical/labeled/mapping0/order0/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/canonical/labeled/mapping0/order0/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/canonical/labeled/mapping0/order0/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/canonical/labeled/mapping0/order1/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/canonical/labeled/mapping0/order1/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/canonical/labeled/mapping0/order1/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/canonical/labeled/mapping0/order1/review-001 | 1/2 [1.3, 98.7] |
| gpt-5.6-luna/canonical/labeled/mapping0/order2/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/canonical/labeled/mapping0/order2/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/canonical/labeled/mapping0/order2/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/canonical/labeled/mapping0/order2/review-001 | 1/2 [1.3, 98.7] |
| gpt-5.6-luna/canonical/labeled/mapping0/order3/ci-001 | 1/2 [1.3, 98.7] |
| gpt-5.6-luna/canonical/labeled/mapping0/order3/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/canonical/labeled/mapping0/order3/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/canonical/labeled/mapping0/order3/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/canonical/labeled/release-001 | 8/8 [63.1, 100.0] |
| gpt-5.6-luna/canonical/labeled/review-001 | 2/8 [3.2, 65.1] |
| gpt-5.6-luna/canonical/unlabeled/ci-001 | 4/8 [15.7, 84.3] |
| gpt-5.6-luna/canonical/unlabeled/issue-001 | 6/8 +1 missing [34.9, 99.7] |
| gpt-5.6-luna/canonical/unlabeled/mapping0/order0/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/canonical/unlabeled/mapping0/order0/issue-001 | 1/2 +1 missing [1.3, 100.0] |
| gpt-5.6-luna/canonical/unlabeled/mapping0/order0/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/canonical/unlabeled/mapping0/order0/review-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/canonical/unlabeled/mapping0/order1/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/canonical/unlabeled/mapping0/order1/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/canonical/unlabeled/mapping0/order1/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/canonical/unlabeled/mapping0/order1/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/canonical/unlabeled/mapping0/order2/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/canonical/unlabeled/mapping0/order2/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/canonical/unlabeled/mapping0/order2/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/canonical/unlabeled/mapping0/order2/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/canonical/unlabeled/mapping0/order3/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/canonical/unlabeled/mapping0/order3/issue-001 | 1/2 [1.3, 98.7] |
| gpt-5.6-luna/canonical/unlabeled/mapping0/order3/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/canonical/unlabeled/mapping0/order3/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/canonical/unlabeled/release-001 | 8/8 [63.1, 100.0] |
| gpt-5.6-luna/canonical/unlabeled/review-001 | 2/8 [3.2, 65.1] |
| gpt-5.6-luna/coded/labeled/ci-001 | 4/32 [3.5, 29.0] |
| gpt-5.6-luna/coded/labeled/issue-001 | 29/32 [75.0, 98.0] |
| gpt-5.6-luna/coded/labeled/mapping0/order0/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/coded/labeled/mapping0/order0/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/coded/labeled/mapping0/order0/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/coded/labeled/mapping0/order0/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/coded/labeled/mapping0/order1/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/coded/labeled/mapping0/order1/issue-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/coded/labeled/mapping0/order1/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/coded/labeled/mapping0/order1/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/coded/labeled/mapping0/order2/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/coded/labeled/mapping0/order2/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/coded/labeled/mapping0/order2/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/coded/labeled/mapping0/order2/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/coded/labeled/mapping0/order3/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/coded/labeled/mapping0/order3/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/coded/labeled/mapping0/order3/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/coded/labeled/mapping0/order3/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/coded/labeled/mapping1/order0/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/coded/labeled/mapping1/order0/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/coded/labeled/mapping1/order0/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/coded/labeled/mapping1/order0/review-001 | 1/2 [1.3, 98.7] |
| gpt-5.6-luna/coded/labeled/mapping1/order1/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/coded/labeled/mapping1/order1/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/coded/labeled/mapping1/order1/release-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/coded/labeled/mapping1/order1/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/coded/labeled/mapping1/order2/ci-001 | 1/2 [1.3, 98.7] |
| gpt-5.6-luna/coded/labeled/mapping1/order2/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/coded/labeled/mapping1/order2/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/coded/labeled/mapping1/order2/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/coded/labeled/mapping1/order3/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/coded/labeled/mapping1/order3/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/coded/labeled/mapping1/order3/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/coded/labeled/mapping1/order3/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/coded/labeled/mapping2/order0/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/coded/labeled/mapping2/order0/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/coded/labeled/mapping2/order0/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/coded/labeled/mapping2/order0/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/coded/labeled/mapping2/order1/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/coded/labeled/mapping2/order1/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/coded/labeled/mapping2/order1/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/coded/labeled/mapping2/order1/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/coded/labeled/mapping2/order2/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/coded/labeled/mapping2/order2/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/coded/labeled/mapping2/order2/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/coded/labeled/mapping2/order2/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/coded/labeled/mapping2/order3/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/coded/labeled/mapping2/order3/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/coded/labeled/mapping2/order3/release-001 | 1/2 [1.3, 98.7] |
| gpt-5.6-luna/coded/labeled/mapping2/order3/review-001 | 1/2 [1.3, 98.7] |
| gpt-5.6-luna/coded/labeled/mapping3/order0/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/coded/labeled/mapping3/order0/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/coded/labeled/mapping3/order0/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/coded/labeled/mapping3/order0/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/coded/labeled/mapping3/order1/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/coded/labeled/mapping3/order1/issue-001 | 1/2 [1.3, 98.7] |
| gpt-5.6-luna/coded/labeled/mapping3/order1/release-001 | 1/2 [1.3, 98.7] |
| gpt-5.6-luna/coded/labeled/mapping3/order1/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/coded/labeled/mapping3/order2/ci-001 | 1/2 [1.3, 98.7] |
| gpt-5.6-luna/coded/labeled/mapping3/order2/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/coded/labeled/mapping3/order2/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/coded/labeled/mapping3/order2/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/coded/labeled/mapping3/order3/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/coded/labeled/mapping3/order3/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/coded/labeled/mapping3/order3/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/coded/labeled/mapping3/order3/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/coded/labeled/release-001 | 28/32 [71.0, 96.5] |
| gpt-5.6-luna/coded/labeled/review-001 | 2/32 [0.8, 20.8] |
| gpt-5.6-luna/coded/unlabeled/ci-001 | 6/32 [7.2, 36.4] |
| gpt-5.6-luna/coded/unlabeled/issue-001 | 27/32 [67.2, 94.7] |
| gpt-5.6-luna/coded/unlabeled/mapping0/order0/ci-001 | 1/2 [1.3, 98.7] |
| gpt-5.6-luna/coded/unlabeled/mapping0/order0/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/coded/unlabeled/mapping0/order0/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/coded/unlabeled/mapping0/order0/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/coded/unlabeled/mapping0/order1/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/coded/unlabeled/mapping0/order1/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/coded/unlabeled/mapping0/order1/release-001 | 1/2 [1.3, 98.7] |
| gpt-5.6-luna/coded/unlabeled/mapping0/order1/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/coded/unlabeled/mapping0/order2/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/coded/unlabeled/mapping0/order2/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/coded/unlabeled/mapping0/order2/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/coded/unlabeled/mapping0/order2/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/coded/unlabeled/mapping0/order3/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/coded/unlabeled/mapping0/order3/issue-001 | 1/2 [1.3, 98.7] |
| gpt-5.6-luna/coded/unlabeled/mapping0/order3/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/coded/unlabeled/mapping0/order3/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/coded/unlabeled/mapping1/order0/ci-001 | 1/2 [1.3, 98.7] |
| gpt-5.6-luna/coded/unlabeled/mapping1/order0/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/coded/unlabeled/mapping1/order0/release-001 | 1/2 +1 missing [1.3, 100.0] |
| gpt-5.6-luna/coded/unlabeled/mapping1/order0/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/coded/unlabeled/mapping1/order1/ci-001 | 1/2 [1.3, 98.7] |
| gpt-5.6-luna/coded/unlabeled/mapping1/order1/issue-001 | 1/2 [1.3, 98.7] |
| gpt-5.6-luna/coded/unlabeled/mapping1/order1/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/coded/unlabeled/mapping1/order1/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/coded/unlabeled/mapping1/order2/ci-001 | 1/2 [1.3, 98.7] |
| gpt-5.6-luna/coded/unlabeled/mapping1/order2/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/coded/unlabeled/mapping1/order2/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/coded/unlabeled/mapping1/order2/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/coded/unlabeled/mapping1/order3/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/coded/unlabeled/mapping1/order3/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/coded/unlabeled/mapping1/order3/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/coded/unlabeled/mapping1/order3/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/coded/unlabeled/mapping2/order0/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/coded/unlabeled/mapping2/order0/issue-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/coded/unlabeled/mapping2/order0/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/coded/unlabeled/mapping2/order0/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/coded/unlabeled/mapping2/order1/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/coded/unlabeled/mapping2/order1/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/coded/unlabeled/mapping2/order1/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/coded/unlabeled/mapping2/order1/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/coded/unlabeled/mapping2/order2/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/coded/unlabeled/mapping2/order2/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/coded/unlabeled/mapping2/order2/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/coded/unlabeled/mapping2/order2/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/coded/unlabeled/mapping2/order3/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/coded/unlabeled/mapping2/order3/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/coded/unlabeled/mapping2/order3/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/coded/unlabeled/mapping2/order3/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/coded/unlabeled/mapping3/order0/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/coded/unlabeled/mapping3/order0/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/coded/unlabeled/mapping3/order0/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/coded/unlabeled/mapping3/order0/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/coded/unlabeled/mapping3/order1/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/coded/unlabeled/mapping3/order1/issue-001 | 1/2 [1.3, 98.7] |
| gpt-5.6-luna/coded/unlabeled/mapping3/order1/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/coded/unlabeled/mapping3/order1/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/coded/unlabeled/mapping3/order2/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/coded/unlabeled/mapping3/order2/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/coded/unlabeled/mapping3/order2/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/coded/unlabeled/mapping3/order2/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/coded/unlabeled/mapping3/order3/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/coded/unlabeled/mapping3/order3/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/coded/unlabeled/mapping3/order3/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-luna/coded/unlabeled/mapping3/order3/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-luna/coded/unlabeled/release-001 | 30/32 +1 missing [79.2, 99.9] |
| gpt-5.6-luna/coded/unlabeled/review-001 | 0/32 [0.0, 10.9] |
| gpt-5.6-sol/canonical/labeled/ci-001 | 0/8 [0.0, 36.9] |
| gpt-5.6-sol/canonical/labeled/issue-001 | 0/8 [0.0, 36.9] |
| gpt-5.6-sol/canonical/labeled/mapping0/order0/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/canonical/labeled/mapping0/order0/issue-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/canonical/labeled/mapping0/order0/release-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/canonical/labeled/mapping0/order0/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/canonical/labeled/mapping0/order1/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/canonical/labeled/mapping0/order1/issue-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/canonical/labeled/mapping0/order1/release-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/canonical/labeled/mapping0/order1/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/canonical/labeled/mapping0/order2/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/canonical/labeled/mapping0/order2/issue-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/canonical/labeled/mapping0/order2/release-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/canonical/labeled/mapping0/order2/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/canonical/labeled/mapping0/order3/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/canonical/labeled/mapping0/order3/issue-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/canonical/labeled/mapping0/order3/release-001 | 0/2 +1 missing [0.0, 98.7] |
| gpt-5.6-sol/canonical/labeled/mapping0/order3/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/canonical/labeled/release-001 | 0/8 +1 missing [0.0, 52.7] |
| gpt-5.6-sol/canonical/labeled/review-001 | 0/8 [0.0, 36.9] |
| gpt-5.6-sol/canonical/unlabeled/ci-001 | 0/8 [0.0, 36.9] |
| gpt-5.6-sol/canonical/unlabeled/issue-001 | 1/8 [0.3, 52.7] |
| gpt-5.6-sol/canonical/unlabeled/mapping0/order0/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/canonical/unlabeled/mapping0/order0/issue-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/canonical/unlabeled/mapping0/order0/release-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/canonical/unlabeled/mapping0/order0/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/canonical/unlabeled/mapping0/order1/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/canonical/unlabeled/mapping0/order1/issue-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/canonical/unlabeled/mapping0/order1/release-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/canonical/unlabeled/mapping0/order1/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/canonical/unlabeled/mapping0/order2/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/canonical/unlabeled/mapping0/order2/issue-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/canonical/unlabeled/mapping0/order2/release-001 | 1/2 [1.3, 98.7] |
| gpt-5.6-sol/canonical/unlabeled/mapping0/order2/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/canonical/unlabeled/mapping0/order3/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/canonical/unlabeled/mapping0/order3/issue-001 | 1/2 [1.3, 98.7] |
| gpt-5.6-sol/canonical/unlabeled/mapping0/order3/release-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/canonical/unlabeled/mapping0/order3/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/canonical/unlabeled/release-001 | 1/8 [0.3, 52.7] |
| gpt-5.6-sol/canonical/unlabeled/review-001 | 0/8 [0.0, 36.9] |
| gpt-5.6-sol/coded/labeled/ci-001 | 0/32 [0.0, 10.9] |
| gpt-5.6-sol/coded/labeled/issue-001 | 0/32 +1 missing [0.0, 16.2] |
| gpt-5.6-sol/coded/labeled/mapping0/order0/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping0/order0/issue-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping0/order0/release-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping0/order0/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping0/order1/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping0/order1/issue-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping0/order1/release-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping0/order1/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping0/order2/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping0/order2/issue-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping0/order2/release-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping0/order2/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping0/order3/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping0/order3/issue-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping0/order3/release-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping0/order3/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping1/order0/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping1/order0/issue-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping1/order0/release-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping1/order0/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping1/order1/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping1/order1/issue-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping1/order1/release-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping1/order1/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping1/order2/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping1/order2/issue-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping1/order2/release-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping1/order2/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping1/order3/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping1/order3/issue-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping1/order3/release-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping1/order3/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping2/order0/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping2/order0/issue-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping2/order0/release-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping2/order0/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping2/order1/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping2/order1/issue-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping2/order1/release-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping2/order1/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping2/order2/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping2/order2/issue-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping2/order2/release-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping2/order2/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping2/order3/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping2/order3/issue-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping2/order3/release-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping2/order3/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping3/order0/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping3/order0/issue-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping3/order0/release-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping3/order0/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping3/order1/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping3/order1/issue-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping3/order1/release-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping3/order1/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping3/order2/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping3/order2/issue-001 | 0/2 +1 missing [0.0, 98.7] |
| gpt-5.6-sol/coded/labeled/mapping3/order2/release-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping3/order2/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping3/order3/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping3/order3/issue-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping3/order3/release-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/mapping3/order3/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/labeled/release-001 | 0/32 [0.0, 10.9] |
| gpt-5.6-sol/coded/labeled/review-001 | 0/32 [0.0, 10.9] |
| gpt-5.6-sol/coded/unlabeled/ci-001 | 0/32 [0.0, 10.9] |
| gpt-5.6-sol/coded/unlabeled/issue-001 | 16/32 [31.9, 68.1] |
| gpt-5.6-sol/coded/unlabeled/mapping0/order0/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/unlabeled/mapping0/order0/issue-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/unlabeled/mapping0/order0/release-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/unlabeled/mapping0/order0/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/unlabeled/mapping0/order1/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/unlabeled/mapping0/order1/issue-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/unlabeled/mapping0/order1/release-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/unlabeled/mapping0/order1/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/unlabeled/mapping0/order2/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/unlabeled/mapping0/order2/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-sol/coded/unlabeled/mapping0/order2/release-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/unlabeled/mapping0/order2/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/unlabeled/mapping0/order3/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/unlabeled/mapping0/order3/issue-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/unlabeled/mapping0/order3/release-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/unlabeled/mapping0/order3/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/unlabeled/mapping1/order0/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/unlabeled/mapping1/order0/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-sol/coded/unlabeled/mapping1/order0/release-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/unlabeled/mapping1/order0/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/unlabeled/mapping1/order1/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/unlabeled/mapping1/order1/issue-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/unlabeled/mapping1/order1/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-sol/coded/unlabeled/mapping1/order1/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/unlabeled/mapping1/order2/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/unlabeled/mapping1/order2/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-sol/coded/unlabeled/mapping1/order2/release-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/unlabeled/mapping1/order2/review-001 | 1/2 [1.3, 98.7] |
| gpt-5.6-sol/coded/unlabeled/mapping1/order3/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/unlabeled/mapping1/order3/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-sol/coded/unlabeled/mapping1/order3/release-001 | 1/2 [1.3, 98.7] |
| gpt-5.6-sol/coded/unlabeled/mapping1/order3/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/unlabeled/mapping2/order0/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/unlabeled/mapping2/order0/issue-001 | 1/2 [1.3, 98.7] |
| gpt-5.6-sol/coded/unlabeled/mapping2/order0/release-001 | 1/2 [1.3, 98.7] |
| gpt-5.6-sol/coded/unlabeled/mapping2/order0/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/unlabeled/mapping2/order1/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/unlabeled/mapping2/order1/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-sol/coded/unlabeled/mapping2/order1/release-001 | 1/2 [1.3, 98.7] |
| gpt-5.6-sol/coded/unlabeled/mapping2/order1/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/unlabeled/mapping2/order2/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/unlabeled/mapping2/order2/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-sol/coded/unlabeled/mapping2/order2/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-sol/coded/unlabeled/mapping2/order2/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/unlabeled/mapping2/order3/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/unlabeled/mapping2/order3/issue-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/unlabeled/mapping2/order3/release-001 | 1/2 [1.3, 98.7] |
| gpt-5.6-sol/coded/unlabeled/mapping2/order3/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/unlabeled/mapping3/order0/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/unlabeled/mapping3/order0/issue-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/unlabeled/mapping3/order0/release-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/unlabeled/mapping3/order0/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/unlabeled/mapping3/order1/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/unlabeled/mapping3/order1/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-sol/coded/unlabeled/mapping3/order1/release-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/unlabeled/mapping3/order1/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/unlabeled/mapping3/order2/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/unlabeled/mapping3/order2/issue-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/unlabeled/mapping3/order2/release-001 | 1/2 [1.3, 98.7] |
| gpt-5.6-sol/coded/unlabeled/mapping3/order2/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/unlabeled/mapping3/order3/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/unlabeled/mapping3/order3/issue-001 | 1/2 [1.3, 98.7] |
| gpt-5.6-sol/coded/unlabeled/mapping3/order3/release-001 | 1/2 [1.3, 98.7] |
| gpt-5.6-sol/coded/unlabeled/mapping3/order3/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-sol/coded/unlabeled/release-001 | 10/32 [16.1, 50.0] |
| gpt-5.6-sol/coded/unlabeled/review-001 | 1/32 [0.1, 16.2] |
| gpt-5.6-terra/canonical/labeled/ci-001 | 7/8 [47.3, 99.7] |
| gpt-5.6-terra/canonical/labeled/issue-001 | 8/8 [63.1, 100.0] |
| gpt-5.6-terra/canonical/labeled/mapping0/order0/ci-001 | 1/2 [1.3, 98.7] |
| gpt-5.6-terra/canonical/labeled/mapping0/order0/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/canonical/labeled/mapping0/order0/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/canonical/labeled/mapping0/order0/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-terra/canonical/labeled/mapping0/order1/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/canonical/labeled/mapping0/order1/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/canonical/labeled/mapping0/order1/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/canonical/labeled/mapping0/order1/review-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/canonical/labeled/mapping0/order2/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/canonical/labeled/mapping0/order2/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/canonical/labeled/mapping0/order2/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/canonical/labeled/mapping0/order2/review-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/canonical/labeled/mapping0/order3/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/canonical/labeled/mapping0/order3/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/canonical/labeled/mapping0/order3/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/canonical/labeled/mapping0/order3/review-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/canonical/labeled/release-001 | 8/8 [63.1, 100.0] |
| gpt-5.6-terra/canonical/labeled/review-001 | 6/8 [34.9, 96.8] |
| gpt-5.6-terra/canonical/unlabeled/ci-001 | 8/8 [63.1, 100.0] |
| gpt-5.6-terra/canonical/unlabeled/issue-001 | 8/8 [63.1, 100.0] |
| gpt-5.6-terra/canonical/unlabeled/mapping0/order0/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/canonical/unlabeled/mapping0/order0/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/canonical/unlabeled/mapping0/order0/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/canonical/unlabeled/mapping0/order0/review-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/canonical/unlabeled/mapping0/order1/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/canonical/unlabeled/mapping0/order1/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/canonical/unlabeled/mapping0/order1/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/canonical/unlabeled/mapping0/order1/review-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/canonical/unlabeled/mapping0/order2/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/canonical/unlabeled/mapping0/order2/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/canonical/unlabeled/mapping0/order2/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/canonical/unlabeled/mapping0/order2/review-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/canonical/unlabeled/mapping0/order3/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/canonical/unlabeled/mapping0/order3/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/canonical/unlabeled/mapping0/order3/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/canonical/unlabeled/mapping0/order3/review-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/canonical/unlabeled/release-001 | 8/8 [63.1, 100.0] |
| gpt-5.6-terra/canonical/unlabeled/review-001 | 8/8 [63.1, 100.0] |
| gpt-5.6-terra/coded/labeled/ci-001 | 17/32 +2 missing [34.7, 76.3] |
| gpt-5.6-terra/coded/labeled/issue-001 | 28/32 [71.0, 96.5] |
| gpt-5.6-terra/coded/labeled/mapping0/order0/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/labeled/mapping0/order0/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/labeled/mapping0/order0/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/labeled/mapping0/order0/review-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/labeled/mapping0/order1/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/labeled/mapping0/order1/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/labeled/mapping0/order1/release-001 | 1/2 [1.3, 98.7] |
| gpt-5.6-terra/coded/labeled/mapping0/order1/review-001 | 1/2 [1.3, 98.7] |
| gpt-5.6-terra/coded/labeled/mapping0/order2/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/labeled/mapping0/order2/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/labeled/mapping0/order2/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/labeled/mapping0/order2/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-terra/coded/labeled/mapping0/order3/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/labeled/mapping0/order3/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/labeled/mapping0/order3/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/labeled/mapping0/order3/review-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/labeled/mapping1/order0/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-terra/coded/labeled/mapping1/order0/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/labeled/mapping1/order0/release-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-terra/coded/labeled/mapping1/order0/review-001 | 1/2 [1.3, 98.7] |
| gpt-5.6-terra/coded/labeled/mapping1/order1/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/labeled/mapping1/order1/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/labeled/mapping1/order1/release-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-terra/coded/labeled/mapping1/order1/review-001 | 1/2 [1.3, 98.7] |
| gpt-5.6-terra/coded/labeled/mapping1/order2/ci-001 | 1/2 [1.3, 98.7] |
| gpt-5.6-terra/coded/labeled/mapping1/order2/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/labeled/mapping1/order2/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/labeled/mapping1/order2/review-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/labeled/mapping1/order3/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/labeled/mapping1/order3/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/labeled/mapping1/order3/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/labeled/mapping1/order3/review-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/labeled/mapping2/order0/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-terra/coded/labeled/mapping2/order0/issue-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-terra/coded/labeled/mapping2/order0/release-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-terra/coded/labeled/mapping2/order0/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-terra/coded/labeled/mapping2/order1/ci-001 | 1/2 [1.3, 98.7] |
| gpt-5.6-terra/coded/labeled/mapping2/order1/issue-001 | 1/2 [1.3, 98.7] |
| gpt-5.6-terra/coded/labeled/mapping2/order1/release-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-terra/coded/labeled/mapping2/order1/review-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/labeled/mapping2/order2/ci-001 | 1/2 +1 missing [1.3, 100.0] |
| gpt-5.6-terra/coded/labeled/mapping2/order2/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/labeled/mapping2/order2/release-001 | 1/2 [1.3, 98.7] |
| gpt-5.6-terra/coded/labeled/mapping2/order2/review-001 | 1/2 [1.3, 98.7] |
| gpt-5.6-terra/coded/labeled/mapping2/order3/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-terra/coded/labeled/mapping2/order3/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/labeled/mapping2/order3/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/labeled/mapping2/order3/review-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/labeled/mapping3/order0/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-terra/coded/labeled/mapping3/order0/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/labeled/mapping3/order0/release-001 | 1/2 [1.3, 98.7] |
| gpt-5.6-terra/coded/labeled/mapping3/order0/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-terra/coded/labeled/mapping3/order1/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/labeled/mapping3/order1/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/labeled/mapping3/order1/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/labeled/mapping3/order1/review-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/labeled/mapping3/order2/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-terra/coded/labeled/mapping3/order2/issue-001 | 1/2 [1.3, 98.7] |
| gpt-5.6-terra/coded/labeled/mapping3/order2/release-001 | 1/2 [1.3, 98.7] |
| gpt-5.6-terra/coded/labeled/mapping3/order2/review-001 | 1/2 [1.3, 98.7] |
| gpt-5.6-terra/coded/labeled/mapping3/order3/ci-001 | 0/2 +1 missing [0.0, 98.7] |
| gpt-5.6-terra/coded/labeled/mapping3/order3/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/labeled/mapping3/order3/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/labeled/mapping3/order3/review-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-terra/coded/labeled/release-001 | 20/32 [43.7, 78.9] |
| gpt-5.6-terra/coded/labeled/review-001 | 19/32 [40.6, 76.3] |
| gpt-5.6-terra/coded/unlabeled/ci-001 | 20/32 [43.7, 78.9] |
| gpt-5.6-terra/coded/unlabeled/issue-001 | 32/32 [89.1, 100.0] |
| gpt-5.6-terra/coded/unlabeled/mapping0/order0/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/unlabeled/mapping0/order0/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/unlabeled/mapping0/order0/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/unlabeled/mapping0/order0/review-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/unlabeled/mapping0/order1/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/unlabeled/mapping0/order1/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/unlabeled/mapping0/order1/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/unlabeled/mapping0/order1/review-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/unlabeled/mapping0/order2/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/unlabeled/mapping0/order2/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/unlabeled/mapping0/order2/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/unlabeled/mapping0/order2/review-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/unlabeled/mapping0/order3/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/unlabeled/mapping0/order3/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/unlabeled/mapping0/order3/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/unlabeled/mapping0/order3/review-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/unlabeled/mapping1/order0/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-terra/coded/unlabeled/mapping1/order0/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/unlabeled/mapping1/order0/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/unlabeled/mapping1/order0/review-001 | 1/2 [1.3, 98.7] |
| gpt-5.6-terra/coded/unlabeled/mapping1/order1/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/unlabeled/mapping1/order1/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/unlabeled/mapping1/order1/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/unlabeled/mapping1/order1/review-001 | 1/2 [1.3, 98.7] |
| gpt-5.6-terra/coded/unlabeled/mapping1/order2/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/unlabeled/mapping1/order2/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/unlabeled/mapping1/order2/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/unlabeled/mapping1/order2/review-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/unlabeled/mapping1/order3/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-terra/coded/unlabeled/mapping1/order3/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/unlabeled/mapping1/order3/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/unlabeled/mapping1/order3/review-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/unlabeled/mapping2/order0/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-terra/coded/unlabeled/mapping2/order0/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/unlabeled/mapping2/order0/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/unlabeled/mapping2/order0/review-001 | 1/2 [1.3, 98.7] |
| gpt-5.6-terra/coded/unlabeled/mapping2/order1/ci-001 | 0/2 [0.0, 84.2] |
| gpt-5.6-terra/coded/unlabeled/mapping2/order1/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/unlabeled/mapping2/order1/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/unlabeled/mapping2/order1/review-001 | 1/2 [1.3, 98.7] |
| gpt-5.6-terra/coded/unlabeled/mapping2/order2/ci-001 | 1/2 [1.3, 98.7] |
| gpt-5.6-terra/coded/unlabeled/mapping2/order2/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/unlabeled/mapping2/order2/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/unlabeled/mapping2/order2/review-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/unlabeled/mapping2/order3/ci-001 | 1/2 [1.3, 98.7] |
| gpt-5.6-terra/coded/unlabeled/mapping2/order3/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/unlabeled/mapping2/order3/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/unlabeled/mapping2/order3/review-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/unlabeled/mapping3/order0/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/unlabeled/mapping3/order0/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/unlabeled/mapping3/order0/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/unlabeled/mapping3/order0/review-001 | 1/2 [1.3, 98.7] |
| gpt-5.6-terra/coded/unlabeled/mapping3/order1/ci-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/unlabeled/mapping3/order1/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/unlabeled/mapping3/order1/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/unlabeled/mapping3/order1/review-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/unlabeled/mapping3/order2/ci-001 | 1/2 [1.3, 98.7] |
| gpt-5.6-terra/coded/unlabeled/mapping3/order2/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/unlabeled/mapping3/order2/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/unlabeled/mapping3/order2/review-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/unlabeled/mapping3/order3/ci-001 | 1/2 [1.3, 98.7] |
| gpt-5.6-terra/coded/unlabeled/mapping3/order3/issue-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/unlabeled/mapping3/order3/release-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/unlabeled/mapping3/order3/review-001 | 2/2 [15.8, 100.0] |
| gpt-5.6-terra/coded/unlabeled/release-001 | 32/32 [89.1, 100.0] |
| gpt-5.6-terra/coded/unlabeled/review-001 | 27/32 [67.2, 94.7] |
| gpt-6-astra/canonical/labeled/ci-001 | 0/8 [0.0, 36.9] |
| gpt-6-astra/canonical/labeled/issue-001 | 0/8 [0.0, 36.9] |
| gpt-6-astra/canonical/labeled/mapping0/order0/ci-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/canonical/labeled/mapping0/order0/issue-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/canonical/labeled/mapping0/order0/release-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/canonical/labeled/mapping0/order0/review-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/canonical/labeled/mapping0/order1/ci-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/canonical/labeled/mapping0/order1/issue-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/canonical/labeled/mapping0/order1/release-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/canonical/labeled/mapping0/order1/review-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/canonical/labeled/mapping0/order2/ci-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/canonical/labeled/mapping0/order2/issue-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/canonical/labeled/mapping0/order2/release-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/canonical/labeled/mapping0/order2/review-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/canonical/labeled/mapping0/order3/ci-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/canonical/labeled/mapping0/order3/issue-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/canonical/labeled/mapping0/order3/release-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/canonical/labeled/mapping0/order3/review-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/canonical/labeled/release-001 | 0/8 [0.0, 36.9] |
| gpt-6-astra/canonical/labeled/review-001 | 0/8 [0.0, 36.9] |
| gpt-6-astra/canonical/unlabeled/ci-001 | 0/8 [0.0, 36.9] |
| gpt-6-astra/canonical/unlabeled/issue-001 | 0/8 [0.0, 36.9] |
| gpt-6-astra/canonical/unlabeled/mapping0/order0/ci-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/canonical/unlabeled/mapping0/order0/issue-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/canonical/unlabeled/mapping0/order0/release-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/canonical/unlabeled/mapping0/order0/review-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/canonical/unlabeled/mapping0/order1/ci-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/canonical/unlabeled/mapping0/order1/issue-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/canonical/unlabeled/mapping0/order1/release-001 | 0/2 +1 missing [0.0, 98.7] |
| gpt-6-astra/canonical/unlabeled/mapping0/order1/review-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/canonical/unlabeled/mapping0/order2/ci-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/canonical/unlabeled/mapping0/order2/issue-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/canonical/unlabeled/mapping0/order2/release-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/canonical/unlabeled/mapping0/order2/review-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/canonical/unlabeled/mapping0/order3/ci-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/canonical/unlabeled/mapping0/order3/issue-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/canonical/unlabeled/mapping0/order3/release-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/canonical/unlabeled/mapping0/order3/review-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/canonical/unlabeled/release-001 | 0/8 +1 missing [0.0, 52.7] |
| gpt-6-astra/canonical/unlabeled/review-001 | 0/8 [0.0, 36.9] |
| gpt-6-astra/coded/labeled/ci-001 | 0/32 +1 missing [0.0, 16.2] |
| gpt-6-astra/coded/labeled/issue-001 | 0/32 +1 missing [0.0, 16.2] |
| gpt-6-astra/coded/labeled/mapping0/order0/ci-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/mapping0/order0/issue-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/mapping0/order0/release-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/mapping0/order0/review-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/mapping0/order1/ci-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/mapping0/order1/issue-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/mapping0/order1/release-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/mapping0/order1/review-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/mapping0/order2/ci-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/mapping0/order2/issue-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/mapping0/order2/release-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/mapping0/order2/review-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/mapping0/order3/ci-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/mapping0/order3/issue-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/mapping0/order3/release-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/mapping0/order3/review-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/mapping1/order0/ci-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/mapping1/order0/issue-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/mapping1/order0/release-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/mapping1/order0/review-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/mapping1/order1/ci-001 | 0/2 +1 missing [0.0, 98.7] |
| gpt-6-astra/coded/labeled/mapping1/order1/issue-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/mapping1/order1/release-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/mapping1/order1/review-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/mapping1/order2/ci-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/mapping1/order2/issue-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/mapping1/order2/release-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/mapping1/order2/review-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/mapping1/order3/ci-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/mapping1/order3/issue-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/mapping1/order3/release-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/mapping1/order3/review-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/mapping2/order0/ci-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/mapping2/order0/issue-001 | 0/2 +1 missing [0.0, 98.7] |
| gpt-6-astra/coded/labeled/mapping2/order0/release-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/mapping2/order0/review-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/mapping2/order1/ci-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/mapping2/order1/issue-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/mapping2/order1/release-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/mapping2/order1/review-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/mapping2/order2/ci-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/mapping2/order2/issue-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/mapping2/order2/release-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/mapping2/order2/review-001 | 0/2 +1 missing [0.0, 98.7] |
| gpt-6-astra/coded/labeled/mapping2/order3/ci-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/mapping2/order3/issue-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/mapping2/order3/release-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/mapping2/order3/review-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/mapping3/order0/ci-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/mapping3/order0/issue-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/mapping3/order0/release-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/mapping3/order0/review-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/mapping3/order1/ci-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/mapping3/order1/issue-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/mapping3/order1/release-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/mapping3/order1/review-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/mapping3/order2/ci-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/mapping3/order2/issue-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/mapping3/order2/release-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/mapping3/order2/review-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/mapping3/order3/ci-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/mapping3/order3/issue-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/mapping3/order3/release-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/mapping3/order3/review-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/labeled/release-001 | 0/32 [0.0, 10.9] |
| gpt-6-astra/coded/labeled/review-001 | 0/32 +1 missing [0.0, 16.2] |
| gpt-6-astra/coded/unlabeled/ci-001 | 0/32 [0.0, 10.9] |
| gpt-6-astra/coded/unlabeled/issue-001 | 0/32 [0.0, 10.9] |
| gpt-6-astra/coded/unlabeled/mapping0/order0/ci-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping0/order0/issue-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping0/order0/release-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping0/order0/review-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping0/order1/ci-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping0/order1/issue-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping0/order1/release-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping0/order1/review-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping0/order2/ci-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping0/order2/issue-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping0/order2/release-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping0/order2/review-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping0/order3/ci-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping0/order3/issue-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping0/order3/release-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping0/order3/review-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping1/order0/ci-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping1/order0/issue-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping1/order0/release-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping1/order0/review-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping1/order1/ci-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping1/order1/issue-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping1/order1/release-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping1/order1/review-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping1/order2/ci-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping1/order2/issue-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping1/order2/release-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping1/order2/review-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping1/order3/ci-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping1/order3/issue-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping1/order3/release-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping1/order3/review-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping2/order0/ci-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping2/order0/issue-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping2/order0/release-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping2/order0/review-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping2/order1/ci-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping2/order1/issue-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping2/order1/release-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping2/order1/review-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping2/order2/ci-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping2/order2/issue-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping2/order2/release-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping2/order2/review-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping2/order3/ci-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping2/order3/issue-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping2/order3/release-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping2/order3/review-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping3/order0/ci-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping3/order0/issue-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping3/order0/release-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping3/order0/review-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping3/order1/ci-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping3/order1/issue-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping3/order1/release-001 | 0/2 +1 missing [0.0, 98.7] |
| gpt-6-astra/coded/unlabeled/mapping3/order1/review-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping3/order2/ci-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping3/order2/issue-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping3/order2/release-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping3/order2/review-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping3/order3/ci-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping3/order3/issue-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping3/order3/release-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/mapping3/order3/review-001 | 0/2 [0.0, 84.2] |
| gpt-6-astra/coded/unlabeled/release-001 | 0/32 +1 missing [0.0, 16.2] |
| gpt-6-astra/coded/unlabeled/review-001 | 0/32 [0.0, 10.9] |

## All specified and exploratory contrasts

| Contrast | Equal-task effect | CI | Issue | Release | Review |
| --- | --- | --- | --- | --- | --- |
| gpt-5.4-2026-03-05/canonical/label_removal | +0.031 | +0.125 | +0.000 | +0.125 | -0.125 |
| gpt-5.4-2026-03-05/canonical/mapping0/order0/label_removal | +0.125 | +0.000 | +0.000 | +0.500 | +0.000 |
| gpt-5.4-2026-03-05/canonical/mapping0/order1/label_removal | +0.000 | +0.500 | +0.000 | +0.000 | -0.500 |
| gpt-5.4-2026-03-05/canonical/mapping0/order2/label_removal | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 |
| gpt-5.4-2026-03-05/canonical/mapping0/order3/label_removal | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 |
| gpt-5.4-2026-03-05/coded/label_removal | [+0.078, +0.094] | [+0.344, +0.375] | [+0.062, +0.094] | +0.094 | -0.188 |
| gpt-5.4-2026-03-05/coded/mapping0/order0/label_removal | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 |
| gpt-5.4-2026-03-05/coded/mapping0/order1/label_removal | +0.125 | +0.500 | +0.000 | +0.000 | +0.000 |
| gpt-5.4-2026-03-05/coded/mapping0/order2/label_removal | -0.125 | +0.000 | +0.000 | +0.000 | -0.500 |
| gpt-5.4-2026-03-05/coded/mapping0/order3/label_removal | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 |
| gpt-5.4-2026-03-05/coded/mapping1/order0/label_removal | +0.000 | +0.500 | +0.000 | +0.000 | -0.500 |
| gpt-5.4-2026-03-05/coded/mapping1/order1/label_removal | +0.375 | +1.000 | +0.000 | +0.000 | +0.500 |
| gpt-5.4-2026-03-05/coded/mapping1/order2/label_removal | +0.000 | +0.500 | +0.000 | +0.000 | -0.500 |
| gpt-5.4-2026-03-05/coded/mapping1/order3/label_removal | +0.125 | +0.500 | +0.000 | +0.000 | +0.000 |
| gpt-5.4-2026-03-05/coded/mapping2/order0/label_removal | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 |
| gpt-5.4-2026-03-05/coded/mapping2/order1/label_removal | +0.250 | +0.500 | +0.000 | +0.500 | +0.000 |
| gpt-5.4-2026-03-05/coded/mapping2/order2/label_removal | +0.500 | +0.000 | +1.000 | +1.000 | +0.000 |
| gpt-5.4-2026-03-05/coded/mapping2/order3/label_removal | [-0.250, -0.125] | [+0.000, +0.500] | +0.000 | +0.000 | -1.000 |
| gpt-5.4-2026-03-05/coded/mapping3/order0/label_removal | -0.125 | +0.000 | +0.000 | +0.000 | -0.500 |
| gpt-5.4-2026-03-05/coded/mapping3/order1/label_removal | +0.125 | +1.000 | +0.000 | +0.000 | -0.500 |
| gpt-5.4-2026-03-05/coded/mapping3/order2/label_removal | [+0.500, +0.625] | +1.000 | [+0.000, +0.500] | +0.000 | +1.000 |
| gpt-5.4-2026-03-05/coded/mapping3/order3/label_removal | -0.250 | +0.000 | +0.000 | +0.000 | -1.000 |
| gpt-5.4-2026-03-05/historical_anchor/label_removal | +0.125 | +0.000 | +0.000 | +0.500 | +0.000 |
| gpt-5.4-2026-03-05/labeled/coded_minus_canonical | [-0.195, -0.180] | [-0.312, -0.281] | [-0.156, -0.125] | -0.094 | -0.219 |
| gpt-5.4-2026-03-05/labeled/order1_minus_order0 | +0.500 | +0.500 | +0.000 | +0.500 | +1.000 |
| gpt-5.4-2026-03-05/labeled/order2_minus_order0 | +0.375 | +0.500 | +0.000 | +0.500 | +0.500 |
| gpt-5.4-2026-03-05/labeled/order3_minus_order0 | +0.625 | +1.000 | +0.000 | +0.500 | +1.000 |
| gpt-5.4-2026-03-05/unlabeled/coded_minus_canonical | -0.133 | -0.062 | -0.062 | -0.125 | -0.281 |
| gpt-5.4-2026-03-05/unlabeled/order1_minus_order0 | +0.375 | +1.000 | +0.000 | +0.000 | +0.500 |
| gpt-5.4-2026-03-05/unlabeled/order2_minus_order0 | +0.250 | +0.500 | +0.000 | +0.000 | +0.500 |
| gpt-5.4-2026-03-05/unlabeled/order3_minus_order0 | +0.500 | +1.000 | +0.000 | +0.000 | +1.000 |
| gpt-5.4-mini-2026-03-17/canonical/label_removal | -0.062 | +0.125 | +0.000 | +0.000 | -0.375 |
| gpt-5.4-mini-2026-03-17/canonical/mapping0/order0/label_removal | -0.125 | +0.000 | +0.000 | +0.000 | -0.500 |
| gpt-5.4-mini-2026-03-17/canonical/mapping0/order1/label_removal | +0.125 | +0.500 | +0.000 | +0.000 | +0.000 |
| gpt-5.4-mini-2026-03-17/canonical/mapping0/order2/label_removal | -0.125 | +0.000 | +0.000 | +0.000 | -0.500 |
| gpt-5.4-mini-2026-03-17/canonical/mapping0/order3/label_removal | -0.125 | +0.000 | +0.000 | +0.000 | -0.500 |
| gpt-5.4-mini-2026-03-17/coded/label_removal | [+0.023, +0.039] | [+0.062, +0.094] | +0.062 | [+0.094, +0.125] | -0.125 |
| gpt-5.4-mini-2026-03-17/coded/mapping0/order0/label_removal | +0.250 | +0.000 | +0.000 | +0.500 | +0.500 |
| gpt-5.4-mini-2026-03-17/coded/mapping0/order1/label_removal | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 |
| gpt-5.4-mini-2026-03-17/coded/mapping0/order2/label_removal | +0.125 | +0.000 | +0.000 | +0.000 | +0.500 |
| gpt-5.4-mini-2026-03-17/coded/mapping0/order3/label_removal | -0.375 | -1.000 | +0.000 | +0.000 | -0.500 |
| gpt-5.4-mini-2026-03-17/coded/mapping1/order0/label_removal | -0.125 | +0.000 | +0.000 | +0.000 | -0.500 |
| gpt-5.4-mini-2026-03-17/coded/mapping1/order1/label_removal | +0.125 | +1.000 | +0.000 | +0.000 | -0.500 |
| gpt-5.4-mini-2026-03-17/coded/mapping1/order2/label_removal | [+0.500, +0.625] | +0.000 | +0.500 | [+0.500, +1.000] | +1.000 |
| gpt-5.4-mini-2026-03-17/coded/mapping1/order3/label_removal | +0.000 | +0.500 | +0.000 | +0.000 | -0.500 |
| gpt-5.4-mini-2026-03-17/coded/mapping2/order0/label_removal | [+0.000, +0.125] | [-0.500, +0.000] | +0.500 | +0.000 | +0.000 |
| gpt-5.4-mini-2026-03-17/coded/mapping2/order1/label_removal | +0.375 | +0.500 | +0.500 | +0.500 | +0.000 |
| gpt-5.4-mini-2026-03-17/coded/mapping2/order2/label_removal | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 |
| gpt-5.4-mini-2026-03-17/coded/mapping2/order3/label_removal | -0.375 | +0.000 | -0.500 | +0.000 | -1.000 |
| gpt-5.4-mini-2026-03-17/coded/mapping3/order0/label_removal | -0.125 | +0.000 | +0.000 | +0.000 | -0.500 |
| gpt-5.4-mini-2026-03-17/coded/mapping3/order1/label_removal | +0.250 | +0.000 | +0.000 | +0.000 | +1.000 |
| gpt-5.4-mini-2026-03-17/coded/mapping3/order2/label_removal | -0.125 | +0.500 | +0.000 | +0.000 | -1.000 |
| gpt-5.4-mini-2026-03-17/coded/mapping3/order3/label_removal | -0.125 | +0.000 | +0.000 | +0.000 | -0.500 |
| gpt-5.4-mini-2026-03-17/historical_anchor/label_removal | -0.125 | +0.000 | +0.000 | +0.000 | -0.500 |
| gpt-5.4-mini-2026-03-17/labeled/coded_minus_canonical | [-0.102, -0.094] | -0.031 | -0.094 | [-0.125, -0.094] | -0.156 |
| gpt-5.4-mini-2026-03-17/labeled/order1_minus_order0 | -0.125 | -0.500 | +0.000 | +0.000 | +0.000 |
| gpt-5.4-mini-2026-03-17/labeled/order2_minus_order0 | +0.125 | +0.000 | +0.000 | +0.000 | +0.500 |
| gpt-5.4-mini-2026-03-17/labeled/order3_minus_order0 | +0.125 | +0.000 | +0.000 | +0.000 | +0.500 |
| gpt-5.4-mini-2026-03-17/unlabeled/coded_minus_canonical | [-0.008, +0.000] | [-0.094, -0.062] | -0.031 | +0.000 | +0.094 |
| gpt-5.4-mini-2026-03-17/unlabeled/order1_minus_order0 | +0.125 | +0.000 | +0.000 | +0.000 | +0.500 |
| gpt-5.4-mini-2026-03-17/unlabeled/order2_minus_order0 | +0.125 | +0.000 | +0.000 | +0.000 | +0.500 |
| gpt-5.4-mini-2026-03-17/unlabeled/order3_minus_order0 | +0.125 | +0.000 | +0.000 | +0.000 | +0.500 |
| gpt-5.6-luna/canonical/label_removal | [-0.156, -0.125] | -0.375 | [-0.250, -0.125] | +0.000 | +0.000 |
| gpt-5.6-luna/canonical/mapping0/order0/label_removal | [+0.125, +0.250] | +0.000 | [-0.500, +0.000] | +0.000 | +1.000 |
| gpt-5.6-luna/canonical/mapping0/order1/label_removal | -0.125 | +0.000 | +0.000 | +0.000 | -0.500 |
| gpt-5.6-luna/canonical/mapping0/order2/label_removal | -0.375 | -1.000 | +0.000 | +0.000 | -0.500 |
| gpt-5.6-luna/canonical/mapping0/order3/label_removal | -0.250 | -0.500 | -0.500 | +0.000 | +0.000 |
| gpt-5.6-luna/coded/label_removal | [+0.000, +0.008] | +0.062 | -0.062 | [+0.062, +0.094] | -0.062 |
| gpt-5.6-luna/coded/mapping0/order0/label_removal | +0.125 | +0.500 | +0.000 | +0.000 | +0.000 |
| gpt-5.6-luna/coded/mapping0/order1/label_removal | +0.125 | +0.000 | +1.000 | -0.500 | +0.000 |
| gpt-5.6-luna/coded/mapping0/order2/label_removal | -0.250 | -1.000 | +0.000 | +0.000 | +0.000 |
| gpt-5.6-luna/coded/mapping0/order3/label_removal | -0.125 | +0.000 | -0.500 | +0.000 | +0.000 |
| gpt-5.6-luna/coded/mapping1/order0/label_removal | [-0.125, +0.000] | +0.500 | +0.000 | [-0.500, +0.000] | -0.500 |
| gpt-5.6-luna/coded/mapping1/order1/label_removal | +0.250 | +0.500 | -0.500 | +1.000 | +0.000 |
| gpt-5.6-luna/coded/mapping1/order2/label_removal | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 |
| gpt-5.6-luna/coded/mapping1/order3/label_removal | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 |
| gpt-5.6-luna/coded/mapping2/order0/label_removal | +0.000 | +1.000 | -1.000 | +0.000 | +0.000 |
| gpt-5.6-luna/coded/mapping2/order1/label_removal | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 |
| gpt-5.6-luna/coded/mapping2/order2/label_removal | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 |
| gpt-5.6-luna/coded/mapping2/order3/label_removal | +0.000 | +0.000 | +0.000 | +0.500 | -0.500 |
| gpt-5.6-luna/coded/mapping3/order0/label_removal | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 |
| gpt-5.6-luna/coded/mapping3/order1/label_removal | +0.125 | +0.000 | +0.000 | +0.500 | +0.000 |
| gpt-5.6-luna/coded/mapping3/order2/label_removal | -0.125 | -0.500 | +0.000 | +0.000 | +0.000 |
| gpt-5.6-luna/coded/mapping3/order3/label_removal | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 |
| gpt-5.6-luna/historical_anchor/label_removal | [+0.125, +0.250] | +0.000 | [-0.500, +0.000] | +0.000 | +1.000 |
| gpt-5.6-luna/labeled/coded_minus_canonical | -0.289 | -0.750 | -0.094 | -0.125 | -0.188 |
| gpt-5.6-luna/labeled/order1_minus_order0 | +0.125 | +0.000 | +0.000 | +0.000 | +0.500 |
| gpt-5.6-luna/labeled/order2_minus_order0 | +0.125 | +0.000 | +0.000 | +0.000 | +0.500 |
| gpt-5.6-luna/labeled/order3_minus_order0 | -0.125 | -0.500 | +0.000 | +0.000 | +0.000 |
| gpt-5.6-luna/unlabeled/coded_minus_canonical | [-0.164, -0.125] | -0.312 | [-0.031, +0.094] | [-0.062, -0.031] | -0.250 |
| gpt-5.6-luna/unlabeled/order1_minus_order0 | [-0.250, -0.125] | +0.000 | [+0.000, +0.500] | +0.000 | -1.000 |
| gpt-5.6-luna/unlabeled/order2_minus_order0 | [-0.500, -0.375] | -1.000 | [+0.000, +0.500] | +0.000 | -1.000 |
| gpt-5.6-luna/unlabeled/order3_minus_order0 | [-0.625, -0.500] | -1.000 | [-0.500, +0.000] | +0.000 | -1.000 |
| gpt-5.6-sol/canonical/label_removal | [+0.031, +0.062] | +0.000 | +0.125 | [+0.000, +0.125] | +0.000 |
| gpt-5.6-sol/canonical/mapping0/order0/label_removal | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 |
| gpt-5.6-sol/canonical/mapping0/order1/label_removal | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 |
| gpt-5.6-sol/canonical/mapping0/order2/label_removal | +0.125 | +0.000 | +0.000 | +0.500 | +0.000 |
| gpt-5.6-sol/canonical/mapping0/order3/label_removal | [+0.000, +0.125] | +0.000 | +0.500 | [-0.500, +0.000] | +0.000 |
| gpt-5.6-sol/coded/label_removal | [+0.203, +0.211] | +0.000 | [+0.469, +0.500] | +0.312 | +0.031 |
| gpt-5.6-sol/coded/mapping0/order0/label_removal | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 |
| gpt-5.6-sol/coded/mapping0/order1/label_removal | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 |
| gpt-5.6-sol/coded/mapping0/order2/label_removal | +0.250 | +0.000 | +1.000 | +0.000 | +0.000 |
| gpt-5.6-sol/coded/mapping0/order3/label_removal | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 |
| gpt-5.6-sol/coded/mapping1/order0/label_removal | +0.250 | +0.000 | +1.000 | +0.000 | +0.000 |
| gpt-5.6-sol/coded/mapping1/order1/label_removal | +0.250 | +0.000 | +0.000 | +1.000 | +0.000 |
| gpt-5.6-sol/coded/mapping1/order2/label_removal | +0.375 | +0.000 | +1.000 | +0.000 | +0.500 |
| gpt-5.6-sol/coded/mapping1/order3/label_removal | +0.375 | +0.000 | +1.000 | +0.500 | +0.000 |
| gpt-5.6-sol/coded/mapping2/order0/label_removal | +0.250 | +0.000 | +0.500 | +0.500 | +0.000 |
| gpt-5.6-sol/coded/mapping2/order1/label_removal | +0.375 | +0.000 | +1.000 | +0.500 | +0.000 |
| gpt-5.6-sol/coded/mapping2/order2/label_removal | +0.500 | +0.000 | +1.000 | +1.000 | +0.000 |
| gpt-5.6-sol/coded/mapping2/order3/label_removal | +0.125 | +0.000 | +0.000 | +0.500 | +0.000 |
| gpt-5.6-sol/coded/mapping3/order0/label_removal | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 |
| gpt-5.6-sol/coded/mapping3/order1/label_removal | +0.250 | +0.000 | +1.000 | +0.000 | +0.000 |
| gpt-5.6-sol/coded/mapping3/order2/label_removal | [+0.000, +0.125] | +0.000 | [-0.500, +0.000] | +0.500 | +0.000 |
| gpt-5.6-sol/coded/mapping3/order3/label_removal | +0.250 | +0.000 | +0.500 | +0.500 | +0.000 |
| gpt-5.6-sol/historical_anchor/label_removal | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 |
| gpt-5.6-sol/labeled/coded_minus_canonical | [-0.031, +0.008] | +0.000 | [+0.000, +0.031] | [-0.125, +0.000] | +0.000 |
| gpt-5.6-sol/labeled/order1_minus_order0 | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 |
| gpt-5.6-sol/labeled/order2_minus_order0 | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 |
| gpt-5.6-sol/labeled/order3_minus_order0 | [+0.000, +0.125] | +0.000 | +0.000 | [+0.000, +0.500] | +0.000 |
| gpt-5.6-sol/unlabeled/coded_minus_canonical | +0.148 | +0.000 | +0.375 | +0.188 | +0.031 |
| gpt-5.6-sol/unlabeled/order1_minus_order0 | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 |
| gpt-5.6-sol/unlabeled/order2_minus_order0 | +0.125 | +0.000 | +0.000 | +0.500 | +0.000 |
| gpt-5.6-sol/unlabeled/order3_minus_order0 | +0.125 | +0.000 | +0.500 | +0.000 | +0.000 |
| gpt-5.6-terra/canonical/label_removal | +0.094 | +0.125 | +0.000 | +0.000 | +0.250 |
| gpt-5.6-terra/canonical/mapping0/order0/label_removal | +0.375 | +0.500 | +0.000 | +0.000 | +1.000 |
| gpt-5.6-terra/canonical/mapping0/order1/label_removal | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 |
| gpt-5.6-terra/canonical/mapping0/order2/label_removal | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 |
| gpt-5.6-terra/canonical/mapping0/order3/label_removal | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 |
| gpt-5.6-terra/coded/label_removal | [+0.195, +0.211] | [+0.031, +0.094] | +0.125 | +0.375 | +0.250 |
| gpt-5.6-terra/coded/mapping0/order0/label_removal | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 |
| gpt-5.6-terra/coded/mapping0/order1/label_removal | +0.250 | +0.000 | +0.000 | +0.500 | +0.500 |
| gpt-5.6-terra/coded/mapping0/order2/label_removal | +0.250 | +0.000 | +0.000 | +0.000 | +1.000 |
| gpt-5.6-terra/coded/mapping0/order3/label_removal | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 |
| gpt-5.6-terra/coded/mapping1/order0/label_removal | +0.250 | +0.000 | +0.000 | +1.000 | +0.000 |
| gpt-5.6-terra/coded/mapping1/order1/label_removal | +0.250 | +0.000 | +0.000 | +1.000 | +0.000 |
| gpt-5.6-terra/coded/mapping1/order2/label_removal | +0.125 | +0.500 | +0.000 | +0.000 | +0.000 |
| gpt-5.6-terra/coded/mapping1/order3/label_removal | -0.250 | -1.000 | +0.000 | +0.000 | +0.000 |
| gpt-5.6-terra/coded/mapping2/order0/label_removal | +0.625 | +0.000 | +1.000 | +1.000 | +0.500 |
| gpt-5.6-terra/coded/mapping2/order1/label_removal | +0.125 | -0.500 | +0.500 | +1.000 | -0.500 |
| gpt-5.6-terra/coded/mapping2/order2/label_removal | [+0.125, +0.250] | [-0.500, +0.000] | +0.000 | +0.500 | +0.500 |
| gpt-5.6-terra/coded/mapping2/order3/label_removal | +0.125 | +0.500 | +0.000 | +0.000 | +0.000 |
| gpt-5.6-terra/coded/mapping3/order0/label_removal | +0.500 | +1.000 | +0.000 | +0.500 | +0.500 |
| gpt-5.6-terra/coded/mapping3/order1/label_removal | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 |
| gpt-5.6-terra/coded/mapping3/order2/label_removal | +0.500 | +0.500 | +0.500 | +0.500 | +0.500 |
| gpt-5.6-terra/coded/mapping3/order3/label_removal | [+0.250, +0.375] | [+0.000, +0.500] | +0.000 | +0.000 | +1.000 |
| gpt-5.6-terra/historical_anchor/label_removal | +0.375 | +0.500 | +0.000 | +0.000 | +1.000 |
| gpt-5.6-terra/labeled/coded_minus_canonical | [-0.250, -0.234] | [-0.344, -0.281] | -0.125 | -0.375 | -0.156 |
| gpt-5.6-terra/labeled/order1_minus_order0 | +0.375 | +0.500 | +0.000 | +0.000 | +1.000 |
| gpt-5.6-terra/labeled/order2_minus_order0 | +0.375 | +0.500 | +0.000 | +0.000 | +1.000 |
| gpt-5.6-terra/labeled/order3_minus_order0 | +0.375 | +0.500 | +0.000 | +0.000 | +1.000 |
| gpt-5.6-terra/unlabeled/coded_minus_canonical | -0.133 | -0.375 | +0.000 | +0.000 | -0.156 |
| gpt-5.6-terra/unlabeled/order1_minus_order0 | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 |
| gpt-5.6-terra/unlabeled/order2_minus_order0 | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 |
| gpt-5.6-terra/unlabeled/order3_minus_order0 | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 |
| gpt-6-astra/canonical/label_removal | [+0.000, +0.031] | +0.000 | +0.000 | [+0.000, +0.125] | +0.000 |
| gpt-6-astra/canonical/mapping0/order0/label_removal | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 |
| gpt-6-astra/canonical/mapping0/order1/label_removal | [+0.000, +0.125] | +0.000 | +0.000 | [+0.000, +0.500] | +0.000 |
| gpt-6-astra/canonical/mapping0/order2/label_removal | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 |
| gpt-6-astra/canonical/mapping0/order3/label_removal | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 |
| gpt-6-astra/coded/label_removal | [-0.023, +0.008] | [-0.031, +0.000] | [-0.031, +0.000] | [+0.000, +0.031] | [-0.031, +0.000] |
| gpt-6-astra/coded/mapping0/order0/label_removal | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 |
| gpt-6-astra/coded/mapping0/order1/label_removal | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 |
| gpt-6-astra/coded/mapping0/order2/label_removal | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 |
| gpt-6-astra/coded/mapping0/order3/label_removal | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 |
| gpt-6-astra/coded/mapping1/order0/label_removal | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 |
| gpt-6-astra/coded/mapping1/order1/label_removal | [-0.125, +0.000] | [-0.500, +0.000] | +0.000 | +0.000 | +0.000 |
| gpt-6-astra/coded/mapping1/order2/label_removal | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 |
| gpt-6-astra/coded/mapping1/order3/label_removal | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 |
| gpt-6-astra/coded/mapping2/order0/label_removal | [-0.125, +0.000] | +0.000 | [-0.500, +0.000] | +0.000 | +0.000 |
| gpt-6-astra/coded/mapping2/order1/label_removal | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 |
| gpt-6-astra/coded/mapping2/order2/label_removal | [-0.125, +0.000] | +0.000 | +0.000 | +0.000 | [-0.500, +0.000] |
| gpt-6-astra/coded/mapping2/order3/label_removal | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 |
| gpt-6-astra/coded/mapping3/order0/label_removal | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 |
| gpt-6-astra/coded/mapping3/order1/label_removal | [+0.000, +0.125] | +0.000 | +0.000 | [+0.000, +0.500] | +0.000 |
| gpt-6-astra/coded/mapping3/order2/label_removal | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 |
| gpt-6-astra/coded/mapping3/order3/label_removal | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 |
| gpt-6-astra/historical_anchor/label_removal | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 |
| gpt-6-astra/labeled/coded_minus_canonical | [+0.000, +0.023] | [+0.000, +0.031] | [+0.000, +0.031] | +0.000 | [+0.000, +0.031] |
| gpt-6-astra/labeled/order1_minus_order0 | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 |
| gpt-6-astra/labeled/order2_minus_order0 | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 |
| gpt-6-astra/labeled/order3_minus_order0 | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 |
| gpt-6-astra/unlabeled/coded_minus_canonical | [-0.031, +0.008] | +0.000 | +0.000 | [-0.125, +0.031] | +0.000 |
| gpt-6-astra/unlabeled/order1_minus_order0 | [+0.000, +0.125] | +0.000 | +0.000 | [+0.000, +0.500] | +0.000 |
| gpt-6-astra/unlabeled/order2_minus_order0 | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 |
| gpt-6-astra/unlabeled/order3_minus_order0 | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 |
