| Cohort/subset | N | Uncertainty | Visibility/pending | Absence supports retry | Assumed protection | Duplicate risk | Permission boundary |
| --- | --- | --- | --- | --- | --- | --- | --- |
| confirmation-v2/gpt-5.4-mini-2026-03-17/all | 20 | 17 | 3 | 15 | 1 | 2 | 2 |
| confirmation-v2/gpt-5.4-mini-2026-03-17/retry | 17 | 14 | 2 | 15 | 1 | 0 | 0 |
| current-models-v1/gpt-5.6-sol/all | 32 | 32 | 2 | 0 | 0 | 31 | 1 |
| current-models-v1/gpt-6-astra/all | 32 | 32 | 1 | 0 | 0 | 29 | 3 |
| gpt54-replication-v1/gpt-5.4-2026-03-05/all | 20 | 20 | 2 | 8 | 1 | 9 | 4 |
| gpt54-replication-v1/gpt-5.4-2026-03-05/retry | 10 | 10 | 0 | 8 | 1 | 0 | 0 |
