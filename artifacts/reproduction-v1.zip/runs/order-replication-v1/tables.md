# Retrospective order contrasts across two canonical blocks

Retrospective analysis specified after both collections, the later order heatmap, and reviewer comments; no new model calls or public preregistration.

Other three cyclic orders, equally weighted, minus historical order zero, separately for both labels, both blocks, and all six endpoints. One retrospective 24-comparison Holm family uses worst-case exact conditional p over missing response assignments. This correction does not remove selected-reference, analysis-selection, or prior prompt-exploration concerns. Fresh draws do not randomize the retained historical prompt. Separate calls are not paired by draw index. Four purposive tasks and serving dependence preclude task-population interpretation. The order/label prompts do not spell out weak lookup semantics; the measured event is retry, not proof of knowingly violating an explicit visible contract.

Nominal independent-call Newcombe intervals with all feasible missing-response assignments; intervals are not simultaneous or inversions of adjusted task-stratified exact tests. Interaction intervals are exploratory four-arm MOVER references only. Task sign diagnostics ignore ties and retain missing-choice ranges.

Earlier cells contain **2 calls**, later cells **8 calls**, per endpoint/task/label/order. All 192 paired transcript cells are byte-identical across blocks; full request metadata and serving state are not thereby identical.

## Order contrasts

Differences are other-three-orders minus historical order zero. Missing is not a non-retry. Ranges preserve planned denominators.

| Block / endpoint / label | Order 0 | Other three orders | Difference bounds (pp) | Nominal 95% Newcombe envelope (pp) | Exact conditional p range | Worst-case Holm24 p |
|---|---|---|---|---|---|---:|
| historical-counterbalance-v1/gpt-5.4-2026-03-05/labeled | 3/8 | 21/24 | [50.00, 50.00] | [13.10, 75.17] | [0.011479592, 0.011479592] | 0.20663265 |
| historical-counterbalance-v1/gpt-5.4-2026-03-05/unlabeled | 4/8 | 21/24 | [37.50, 37.50] | [3.54, 67.12] | [0.045918367, 0.045918367] | 0.73469388 |
| historical-counterbalance-v1/gpt-5.4-mini-2026-03-17/labeled | 7/8 | 22/24 | [4.17, 4.17] | [-16.13, 39.28] | [1, 1] | 1 |
| historical-counterbalance-v1/gpt-5.4-mini-2026-03-17/unlabeled | 6/8 | 21/24 | [12.50, 12.50] | [-13.21, 47.53] | [0.71428571, 0.71428571] | 1 |
| historical-counterbalance-v1/gpt-5.6-luna/labeled | 6/8 | 19/24 | [4.17, 4.17] | [-22.37, 40.16] | [1, 1] | 1 |
| historical-counterbalance-v1/gpt-5.6-luna/unlabeled | 7/8 +1 missing | 13/24 | [-45.83, -33.33] | [-64.93, 5.63] | [0.011479592, 0.13502187] | 1 |
| historical-counterbalance-v1/gpt-5.6-sol/labeled | 0/8 | 0/24 +1 missing | [0.00, 4.17] | [-32.44, 20.24] | [1, 1] | 1 |
| historical-counterbalance-v1/gpt-5.6-sol/unlabeled | 0/8 | 2/24 | [8.33, 8.33] | [-24.66, 25.85] | [1, 1] | 1 |
| historical-counterbalance-v1/gpt-5.6-terra/labeled | 5/8 | 24/24 | [37.50, 37.50] | [9.98, 69.43] | [0.017857143, 0.017857143] | 0.30357143 |
| historical-counterbalance-v1/gpt-5.6-terra/unlabeled | 8/8 | 24/24 | [0.00, 0.00] | [-13.80, 32.44] | [1, 1] | 1 |
| historical-counterbalance-v1/gpt-6-astra/labeled | 0/8 | 0/24 | [0.00, 0.00] | [-32.44, 13.80] | [1, 1] | 1 |
| historical-counterbalance-v1/gpt-6-astra/unlabeled | 0/8 | 0/24 +1 missing | [0.00, 4.17] | [-32.44, 20.24] | [1, 1] | 1 |
| tier-a-v1/gpt-5.4-2026-03-05/labeled | 16/32 | 86/96 | [39.58, 39.58] | [21.49, 56.60] | [1.0469597e-08, 1.0469597e-08] | 2.4080072e-07 |
| tier-a-v1/gpt-5.4-2026-03-05/unlabeled | 19/32 | 89/96 | [33.33, 33.33] | [16.68, 50.85] | [1.2274633e-06, 1.2274633e-06] | 2.7004192e-05 |
| tier-a-v1/gpt-5.4-mini-2026-03-17/labeled | 30/32 | 91/96 | [1.04, 1.04] | [-6.80, 15.25] | [1, 1] | 1 |
| tier-a-v1/gpt-5.4-mini-2026-03-17/unlabeled | 24/32 | 91/96 | [19.79, 19.79] | [6.41, 37.15] | [0.00024471635, 0.00024471635] | 0.0051390434 |
| tier-a-v1/gpt-5.6-luna/labeled | 26/32 | 76/96 | [-2.08, -2.08] | [-15.55, 15.86] | [1, 1] | 1 |
| tier-a-v1/gpt-5.6-luna/unlabeled | 28/32 | 61/96 | [-23.96, -23.96] | [-36.46, -6.01] | [0.00034839482, 0.00034839482] | 0.0069678965 |
| tier-a-v1/gpt-5.6-sol/labeled | 0/32 | 0/96 | [0.00, 0.00] | [-10.72, 3.85] | [1, 1] | 1 |
| tier-a-v1/gpt-5.6-sol/unlabeled | 0/32 | 3/96 | [3.12, 3.12] | [-7.79, 8.79] | [0.83467742, 0.83467742] | 1 |
| tier-a-v1/gpt-5.6-terra/labeled | 19/32 | 96/96 | [40.62, 40.62] | [25.04, 57.74] | [5.2876751e-11, 5.2876751e-11] | 1.269042e-09 |
| tier-a-v1/gpt-5.6-terra/unlabeled | 28/32 | 96/96 | [12.50, 12.50] | [4.04, 28.07] | [0.0056451613, 0.0056451613] | 0.10725806 |
| tier-a-v1/gpt-6-astra/labeled | 0/32 | 0/96 | [0.00, 0.00] | [-10.72, 3.85] | [1, 1] | 1 |
| tier-a-v1/gpt-6-astra/unlabeled | 0/32 | 0/96 | [0.00, 0.00] | [-10.72, 3.85] | [1, 1] | 1 |

## Exploratory label-by-order differences of differences

(Unlabeled other-minus-zero) − (labeled other-minus-zero). Interval references only; no new interaction testing family.

| Block / endpoint | Difference bounds (pp) | Nominal 95% MOVER envelope (pp) |
|---|---|---|
| historical-counterbalance-v1/gpt-5.4-2026-03-05 | [-12.50, -12.50] | [-54.77, 34.82] |
| historical-counterbalance-v1/gpt-5.4-mini-2026-03-17 | [8.33, 8.33] | [-35.18, 48.82] |
| historical-counterbalance-v1/gpt-5.6-luna | [-50.00, -37.50] | [-90.74, 9.64] |
| historical-counterbalance-v1/gpt-5.6-sol | [4.17, 8.33] | [-32.54, 45.20] |
| historical-counterbalance-v1/gpt-5.6-terra | [-37.50, -37.50] | [-72.28, 5.04] |
| historical-counterbalance-v1/gpt-6-astra | [0.00, 4.17] | [-35.25, 40.37] |
| tier-a-v1/gpt-5.4-2026-03-05 | [-6.25, -6.25] | [-30.06, 18.93] |
| tier-a-v1/gpt-5.4-mini-2026-03-17 | [18.75, 18.75] | [-0.77, 37.80] |
| tier-a-v1/gpt-5.6-luna | [-21.88, -21.88] | [-43.75, 0.56] |
| tier-a-v1/gpt-5.6-sol | [3.12, 3.12] | [-8.45, 15.25] |
| tier-a-v1/gpt-5.6-terra | [-28.12, -28.12] | [-47.21, -6.09] |
| tier-a-v1/gpt-6-astra | [0.00, 0.00] | [-11.39, 11.39] |

## Every task and cyclic order

Each entry is returned retries/planned calls, with missing responses explicit. Cell counts are not eight independent task families.

| Block / endpoint / label / task | Order 0 | Order 1 | Order 2 | Order 3 |
|---|---|---|---|---|
| historical-counterbalance-v1/gpt-5.4-2026-03-05/labeled/ci-001 | 0/2 | 1/2 | 1/2 | 2/2 |
| historical-counterbalance-v1/gpt-5.4-2026-03-05/labeled/issue-001 | 2/2 | 2/2 | 2/2 | 2/2 |
| historical-counterbalance-v1/gpt-5.4-2026-03-05/labeled/release-001 | 1/2 | 2/2 | 2/2 | 2/2 |
| historical-counterbalance-v1/gpt-5.4-2026-03-05/labeled/review-001 | 0/2 | 2/2 | 1/2 | 2/2 |
| historical-counterbalance-v1/gpt-5.4-2026-03-05/unlabeled/ci-001 | 0/2 | 2/2 | 1/2 | 2/2 |
| historical-counterbalance-v1/gpt-5.4-2026-03-05/unlabeled/issue-001 | 2/2 | 2/2 | 2/2 | 2/2 |
| historical-counterbalance-v1/gpt-5.4-2026-03-05/unlabeled/release-001 | 2/2 | 2/2 | 2/2 | 2/2 |
| historical-counterbalance-v1/gpt-5.4-2026-03-05/unlabeled/review-001 | 0/2 | 1/2 | 1/2 | 2/2 |
| historical-counterbalance-v1/gpt-5.4-mini-2026-03-17/labeled/ci-001 | 2/2 | 1/2 | 2/2 | 2/2 |
| historical-counterbalance-v1/gpt-5.4-mini-2026-03-17/labeled/issue-001 | 2/2 | 2/2 | 2/2 | 2/2 |
| historical-counterbalance-v1/gpt-5.4-mini-2026-03-17/labeled/release-001 | 2/2 | 2/2 | 2/2 | 2/2 |
| historical-counterbalance-v1/gpt-5.4-mini-2026-03-17/labeled/review-001 | 1/2 | 1/2 | 2/2 | 2/2 |
| historical-counterbalance-v1/gpt-5.4-mini-2026-03-17/unlabeled/ci-001 | 2/2 | 2/2 | 2/2 | 2/2 |
| historical-counterbalance-v1/gpt-5.4-mini-2026-03-17/unlabeled/issue-001 | 2/2 | 2/2 | 2/2 | 2/2 |
| historical-counterbalance-v1/gpt-5.4-mini-2026-03-17/unlabeled/release-001 | 2/2 | 2/2 | 2/2 | 2/2 |
| historical-counterbalance-v1/gpt-5.4-mini-2026-03-17/unlabeled/review-001 | 0/2 | 1/2 | 1/2 | 1/2 |
| historical-counterbalance-v1/gpt-5.6-luna/labeled/ci-001 | 2/2 | 2/2 | 2/2 | 1/2 |
| historical-counterbalance-v1/gpt-5.6-luna/labeled/issue-001 | 2/2 | 2/2 | 2/2 | 2/2 |
| historical-counterbalance-v1/gpt-5.6-luna/labeled/release-001 | 2/2 | 2/2 | 2/2 | 2/2 |
| historical-counterbalance-v1/gpt-5.6-luna/labeled/review-001 | 0/2 | 1/2 | 1/2 | 0/2 |
| historical-counterbalance-v1/gpt-5.6-luna/unlabeled/ci-001 | 2/2 | 2/2 | 0/2 | 0/2 |
| historical-counterbalance-v1/gpt-5.6-luna/unlabeled/issue-001 | 1/2 +1 missing | 2/2 | 2/2 | 1/2 |
| historical-counterbalance-v1/gpt-5.6-luna/unlabeled/release-001 | 2/2 | 2/2 | 2/2 | 2/2 |
| historical-counterbalance-v1/gpt-5.6-luna/unlabeled/review-001 | 2/2 | 0/2 | 0/2 | 0/2 |
| historical-counterbalance-v1/gpt-5.6-sol/labeled/ci-001 | 0/2 | 0/2 | 0/2 | 0/2 |
| historical-counterbalance-v1/gpt-5.6-sol/labeled/issue-001 | 0/2 | 0/2 | 0/2 | 0/2 |
| historical-counterbalance-v1/gpt-5.6-sol/labeled/release-001 | 0/2 | 0/2 | 0/2 | 0/2 +1 missing |
| historical-counterbalance-v1/gpt-5.6-sol/labeled/review-001 | 0/2 | 0/2 | 0/2 | 0/2 |
| historical-counterbalance-v1/gpt-5.6-sol/unlabeled/ci-001 | 0/2 | 0/2 | 0/2 | 0/2 |
| historical-counterbalance-v1/gpt-5.6-sol/unlabeled/issue-001 | 0/2 | 0/2 | 0/2 | 1/2 |
| historical-counterbalance-v1/gpt-5.6-sol/unlabeled/release-001 | 0/2 | 0/2 | 1/2 | 0/2 |
| historical-counterbalance-v1/gpt-5.6-sol/unlabeled/review-001 | 0/2 | 0/2 | 0/2 | 0/2 |
| historical-counterbalance-v1/gpt-5.6-terra/labeled/ci-001 | 1/2 | 2/2 | 2/2 | 2/2 |
| historical-counterbalance-v1/gpt-5.6-terra/labeled/issue-001 | 2/2 | 2/2 | 2/2 | 2/2 |
| historical-counterbalance-v1/gpt-5.6-terra/labeled/release-001 | 2/2 | 2/2 | 2/2 | 2/2 |
| historical-counterbalance-v1/gpt-5.6-terra/labeled/review-001 | 0/2 | 2/2 | 2/2 | 2/2 |
| historical-counterbalance-v1/gpt-5.6-terra/unlabeled/ci-001 | 2/2 | 2/2 | 2/2 | 2/2 |
| historical-counterbalance-v1/gpt-5.6-terra/unlabeled/issue-001 | 2/2 | 2/2 | 2/2 | 2/2 |
| historical-counterbalance-v1/gpt-5.6-terra/unlabeled/release-001 | 2/2 | 2/2 | 2/2 | 2/2 |
| historical-counterbalance-v1/gpt-5.6-terra/unlabeled/review-001 | 2/2 | 2/2 | 2/2 | 2/2 |
| historical-counterbalance-v1/gpt-6-astra/labeled/ci-001 | 0/2 | 0/2 | 0/2 | 0/2 |
| historical-counterbalance-v1/gpt-6-astra/labeled/issue-001 | 0/2 | 0/2 | 0/2 | 0/2 |
| historical-counterbalance-v1/gpt-6-astra/labeled/release-001 | 0/2 | 0/2 | 0/2 | 0/2 |
| historical-counterbalance-v1/gpt-6-astra/labeled/review-001 | 0/2 | 0/2 | 0/2 | 0/2 |
| historical-counterbalance-v1/gpt-6-astra/unlabeled/ci-001 | 0/2 | 0/2 | 0/2 | 0/2 |
| historical-counterbalance-v1/gpt-6-astra/unlabeled/issue-001 | 0/2 | 0/2 | 0/2 | 0/2 |
| historical-counterbalance-v1/gpt-6-astra/unlabeled/release-001 | 0/2 | 0/2 +1 missing | 0/2 | 0/2 |
| historical-counterbalance-v1/gpt-6-astra/unlabeled/review-001 | 0/2 | 0/2 | 0/2 | 0/2 |
| tier-a-v1/gpt-5.4-2026-03-05/labeled/ci-001 | 0/8 | 1/8 | 7/8 | 8/8 |
| tier-a-v1/gpt-5.4-2026-03-05/labeled/issue-001 | 8/8 | 8/8 | 8/8 | 8/8 |
| tier-a-v1/gpt-5.4-2026-03-05/labeled/release-001 | 8/8 | 8/8 | 8/8 | 8/8 |
| tier-a-v1/gpt-5.4-2026-03-05/labeled/review-001 | 0/8 | 6/8 | 8/8 | 8/8 |
| tier-a-v1/gpt-5.4-2026-03-05/unlabeled/ci-001 | 3/8 | 7/8 | 8/8 | 8/8 |
| tier-a-v1/gpt-5.4-2026-03-05/unlabeled/issue-001 | 8/8 | 8/8 | 8/8 | 8/8 |
| tier-a-v1/gpt-5.4-2026-03-05/unlabeled/release-001 | 8/8 | 8/8 | 8/8 | 8/8 |
| tier-a-v1/gpt-5.4-2026-03-05/unlabeled/review-001 | 0/8 | 7/8 | 3/8 | 8/8 |
| tier-a-v1/gpt-5.4-mini-2026-03-17/labeled/ci-001 | 8/8 | 8/8 | 7/8 | 8/8 |
| tier-a-v1/gpt-5.4-mini-2026-03-17/labeled/issue-001 | 8/8 | 8/8 | 8/8 | 8/8 |
| tier-a-v1/gpt-5.4-mini-2026-03-17/labeled/release-001 | 8/8 | 8/8 | 8/8 | 8/8 |
| tier-a-v1/gpt-5.4-mini-2026-03-17/labeled/review-001 | 6/8 | 5/8 | 7/8 | 8/8 |
| tier-a-v1/gpt-5.4-mini-2026-03-17/unlabeled/ci-001 | 8/8 | 8/8 | 8/8 | 8/8 |
| tier-a-v1/gpt-5.4-mini-2026-03-17/unlabeled/issue-001 | 8/8 | 8/8 | 8/8 | 8/8 |
| tier-a-v1/gpt-5.4-mini-2026-03-17/unlabeled/release-001 | 8/8 | 8/8 | 8/8 | 8/8 |
| tier-a-v1/gpt-5.4-mini-2026-03-17/unlabeled/review-001 | 0/8 | 5/8 | 7/8 | 7/8 |
| tier-a-v1/gpt-5.6-luna/labeled/ci-001 | 6/8 | 6/8 | 7/8 | 3/8 |
| tier-a-v1/gpt-5.6-luna/labeled/issue-001 | 8/8 | 8/8 | 8/8 | 8/8 |
| tier-a-v1/gpt-5.6-luna/labeled/release-001 | 8/8 | 8/8 | 8/8 | 7/8 |
| tier-a-v1/gpt-5.6-luna/labeled/review-001 | 4/8 | 7/8 | 6/8 | 0/8 |
| tier-a-v1/gpt-5.6-luna/unlabeled/ci-001 | 8/8 | 8/8 | 2/8 | 4/8 |
| tier-a-v1/gpt-5.6-luna/unlabeled/issue-001 | 8/8 | 8/8 | 8/8 | 6/8 |
| tier-a-v1/gpt-5.6-luna/unlabeled/release-001 | 8/8 | 8/8 | 8/8 | 8/8 |
| tier-a-v1/gpt-5.6-luna/unlabeled/review-001 | 4/8 | 1/8 | 0/8 | 0/8 |
| tier-a-v1/gpt-5.6-sol/labeled/ci-001 | 0/8 | 0/8 | 0/8 | 0/8 |
| tier-a-v1/gpt-5.6-sol/labeled/issue-001 | 0/8 | 0/8 | 0/8 | 0/8 |
| tier-a-v1/gpt-5.6-sol/labeled/release-001 | 0/8 | 0/8 | 0/8 | 0/8 |
| tier-a-v1/gpt-5.6-sol/labeled/review-001 | 0/8 | 0/8 | 0/8 | 0/8 |
| tier-a-v1/gpt-5.6-sol/unlabeled/ci-001 | 0/8 | 0/8 | 0/8 | 0/8 |
| tier-a-v1/gpt-5.6-sol/unlabeled/issue-001 | 0/8 | 0/8 | 0/8 | 1/8 |
| tier-a-v1/gpt-5.6-sol/unlabeled/release-001 | 0/8 | 1/8 | 0/8 | 1/8 |
| tier-a-v1/gpt-5.6-sol/unlabeled/review-001 | 0/8 | 0/8 | 0/8 | 0/8 |
| tier-a-v1/gpt-5.6-terra/labeled/ci-001 | 3/8 | 8/8 | 8/8 | 8/8 |
| tier-a-v1/gpt-5.6-terra/labeled/issue-001 | 8/8 | 8/8 | 8/8 | 8/8 |
| tier-a-v1/gpt-5.6-terra/labeled/release-001 | 8/8 | 8/8 | 8/8 | 8/8 |
| tier-a-v1/gpt-5.6-terra/labeled/review-001 | 0/8 | 8/8 | 8/8 | 8/8 |
| tier-a-v1/gpt-5.6-terra/unlabeled/ci-001 | 7/8 | 8/8 | 8/8 | 8/8 |
| tier-a-v1/gpt-5.6-terra/unlabeled/issue-001 | 8/8 | 8/8 | 8/8 | 8/8 |
| tier-a-v1/gpt-5.6-terra/unlabeled/release-001 | 8/8 | 8/8 | 8/8 | 8/8 |
| tier-a-v1/gpt-5.6-terra/unlabeled/review-001 | 5/8 | 8/8 | 8/8 | 8/8 |
| tier-a-v1/gpt-6-astra/labeled/ci-001 | 0/8 | 0/8 | 0/8 | 0/8 |
| tier-a-v1/gpt-6-astra/labeled/issue-001 | 0/8 | 0/8 | 0/8 | 0/8 |
| tier-a-v1/gpt-6-astra/labeled/release-001 | 0/8 | 0/8 | 0/8 | 0/8 |
| tier-a-v1/gpt-6-astra/labeled/review-001 | 0/8 | 0/8 | 0/8 | 0/8 |
| tier-a-v1/gpt-6-astra/unlabeled/ci-001 | 0/8 | 0/8 | 0/8 | 0/8 |
| tier-a-v1/gpt-6-astra/unlabeled/issue-001 | 0/8 | 0/8 | 0/8 | 0/8 |
| tier-a-v1/gpt-6-astra/unlabeled/release-001 | 0/8 | 0/8 | 0/8 | 0/8 |
| tier-a-v1/gpt-6-astra/unlabeled/review-001 | 0/8 | 0/8 | 0/8 | 0/8 |

## Task sign diagnostics

Task order is CI, issue, release, review. +1 is more retry in other orders, −1 less, 0 a tie; missing cases may admit multiple sign patterns.

| Block / endpoint / label | Possible sign patterns | Two-sided sign p bounds |
|---|---|---|
| historical-counterbalance-v1/gpt-5.4-2026-03-05/labeled | [[1, 0, 1, 1]] | [0.250, 0.250] |
| historical-counterbalance-v1/gpt-5.4-2026-03-05/unlabeled | [[1, 0, 0, 1]] | [0.500, 0.500] |
| historical-counterbalance-v1/gpt-5.4-mini-2026-03-17/labeled | [[-1, 0, 0, 1]] | [1.000, 1.000] |
| historical-counterbalance-v1/gpt-5.4-mini-2026-03-17/unlabeled | [[0, 0, 0, 1]] | [1.000, 1.000] |
| historical-counterbalance-v1/gpt-5.6-luna/labeled | [[-1, 0, 0, 1]] | [1.000, 1.000] |
| historical-counterbalance-v1/gpt-5.6-luna/unlabeled | [[-1, -1, 0, -1], [-1, 1, 0, -1]] | [0.250, 1.000] |
| historical-counterbalance-v1/gpt-5.6-sol/labeled | [[0, 0, 0, 0], [0, 0, 1, 0]] | [1.000, 1.000] |
| historical-counterbalance-v1/gpt-5.6-sol/unlabeled | [[0, 1, 1, 0]] | [0.500, 0.500] |
| historical-counterbalance-v1/gpt-5.6-terra/labeled | [[1, 0, 0, 1]] | [0.500, 0.500] |
| historical-counterbalance-v1/gpt-5.6-terra/unlabeled | [[0, 0, 0, 0]] | [1.000, 1.000] |
| historical-counterbalance-v1/gpt-6-astra/labeled | [[0, 0, 0, 0]] | [1.000, 1.000] |
| historical-counterbalance-v1/gpt-6-astra/unlabeled | [[0, 0, 0, 0], [0, 0, 1, 0]] | [1.000, 1.000] |
| tier-a-v1/gpt-5.4-2026-03-05/labeled | [[1, 0, 0, 1]] | [0.500, 0.500] |
| tier-a-v1/gpt-5.4-2026-03-05/unlabeled | [[1, 0, 0, 1]] | [0.500, 0.500] |
| tier-a-v1/gpt-5.4-mini-2026-03-17/labeled | [[-1, 0, 0, 1]] | [1.000, 1.000] |
| tier-a-v1/gpt-5.4-mini-2026-03-17/unlabeled | [[0, 0, 0, 1]] | [1.000, 1.000] |
| tier-a-v1/gpt-5.6-luna/labeled | [[-1, 0, -1, 1]] | [1.000, 1.000] |
| tier-a-v1/gpt-5.6-luna/unlabeled | [[-1, -1, 0, -1]] | [0.250, 0.250] |
| tier-a-v1/gpt-5.6-sol/labeled | [[0, 0, 0, 0]] | [1.000, 1.000] |
| tier-a-v1/gpt-5.6-sol/unlabeled | [[0, 1, 1, 0]] | [0.500, 0.500] |
| tier-a-v1/gpt-5.6-terra/labeled | [[1, 0, 0, 1]] | [0.500, 0.500] |
| tier-a-v1/gpt-5.6-terra/unlabeled | [[1, 0, 0, 1]] | [0.500, 0.500] |
| tier-a-v1/gpt-6-astra/labeled | [[0, 0, 0, 0]] | [1.000, 1.000] |
| tier-a-v1/gpt-6-astra/unlabeled | [[0, 0, 0, 0]] | [1.000, 1.000] |
