# Later canonical and supplied-key blocks

Later collection blocks; no primary pooling with earlier data. Supplied-key schema/affordance change does not isolate mechanism. Canonical estimates are conditional on four purposive tasks and cyclic orders; increased call precision does not establish task generality or equivalence. Metric bounds are marginal; different metrics extrema need not be jointly attainable. Astra low is separate from other none settings.

Returned 1776/1776; attempted 1776. Known cost $2.799830; unknown reserve $0.000000.

## Canonical response counts

| Endpoint | Label | Retry | Stop | Wait | Unresolved | Missing | Planned |
|---|---|---:|---:|---:|---:|---:|---:|
| gpt-5.4-2026-03-05 | labeled | 102 | 0 | 0 | 26 | 0 | 128 |
| gpt-5.4-2026-03-05 | unlabeled | 108 | 0 | 0 | 20 | 0 | 128 |
| gpt-5.4-mini-2026-03-17 | labeled | 121 | 0 | 2 | 5 | 0 | 128 |
| gpt-5.4-mini-2026-03-17 | unlabeled | 115 | 1 | 0 | 12 | 0 | 128 |
| gpt-5.6-luna | labeled | 102 | 0 | 0 | 26 | 0 | 128 |
| gpt-5.6-luna | unlabeled | 89 | 0 | 0 | 39 | 0 | 128 |
| gpt-5.6-sol | labeled | 0 | 0 | 0 | 128 | 0 | 128 |
| gpt-5.6-sol | unlabeled | 3 | 0 | 0 | 125 | 0 | 128 |
| gpt-5.6-terra | labeled | 115 | 0 | 0 | 13 | 0 | 128 |
| gpt-5.6-terra | unlabeled | 124 | 0 | 0 | 4 | 0 | 128 |
| gpt-6-astra | labeled | 0 | 0 | 0 | 128 | 0 | 128 |
| gpt-6-astra | unlabeled | 0 | 0 | 0 | 128 | 0 | 128 |

## Later canonical contrasts

| Endpoint | U minus L (pp) | 95% Newcombe envelope (pp) | Six-way Holm conditional p |
|---|---:|---:|---:|
| gpt-5.4-mini-2026-03-17 | [-4.69, -4.69] | [-11.71, +2.10] | 0.568872 |
| gpt-5.4-2026-03-05 | [+4.69, +4.69] | [-4.78, +14.09] | 0.568872 |
| gpt-5.6-sol | [+2.34, +2.34] | [-0.95, +6.66] | 0.568872 |
| gpt-5.6-terra | [+7.03, +7.03] | [+0.83, +13.75] | 0.0145239 |
| gpt-5.6-luna | [-10.16, -10.16] | [-20.55, +0.52] | 0.105116 |
| gpt-6-astra | [+0.00, +0.00] | [-2.91, +2.91] | 1 |

Nominal call-reference intervals are not simultaneous. Conditional tests stratify by task and cyclic order. No pairing by repetition number; six predeclared later-block contrasts form their own Holm family.


## Supplied-key response counts (both labels)

| Endpoint / original key | Protected keyed dispatch | Unprotected keyed dispatch | Bare retry | Stop | Wait | Unresolved | Missing | Planned |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| gpt-5.6-sol/omitted | 0 | 0 | 0 | 0 | 0 | 40 | 0 | 40 |
| gpt-5.6-sol/present | 40 | 0 | 0 | 0 | 0 | 0 | 0 | 40 |
| gpt-5.6-terra/omitted | 0 | 0 | 0 | 0 | 0 | 40 | 0 | 40 |
| gpt-5.6-terra/present | 40 | 0 | 0 | 0 | 0 | 0 | 0 | 40 |
| gpt-5.6-luna/omitted | 0 | 7 | 0 | 0 | 0 | 33 | 0 | 40 |
| gpt-5.6-luna/present | 36 | 1 | 0 | 0 | 0 | 3 | 0 | 40 |

## All response cells and replay outcomes

| Condition | Responses / planned | FRP | Duplicates | Omissions | Unresolved | Exact resolved | Terminal progress / planned |
|---|---:|---:|---:|---:|---:|---:|---:|
| gpt-5.4-2026-03-05/canonical/labeled | 128/128 | 306 | 204 | 26 | 78 | 102 | 102/128 |
| gpt-5.4-2026-03-05/canonical/unlabeled | 128/128 | 324 | 216 | 20 | 60 | 108 | 108/128 |
| gpt-5.4-mini-2026-03-17/canonical/labeled | 128/128 | 363 | 242 | 7 | 21 | 121 | 121/128 |
| gpt-5.4-mini-2026-03-17/canonical/unlabeled | 128/128 | 345 | 230 | 13 | 36 | 117 | 115/128 |
| gpt-5.6-luna/canonical/labeled | 128/128 | 306 | 204 | 26 | 78 | 102 | 102/128 |
| gpt-5.6-luna/canonical/unlabeled | 128/128 | 267 | 178 | 39 | 117 | 89 | 89/128 |
| gpt-5.6-luna/supplied_key/labeled/omitted | 20/20 | 9 | 6 | 17 | 51 | 3 | 3/20 |
| gpt-5.6-luna/supplied_key/labeled/present | 20/20 | 0 | 0 | 3 | 9 | 51 | 17/20 |
| gpt-5.6-luna/supplied_key/unlabeled/omitted | 20/20 | 12 | 8 | 16 | 48 | 4 | 4/20 |
| gpt-5.6-luna/supplied_key/unlabeled/present | 20/20 | 3 | 2 | 0 | 0 | 58 | 20/20 |
| gpt-5.6-sol/canonical/labeled | 128/128 | 0 | 0 | 128 | 384 | 0 | 0/128 |
| gpt-5.6-sol/canonical/unlabeled | 128/128 | 9 | 6 | 125 | 375 | 3 | 3/128 |
| gpt-5.6-sol/supplied_key/labeled/omitted | 20/20 | 0 | 0 | 20 | 60 | 0 | 0/20 |
| gpt-5.6-sol/supplied_key/labeled/present | 20/20 | 0 | 0 | 0 | 0 | 60 | 20/20 |
| gpt-5.6-sol/supplied_key/unlabeled/omitted | 20/20 | 0 | 0 | 20 | 60 | 0 | 0/20 |
| gpt-5.6-sol/supplied_key/unlabeled/present | 20/20 | 0 | 0 | 0 | 0 | 60 | 20/20 |
| gpt-5.6-terra/canonical/labeled | 128/128 | 345 | 230 | 13 | 39 | 115 | 115/128 |
| gpt-5.6-terra/canonical/unlabeled | 128/128 | 372 | 248 | 4 | 12 | 124 | 124/128 |
| gpt-5.6-terra/supplied_key/labeled/omitted | 20/20 | 0 | 0 | 20 | 60 | 0 | 0/20 |
| gpt-5.6-terra/supplied_key/labeled/present | 20/20 | 0 | 0 | 0 | 0 | 60 | 20/20 |
| gpt-5.6-terra/supplied_key/unlabeled/omitted | 20/20 | 0 | 0 | 20 | 60 | 0 | 0/20 |
| gpt-5.6-terra/supplied_key/unlabeled/present | 20/20 | 0 | 0 | 0 | 0 | 60 | 20/20 |
| gpt-6-astra/canonical/labeled | 128/128 | 0 | 0 | 128 | 384 | 0 | 0/128 |
| gpt-6-astra/canonical/unlabeled | 128/128 | 0 | 0 | 128 | 384 | 0 | 0/128 |

Replay counts use three correlated worlds per returned response. Missing-action outcome bounds, every task/order/label cell, supplied strings and exact canonical references are in report.json and requests.jsonl.

## Reproduction

```sh
PYTHONPATH=runs/tier-a-v1/collection-source python scripts/analyze_tier_a.py
```
