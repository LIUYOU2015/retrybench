"""Frozen later-block canonical and model-supplied-key collection, combined $5 cap."""
from __future__ import annotations
import argparse, concurrent.futures, fcntl, hashlib, json, os, random, shutil, socket, subprocess, threading, urllib.error, urllib.request
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from retrybench.serialization import canonical_json_sha256, read_json_object, read_jsonl, write_json, write_jsonl
import followup_studies as prior
from counterbalance_study import MODELS, RATES

if not __debug__:
    raise RuntimeError('Optimized execution disables validation and is not supported')

STUDY = 'tier-a-v1'
ROOT = Path(__file__).resolve().parents[1]
CAP = 5.0
KEY_MODELS = ['gpt-5.6-sol', 'gpt-5.6-terra', 'gpt-5.6-luna']

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def now(): return datetime.now(timezone.utc).isoformat()
def build_manifest():
    cases = []
    for old in read_jsonl(ROOT/'protocol/historical-counterbalance-v1/manifest.jsonl'):
        if old['representation'] != 'canonical' or old['repetition'] != 1: continue
        for rep in range(1, 9):
            c = {k:v for k,v in old.items() if k not in ('case_id','transcript_sha256','study','repetition')}
            c.update(study=STUDY, block='canonical', repetition=rep,
                     condition=old['requested_model']+'/canonical/'+old['label'], original_key=None)
            cases.append(prior.finish_case(c))
    for old in read_jsonl(ROOT/'protocol/label-protection-v1/manifest.jsonl'):
        if old['semantics'] != 'stated' or old['protection'] not in ('none','valid'): continue
        c = {k:v for k,v in old.items() if k not in ('case_id','transcript_sha256','study','condition','protection')}
        original = None if old['protection']=='none' else 'key-A'
        lines = [line for line in c['prompt'].splitlines() if not line.startswith('Candidate key for retry_with_key:')]
        prompt = '\n'.join(lines).replace('retry_with_key dispatches it with the displayed candidate key', 'retry_with_key dispatches it with the idempotency_key you supply')
        prompt += '\nReturn idempotency_key as a nonempty string for retry_with_key and null for every other action.'
        c.update(study=STUDY, block='supplied_key', original_key=original, original_key_state='omitted' if original is None else 'present', prompt=prompt)
        c['condition']='/'.join((c['requested_model'],c['block'],c['label'],c['original_key_state']))
        cases.append(prior.finish_case(c))
    random.Random(2026101001).shuffle(cases)
    return cases

def payload(c):
    p = prior.payload(c)
    p['service_tier'] = 'default'
    if c['block']=='supplied_key':
        schema=p['text']['format']['schema']
        schema['properties']['idempotency_key']={'type':['string','null']}
        schema['required'].append('idempotency_key')
    return p

def decode(c, raw):
    prior.RATES=RATES
    result=prior.decode(c,raw)
    if c['block']=='canonical' or raw.get('status')!='completed': return result
    try:
        text=''.join(x['text'] for item in raw.get('output',[]) for x in item.get('content',[]) if x.get('type')=='output_text')
        d=json.loads(text)
        assert isinstance(d,dict) and set(d)=={'action','rationale','idempotency_key'}
        assert d['action'] in c['allowed_actions'] and isinstance(d['rationale'],str)
        key=d['idempotency_key']
        assert (isinstance(key,str) and bool(key)) if d['action']=='retry_with_key' else key is None
    except (AssertionError,ValueError,TypeError):
        return dict({k:v for k,v in result.items() if k != 'decision'},status='invalid_output')
    return dict(result,status='complete',decision=d)

def reserve(c):
    # JSON bytes bound ordinary text token count conservatively, plus 4096 framing tokens.
    i,_,o=RATES[c['requested_model']]
    return ((len(json.dumps(payload(c),ensure_ascii=False).encode())+4096)*i*1.25 + c['max_output_tokens']*o)/1e6

def protected(c,d):
    return c['block']=='supplied_key' and d['action']=='retry_with_key' and c['original_key'] is not None and d.get('idempotency_key')==c['original_key']

def score(c,d):
    from retrybench.model import TASKS, EvidenceContract, Schedule
    from retrybench.service import DeterministicService, AmbiguousTimeout, seed_original_idempotency_record
    from retrybench.scoring import score_exact_state
    task=next(t for t in TASKS if t.task_id==c['task_id']);out=[]
    for name in c['schedules']:
        service=DeterministicService(task,Schedule(name),EvidenceContract.WEAK);operation='tier-a:'+c['case_id']
        try: service.start(operation)
        except AmbiguousTimeout: pass
        if c['original_key'] is not None: seed_original_idempotency_record(service,operation)
        assert service.status().value=='not_found'
        if name=='in_flight_late_commit': assert service.pending_original and service.steps==0
        action=d['action'];safe=protected(c,d);dispatch=action in ('retry','retry_with_key')
        if dispatch:
            if name=='in_flight_late_commit': assert service.pending_original and service.steps==0
            service.retry(operation,stable_idempotency=safe)
        service.settle();state=score_exact_state(task,operation,service.effects,action in ('wait','unresolved'))
        out.append(dict(case_id=c['case_id'],condition=c['condition'],task_id=c['task_id'],schedule=name,action=action,
            false_retry_permission=int(dispatch and not safe),duplicates=int(state.duplicate_effect),omissions=int(state.omission),
            unresolved=int(state.unresolved),ledger_correct=int(len(service.effects)==1),resolved_exact_state=int(state.exact_state_success),
            protected_recovery=int(safe and state.exact_state_success),effect_count=len(service.effects)))
    return out

def possible_decisions(c):
    ds=[dict(action=a,idempotency_key=None) for a in prior.ACTIONS]
    if c['block']=='supplied_key':
        ds.append(dict(action='retry_with_key',idempotency_key='other-key'))
        if c['original_key'] is not None: ds.append(dict(action='retry_with_key',idempotency_key=c['original_key']))
    return ds

def prepare():
    pd=ROOT/'protocol'/STUDY;rd=ROOT/'runs'/STUDY
    if pd.exists() or rd.exists(): raise ValueError('Refuse to replace frozen study')
    cases=build_manifest()
    paths=[Path(__file__),ROOT/'scripts/followup_studies.py',ROOT/'scripts/counterbalance_study.py']
    p=dict(schema_version='retrybench-tier-a-protocol-v1',study=STUDY,recorded_at_utc=now(),manifest_sha256=canonical_json_sha256(cases),
        models=MODELS,planned_requests=len(cases),planned_by_block=dict(Counter(c['block'] for c in cases)),cap_usd=CAP,
        rates_per_million=RATES,prices_checked_date='2026-10-10',price_sources=['https://developers.openai.com/api/docs/models/'+m.split('-2026')[0] for m in MODELS],
        collection_code_sha256={p.name:sha(p) for p in paths},source_sha256={p.name:sha(p) for p in sorted((ROOT/'src/retrybench').glob('*.py'))},
        decoding='Responses strict JSON, store=false, service_tier=default, 256 output tokens, reasoning none except Astra low. No temperature or provider seed. Shuffle seed2026101001 is only request order.',
        design='Fresh later collection: canonical six endpoints x four tasks x two labels x four cyclic orders x eight draws=1536; self-supplied-key Sol/Terra/Luna x four tasks x two labels x original key omitted/present x five draws=240, explicit weak semantics. No candidate displayed. Prior valid/changed inputs collapse. No retrospective pooling into primary estimates.',
        gold='Bare retry always inadmissible. Keyed retry is protected exactly when the original carried the same nonempty key and unchanged payload within retention. Any new key after original omitted key is unprotected. Wait/unresolved defer within one-decision horizon. Replay in three worlds; pending original remains nonterminal at observation/admission.',
        analysis='All planned response denominators, separate block/endpoint/task/label/order/key-state cells; full action and outcome vectors; missing-action/key-category bounds. Canonical six unlabeled-minus-labeled differences: Newcombe reference interval envelopes and exact conditional tests stratified by task/order, worst-case missing-completion Holm across six endpoints. Task and call reference assumptions disclosed. Key rates descriptive with CP references; no mechanistic identification from cross-window/schema comparisons. No contemporaneous representation interaction claim.',
        stopping='One serial worker per endpoint, shared locked budget including pending reservations. Stop before any request exceeding combined $5. No retries/replacements. At most four transport failures per endpoint; fifth stops endpoint. Any HTTP/auth/access/metadata error stops all workers after in-flight completions. Pending journals block resume. Unattempted/invalid/incomplete/missing cases remain unknown. No result-dependent changes.',
        reservation='Per request: (serialized payload UTF8 bytes+4096)*1.25*input rate + max_output_tokens*output rate. Reconciled to returned usage; unknown requests retain whole reserve. Default service tier, no tools or explicit cache writes.',
        independent_review='Pre-collection model-assisted design/gold review; not human validation or public preregistration.')
    pd.mkdir(parents=True);rd.mkdir(parents=True)
    write_json(pd/'protocol.json',p);write_jsonl(pd/'manifest.jsonl',cases)
    for dest,files in [('collection-code',paths),('collection-source/retrybench',list((ROOT/'src/retrybench').glob('*.py')))]:
        target=rd/dest;target.mkdir(parents=True)
        for file in files: shutil.copyfile(file,target/file.name)
    print(json.dumps({'planned':len(cases),'blocks':p['planned_by_block'],'cap_usd':CAP}))

def collect():
    private=ROOT/'runs'/STUDY/'private'
    private.mkdir(exist_ok=True)
    with (private/'collector.lock').open('a') as process_lock:
        fcntl.flock(process_lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        _collect()

def _collect():
    pd=ROOT/'protocol'/STUDY;rd=ROOT/'runs'/STUDY;p=read_json_object(pd/'protocol.json');cases=read_jsonl(pd/'manifest.jsonl');ph=canonical_json_sha256(p)
    assert canonical_json_sha256(cases)==p['manifest_sha256']
    for n,h in p['collection_code_sha256'].items(): assert sha(ROOT/'scripts'/n)==h
    for n,h in p['source_sha256'].items(): assert sha(ROOT/'src/retrybench'/n)==h
    private=rd/'private';private.mkdir(exist_ok=True)
    if (rd/'collection-summary.json').exists():
        previous=read_json_object(rd/'collection-summary.json')
        if 'reservation_violation' in previous.get('stop_reasons',{}).values(): raise ValueError('Reservation violation requires review')
    if list(private.glob('pending-*.json')): raise ValueError('Pending request cannot be replayed')
    journal=private/'requests.jsonl';records=read_jsonl(journal) if journal.exists() else []
    assert len({r['case_id'] for r in records})==len(records)
    assert all(r['protocol_sha256']==ph for r in records)
    if any(r['status']=='failed' for r in records): raise ValueError('Failure requires review')
    for m in MODELS: assert [r['case_id'] for r in records if r['requested_model']==m]==[c['case_id'] for c in cases if c['requested_model']==m][:sum(r['requested_model']==m for r in records)]
    result=subprocess.run(['/usr/bin/security','find-generic-password','-a','retrybench','-s','retrybench-openai-api-key','-w'],capture_output=True,timeout=25)
    if result.returncode or not result.stdout.strip(): raise ValueError('Keychain lookup failed')
    key=result.stdout.decode().strip();del result
    lock=threading.Lock();stop=threading.Event();pending_cost={};reasons={}
    def publish():
        byid={r['case_id']:r for r in records};ordered=[byid[c['case_id']] for c in cases if c['case_id'] in byid]
        write_jsonl(rd/'requests.jsonl',ordered)
        write_json(rd/'collection-summary.json',dict(protocol_sha256=ph,planned=len(cases),attempted=len(records),complete=sum(r['status']=='complete' for r in records),known_cost_usd=sum(r.get('cost_usd',0) for r in records),unknown_cost_upper_reserve_usd=sum(r.get('unknown_cost_upper_reserve_usd',0) for r in records),pending_reserved_usd=sum(pending_cost.values()),attempted_all=len(records)==len(cases),stop_reasons=reasons))
    def worker(m):
        cs=[c for c in cases if c['requested_model']==m];done=[r for r in records if r['requested_model']==m];transport=sum(r['status']=='transport_error' for r in done)
        if transport>4:return
        for c in cs[len(done):]:
            bound=reserve(c);pending=private/('pending-'+m+'.json')
            with lock:
                if stop.is_set(): return
                spent=sum(r.get('cost_usd',0)+r.get('unknown_cost_upper_reserve_usd',0) for r in records)+sum(pending_cost.values())
                if spent+bound>CAP: reasons[m]='combined_budget';publish();return
                pending_cost[m]=bound
                record=dict(case_id=c['case_id'],requested_model=m,protocol_sha256=ph,collected_at_utc=now())
                write_json(pending,record);publish()
            request=urllib.request.Request('https://api.openai.com/v1/responses',data=json.dumps(payload(c)).encode(),headers={'Authorization':'Bearer '+key,'Content-Type':'application/json'},method='POST')
            try:
                with urllib.request.urlopen(request,timeout=120) as response: raw=json.loads(response.read())
                with (private/('provider-'+m+'.jsonl')).open('a') as f: f.write(json.dumps({'case_id':c['case_id'],'response':raw},sort_keys=True)+'\n');f.flush();os.fsync(f.fileno())
                record.update(decode(c,raw))
            except urllib.error.HTTPError as exc: record.update(status='failed',error_type='HTTPError',http_status=exc.code,unknown_cost_upper_reserve_usd=bound)
            except (TimeoutError,socket.timeout,urllib.error.URLError) as exc: record.update(status='transport_error',error_type=type(exc).__name__,unknown_cost_upper_reserve_usd=bound)
            except Exception as exc: record.update(status='failed',error_type=type(exc).__name__,unknown_cost_upper_reserve_usd=bound)
            with lock:
                with journal.open('a') as f: f.write(json.dumps(record,sort_keys=True)+'\n');f.flush();os.fsync(f.fileno())
                records.append(record);pending.unlink();pending_cost.pop(m)
                if record.get('cost_usd',0)>bound: reasons[m]='reservation_violation';stop.set()
                if record['status']=='failed': reasons[m]='request_failure';stop.set()
                transport+=record['status']=='transport_error'
                if transport>4: reasons[m]='transport_limit'
                publish()
                if len(records)%40==0 or stop.is_set(): print(json.dumps({'attempted':len(records),'complete':sum(r['status']=='complete' for r in records),'spent_plus_unknown':round(sum(r.get('cost_usd',0)+r.get('unknown_cost_upper_reserve_usd',0) for r in records),6),'stop_reasons':reasons}),flush=True)
            if transport>4 or stop.is_set():return
    with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
        list(pool.map(worker,MODELS))
    with lock:publish()
    print('Collection stopped; summary retained.',flush=True)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('mode',choices=['prepare','collect']);args=ap.parse_args()
    try: prepare() if args.mode=='prepare' else collect()
    except Exception as exc: print('Stopped safely: '+type(exc).__name__,flush=True);raise SystemExit(1)
