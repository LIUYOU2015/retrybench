# Same-prompt retest and secondary protected recovery

Retrospective analyses, no new model calls. Retest compares new absent arms to earlier labeled supplied-key arms; payload equality checked for all 120 planned matched cases, calls not paired statistically. Six retest contrasts form an exploratory Holm family; between-block timing/alias/serving confounds remain. Three protected-recovery contrasts form a separate exploratory Holm family; protected recovery was a predeclared secondary outcome, but this test family was selected after seeing outcomes. Neither replaces or changes the six prespecified primary error tests.

## Absent-candidate retest: new minus earlier labeled

| Endpoint / original | Earlier errors / planned | New errors / planned | Difference bounds (pp) | Nominal 95% envelope (pp) | Worst-case Holm6 p |
|---|---:|---:|---|---|---:|
| gpt-5.6-sol/omitted | 0/20 | 0/20 +1 missing | [+0.00, +5.00] | [-16.11, +23.61] | 1 |
| gpt-5.6-sol/present | 0/20 | 0/20 | [+0.00, +0.00] | [-16.11, +16.11] | 1 |
| gpt-5.6-terra/omitted | 0/20 | 0/20 | [+0.00, +0.00] | [-16.11, +16.11] | 1 |
| gpt-5.6-terra/present | 0/20 | 0/20 | [+0.00, +0.00] | [-16.11, +16.11] | 1 |
| gpt-5.6-luna/omitted | 3/20 | 8/20 | [+25.00, +25.00] | [-2.77, +48.47] | 0.8862434 |
| gpt-5.6-luna/present | 0/20 | 0/20 | [+0.00, +0.00] | [-16.11, +16.11] | 1 |

## Original-present protected recovery: displayed minus absent

| Endpoint | Absent protected / planned | Displayed protected / planned | Difference bounds (pp) | Nominal 95% envelope (pp) | Worst-case Holm3 p |
|---|---:|---:|---|---|---:|
| gpt-5.6-sol | 20/20 | 19/20 +1 missing | [-5.00, +0.00] | [-23.61, +16.11] | 1 |
| gpt-5.6-terra | 20/20 | 20/20 | [+0.00, +0.00] | [-16.11, +16.11] | 1 |
| gpt-5.6-luna | 18/20 | 0/20 | [-90.00, -90.00] | [-97.21, -64.24] | 3.124413e-08 |
