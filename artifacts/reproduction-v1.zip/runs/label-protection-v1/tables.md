### Response decisions

| Endpoint | Valid same-key retry | Unsupported retry: original omitted key | Unsupported retry: changed key |
| --- | --- | --- | --- |
| gpt-5.6-sol | 80/80 | 0/80 | 1/80 |
| gpt-5.6-terra | 80/80 | 0/80 | 55/80 |
| gpt-5.6-luna | 78/80 | 49/80 | 60/80 |

### Realized outcomes

| Endpoint | Key condition | Outcomes | FRP | Duplicates | Omissions | Unresolved | Ledger correct | Resolved exact |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| gpt-5.6-sol | none | 240 | 0 | 0 | 80 | 240 | 160 | 0 |
| gpt-5.6-sol | valid | 240 | 0 | 0 | 0 | 0 | 240 | 240 |
| gpt-5.6-sol | changed | 240 | 3 | 2 | 79 | 237 | 159 | 1 |
| gpt-5.6-terra | none | 240 | 0 | 0 | 80 | 240 | 160 | 0 |
| gpt-5.6-terra | valid | 240 | 0 | 0 | 0 | 0 | 240 | 240 |
| gpt-5.6-terra | changed | 240 | 165 | 110 | 25 | 75 | 105 | 55 |
| gpt-5.6-luna | none | 240 | 147 | 98 | 31 | 93 | 111 | 49 |
| gpt-5.6-luna | valid | 240 | 0 | 0 | 2 | 6 | 238 | 234 |
| gpt-5.6-luna | changed | 240 | 180 | 120 | 20 | 60 | 100 | 60 |

# Full response and outcome cells

Each cell has 20 responses and 60 correlated outcomes. Actions are retry / retry_with_key / stop / wait / unresolved.

| Condition | Actions | FRP | Duplicates | Omissions | Unresolved | Ledger correct | Resolved exact |
| --- | --- | --- | --- | --- | --- | --- | --- |
| gpt-5.6-luna/labeled/stated/changed | 0/11/0/0/9 | 33 | 22 | 9 | 27 | 29 | 11 |
| gpt-5.6-luna/labeled/stated/none | 0/2/0/0/18 | 6 | 4 | 18 | 54 | 38 | 2 |
| gpt-5.6-luna/labeled/stated/valid | 0/20/0/0/0 | 0 | 0 | 0 | 0 | 60 | 60 |
| gpt-5.6-luna/labeled/unstated/changed | 0/17/0/0/3 | 51 | 34 | 3 | 9 | 23 | 17 |
| gpt-5.6-luna/labeled/unstated/none | 0/20/0/0/0 | 60 | 40 | 0 | 0 | 20 | 20 |
| gpt-5.6-luna/labeled/unstated/valid | 0/20/0/0/0 | 0 | 0 | 0 | 0 | 60 | 60 |
| gpt-5.6-luna/unlabeled/stated/changed | 0/14/0/0/6 | 42 | 28 | 6 | 18 | 26 | 14 |
| gpt-5.6-luna/unlabeled/stated/none | 0/7/0/0/13 | 21 | 14 | 13 | 39 | 33 | 7 |
| gpt-5.6-luna/unlabeled/stated/valid | 0/20/0/0/0 | 0 | 0 | 0 | 0 | 60 | 60 |
| gpt-5.6-luna/unlabeled/unstated/changed | 0/18/0/0/2 | 54 | 36 | 2 | 6 | 22 | 18 |
| gpt-5.6-luna/unlabeled/unstated/none | 0/20/0/0/0 | 60 | 40 | 0 | 0 | 20 | 20 |
| gpt-5.6-luna/unlabeled/unstated/valid | 0/18/0/0/2 | 0 | 0 | 2 | 6 | 58 | 54 |
| gpt-5.6-sol/labeled/stated/changed | 0/0/0/0/20 | 0 | 0 | 20 | 60 | 40 | 0 |
| gpt-5.6-sol/labeled/stated/none | 0/0/0/0/20 | 0 | 0 | 20 | 60 | 40 | 0 |
| gpt-5.6-sol/labeled/stated/valid | 0/20/0/0/0 | 0 | 0 | 0 | 0 | 60 | 60 |
| gpt-5.6-sol/labeled/unstated/changed | 0/0/0/0/20 | 0 | 0 | 20 | 60 | 40 | 0 |
| gpt-5.6-sol/labeled/unstated/none | 0/0/0/0/20 | 0 | 0 | 20 | 60 | 40 | 0 |
| gpt-5.6-sol/labeled/unstated/valid | 0/20/0/0/0 | 0 | 0 | 0 | 0 | 60 | 60 |
| gpt-5.6-sol/unlabeled/stated/changed | 0/0/0/0/20 | 0 | 0 | 20 | 60 | 40 | 0 |
| gpt-5.6-sol/unlabeled/stated/none | 0/0/0/0/20 | 0 | 0 | 20 | 60 | 40 | 0 |
| gpt-5.6-sol/unlabeled/stated/valid | 0/20/0/0/0 | 0 | 0 | 0 | 0 | 60 | 60 |
| gpt-5.6-sol/unlabeled/unstated/changed | 1/0/0/0/19 | 3 | 2 | 19 | 57 | 39 | 1 |
| gpt-5.6-sol/unlabeled/unstated/none | 0/0/0/0/20 | 0 | 0 | 20 | 60 | 40 | 0 |
| gpt-5.6-sol/unlabeled/unstated/valid | 0/20/0/0/0 | 0 | 0 | 0 | 0 | 60 | 60 |
| gpt-5.6-terra/labeled/stated/changed | 0/11/0/0/9 | 33 | 22 | 9 | 27 | 29 | 11 |
| gpt-5.6-terra/labeled/stated/none | 0/0/0/0/20 | 0 | 0 | 20 | 60 | 40 | 0 |
| gpt-5.6-terra/labeled/stated/valid | 0/20/0/0/0 | 0 | 0 | 0 | 0 | 60 | 60 |
| gpt-5.6-terra/labeled/unstated/changed | 0/14/0/0/6 | 42 | 28 | 6 | 18 | 26 | 14 |
| gpt-5.6-terra/labeled/unstated/none | 0/0/0/0/20 | 0 | 0 | 20 | 60 | 40 | 0 |
| gpt-5.6-terra/labeled/unstated/valid | 0/20/0/0/0 | 0 | 0 | 0 | 0 | 60 | 60 |
| gpt-5.6-terra/unlabeled/stated/changed | 0/15/0/0/5 | 45 | 30 | 5 | 15 | 25 | 15 |
| gpt-5.6-terra/unlabeled/stated/none | 0/0/0/0/20 | 0 | 0 | 20 | 60 | 40 | 0 |
| gpt-5.6-terra/unlabeled/stated/valid | 0/20/0/0/0 | 0 | 0 | 0 | 0 | 60 | 60 |
| gpt-5.6-terra/unlabeled/unstated/changed | 0/15/0/0/5 | 45 | 30 | 5 | 15 | 25 | 15 |
| gpt-5.6-terra/unlabeled/unstated/none | 0/0/0/0/20 | 0 | 0 | 20 | 60 | 40 | 0 |
| gpt-5.6-terra/unlabeled/unstated/valid | 0/20/0/0/0 | 0 | 0 | 0 | 0 | 60 | 60 |

# All four-task effects

All follow-up responses are observed. Effects are descriptive fixed-task differences, not population estimates.

| Contrast | CI | Issue | Release | Review | Mean |
| --- | --- | --- | --- | --- | --- |
| gpt-5.6-luna/label_removal | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| gpt-5.6-luna/labeled/semantics_added | -1.00 | -1.00 | -1.00 | -0.60 | -0.90 |
| gpt-5.6-luna/labeled/stated/valid_minus_changed_keyed_selection | 1.00 | 0.40 | 0.20 | 0.20 | 0.45 |
| gpt-5.6-luna/labeled/stated/valid_minus_changed_progress | 1.00 | 1.00 | 1.00 | 1.00 | 1.00 |
| gpt-5.6-luna/labeled/unstated/valid_minus_changed_keyed_selection | 0.00 | 0.00 | 0.20 | 0.40 | 0.15 |
| gpt-5.6-luna/labeled/unstated/valid_minus_changed_progress | 1.00 | 1.00 | 1.00 | 1.00 | 1.00 |
| gpt-5.6-luna/unlabeled/semantics_added | -1.00 | -0.20 | -1.00 | -0.40 | -0.65 |
| gpt-5.6-luna/unlabeled/stated/valid_minus_changed_keyed_selection | 0.00 | 0.40 | 0.20 | 0.60 | 0.30 |
| gpt-5.6-luna/unlabeled/stated/valid_minus_changed_progress | 1.00 | 1.00 | 1.00 | 1.00 | 1.00 |
| gpt-5.6-luna/unlabeled/unstated/valid_minus_changed_keyed_selection | 0.20 | -0.40 | 0.00 | 0.20 | -0.00 |
| gpt-5.6-luna/unlabeled/unstated/valid_minus_changed_progress | 1.00 | 0.60 | 1.00 | 1.00 | 0.90 |
| gpt-5.6-sol/label_removal | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| gpt-5.6-sol/labeled/semantics_added | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| gpt-5.6-sol/labeled/stated/valid_minus_changed_keyed_selection | 1.00 | 1.00 | 1.00 | 1.00 | 1.00 |
| gpt-5.6-sol/labeled/stated/valid_minus_changed_progress | 1.00 | 1.00 | 1.00 | 1.00 | 1.00 |
| gpt-5.6-sol/labeled/unstated/valid_minus_changed_keyed_selection | 1.00 | 1.00 | 1.00 | 1.00 | 1.00 |
| gpt-5.6-sol/labeled/unstated/valid_minus_changed_progress | 1.00 | 1.00 | 1.00 | 1.00 | 1.00 |
| gpt-5.6-sol/unlabeled/semantics_added | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| gpt-5.6-sol/unlabeled/stated/valid_minus_changed_keyed_selection | 1.00 | 1.00 | 1.00 | 1.00 | 1.00 |
| gpt-5.6-sol/unlabeled/stated/valid_minus_changed_progress | 1.00 | 1.00 | 1.00 | 1.00 | 1.00 |
| gpt-5.6-sol/unlabeled/unstated/valid_minus_changed_keyed_selection | 1.00 | 1.00 | 1.00 | 1.00 | 1.00 |
| gpt-5.6-sol/unlabeled/unstated/valid_minus_changed_progress | 1.00 | 1.00 | 1.00 | 1.00 | 1.00 |
| gpt-5.6-terra/label_removal | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| gpt-5.6-terra/labeled/semantics_added | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| gpt-5.6-terra/labeled/stated/valid_minus_changed_keyed_selection | 0.00 | 0.80 | 1.00 | 0.00 | 0.45 |
| gpt-5.6-terra/labeled/stated/valid_minus_changed_progress | 1.00 | 1.00 | 1.00 | 1.00 | 1.00 |
| gpt-5.6-terra/labeled/unstated/valid_minus_changed_keyed_selection | 0.60 | 0.00 | 0.60 | 0.00 | 0.30 |
| gpt-5.6-terra/labeled/unstated/valid_minus_changed_progress | 1.00 | 1.00 | 1.00 | 1.00 | 1.00 |
| gpt-5.6-terra/unlabeled/semantics_added | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| gpt-5.6-terra/unlabeled/stated/valid_minus_changed_keyed_selection | 0.00 | 0.40 | 0.60 | 0.00 | 0.25 |
| gpt-5.6-terra/unlabeled/stated/valid_minus_changed_progress | 1.00 | 1.00 | 1.00 | 1.00 | 1.00 |
| gpt-5.6-terra/unlabeled/unstated/valid_minus_changed_keyed_selection | 0.20 | 0.00 | 0.80 | 0.00 | 0.25 |
| gpt-5.6-terra/unlabeled/unstated/valid_minus_changed_progress | 1.00 | 1.00 | 1.00 | 1.00 | 1.00 |
