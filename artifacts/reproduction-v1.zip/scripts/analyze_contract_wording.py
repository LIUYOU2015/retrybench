"""Complete-block reporting for the frozen five-arm semantics control.

Family mean contrasts are specified in the protocol. Bootstrap/sign summaries
are additional descriptive diagnostics, not preregistered population inference.
This script refuses incomplete collection and never calls a model.
"""
from __future__ import annotations

import argparse
import hashlib
from collections import Counter
from pathlib import Path

from retrybench.review_diagnostics import family_statistics
from retrybench.serialization import canonical_json_sha256, read_json_object, read_jsonl, write_json
from retrybench.tmlr_analysis import outcome_summary


def analyze(protocol_dir, run_dir):
    protocol = read_json_object(protocol_dir / 'protocol.json')
    manifest = read_jsonl(protocol_dir / 'manifest.jsonl')
    report = read_json_object(run_dir / 'analysis.json')
    requests = read_jsonl(run_dir / 'requests.jsonl')
    rows = read_jsonl(run_dir / 'outcomes.jsonl')
    provenance = read_json_object(run_dir / 'collection-provenance.json')
    if not report.get('complete') or len(requests) != len(manifest):
        raise ValueError('complete frozen collection required')
    ids = [r['case_id'] for r in requests]
    if len(set(ids)) != len(ids) or set(ids) != {c['case_id'] for c in manifest}:
        raise ValueError('request IDs differ from frozen manifest')
    if canonical_json_sha256(manifest) != protocol['manifest_sha256']:
        raise ValueError('manifest hash mismatch')
    if canonical_json_sha256(protocol) != provenance['protocol_sha256']:
        raise ValueError('protocol hash mismatch')
    for request in requests:
        if request['provider_status'] != 'completed' or request['collection_provenance_sha256'] != canonical_json_sha256(provenance):
            raise ValueError('request provenance mismatch')
    expected = {(c['case_id'], s) for c in manifest for s in c['schedules']}
    actual = [(r['response_group_id'], r['schedule']) for r in rows]
    if len(set(actual)) != len(actual) or set(actual) != expected:
        raise ValueError('scored outcomes differ from frozen schedules')
    decisions = {r['case_id']: r['decision'] for r in requests}
    if any(r['decision'] != decisions[r['response_group_id']] for r in rows):
        raise ValueError('scored decisions differ from requests')
    arms = {}
    for arm in sorted({c['prompt_mode'] for c in manifest}):
        cases = [c for c in manifest if c['prompt_mode'] == arm]
        selected = [r for r in rows if r['prompt_mode'] == arm]
        common = [r for r in selected if r['schedule'] != 'fail_before_execution']
        states = {}
        for state in sorted({c['observed_state'] for c in cases}):
            cell = [c for c in cases if c['observed_state'] == state]
            states[state] = {
                'responses': len(cell),
                'actions': dict(sorted(Counter(decisions[c['case_id']]['action'] for c in cell).items())),
                'outcomes': outcome_summary([r for r in selected if r['observed_state'] == state]),
            }
        terminal = [c for c in cases if c['evidence'] == 'authoritative' and c['observed_state'] == 'not_executed']
        arms[arm] = {
            'responses': len(cases),
            'response_actions': dict(sorted(Counter(decisions[c['case_id']]['action'] for c in cases).items())),
            'state_responses': states,
            'outcomes': outcome_summary(selected),
            'common_forbidden': outcome_summary(common),
            'common_forbidden_retry_rate': sum(r['false_retry_permission'] for r in common) / len(common),
            'authoritative_terminal_correct_retries': sum(decisions[c['case_id']]['action'] == 'retry' for c in terminal),
            'authoritative_terminal_responses': len(terminal),
        }
    contrasts = {}
    for name, contrast in report['arm_contrasts'].items():
        left, right = name.split('_minus_')
        families = []
        for family in sorted({r['family_id'] for r in rows}):
            rates = {}
            for arm in (left, right):
                chosen = [r for r in rows if r['family_id'] == family and r['prompt_mode'] == arm and r['schedule'] != 'fail_before_execution']
                rates[arm] = sum(r['false_retry_permission'] for r in chosen) / len(chosen)
            families.append({'family_id': family, 'left': rates[left], 'right': rates[right], 'difference': rates[left] - rates[right]})
        if families != contrast['family_effects']:
            raise ValueError('independent contrast recomputation differs')
        contrasts[name] = {'family_effects': families, 'descriptive_family_statistics': family_statistics([r['difference'] for r in families])}
    dates = sorted(r['collected_at_utc'] for r in requests)
    return {
        'schema_version': 'retrybench-contract-wording-report-v1',
        'complete': True,
        'scope': 'Fixed-input five-arm block; none reasoning; eight reused purposive families; one recovery decision.',
        'inference': 'Protocol-specified family mean contrasts; additional descriptive whole-family bootstrap/sign diagnostics. No task-population coverage or eventual liveness claim.',
        'manifest_sha256': protocol['manifest_sha256'],
        'source_hashes': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in (run_dir / 'requests.jsonl', run_dir / 'outcomes.jsonl', run_dir / 'analysis.json', run_dir / 'collection-provenance.json')},
        'requested_models': sorted({c['requested_model'] for c in manifest}),
        'returned_models': sorted({r['decision']['model'] for r in requests}),
        'first_request_utc': dates[0], 'last_request_utc': dates[-1],
        'fresh_calls': len(requests), 'scored_outcomes': len(rows),
        'estimated_cost_usd': sum(r['decision']['cost_usd'] for r in requests),
        'token_usage': {key: sum(r['decision']['usage'][key] for r in requests) for key in ('input_tokens', 'cached_input_tokens', 'output_tokens', 'reasoning_tokens')},
        'arms': arms, 'contrasts': contrasts,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--protocol-dir', type=Path, default=Path('protocol/contract-wording-v2'))
    parser.add_argument('--run-dir', type=Path, default=Path('runs/contract-wording-v2'))
    args = parser.parse_args()
    report = analyze(args.protocol_dir, args.run_dir)
    write_json(args.run_dir / 'report.json', report)
    print('Wrote complete-block report with %d model responses.' % report['fresh_calls'])


if __name__ == '__main__':
    main()
