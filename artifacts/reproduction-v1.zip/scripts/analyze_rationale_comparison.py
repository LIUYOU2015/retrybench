"""Offline descriptive comparison of every returned Sol coded explanation.

These post-hoc, unblinded lexical indicators are not semantic or human coding.
Every match retains its exact text and character offsets for inspection.
Reproduce with PYTHONPATH=src python scripts/analyze_rationale_comparison.py.
"""
from __future__ import annotations

import hashlib
import re
from collections import Counter
from pathlib import Path

from retrybench.serialization import read_json_object, read_jsonl, write_json, write_jsonl
from contrast_inference import mover

ROOT = Path(__file__).resolve().parents[1]
STUDY = "historical-counterbalance-v1"
MODEL = "gpt-5.6-sol"
RUBRIC = {
    "weak_word": {
        "description": "Literal word weak; not a semantic judgment of contract use.",
        "pattern": r"\bweak\b",
    },
    "contract_word": {
        "description": "Literal word contract; not proof it caused the decision.",
        "pattern": r"\bcontract\b",
    },
    "label_word": {
        "description": "Literal label, labels, labeled or labelled.",
        "pattern": r"\blabel(?:s|ed|led)?\b",
    },
    "stale_word": {
        "description": "Literal stale or staleness; other visibility language is separate.",
        "pattern": r"\bstale(?:ness)?\b",
    },
    "authority_word": {
        "description": "Literal authoritative or authority, regardless of negation or uncertainty.",
        "pattern": r"\b(?:authoritative|authority)\b",
    },
    "non_authoritative_phrase": {
        "description": "Literal non-authoritative, non authoritative, or not authoritative.",
        "pattern": r"\b(?:non[- ]|not\s+)authoritative\b",
    },
    "duplicate_or_twice": {
        "description": "Duplicate/duplicated/duplicates/duplicating/duplication, or twice.",
        "pattern": r"\b(?:duplicat(?:e[sd]?|ing|ion)|twice)\b",
    },
    "uncertainty_word": {
        "description": "Uncertain/uncertainty, unknown, ambiguous, or indeterminate.",
        "pattern": r"\b(?:uncertain(?:ty)?|unknown|ambiguous|indeterminate)\b",
    },
    "insufficiency_phrase": {
        "description": "Specified phrases denying guarantee/proof/confirmation or expressing insufficiency; no automated referent or polarity analysis beyond the pattern.",
        "pattern": r"\b(?:does not|do not|cannot)\s+(?:(?:reliably|safely)\s+)?(?:guarantee|prove|establish|confirm)\b|\b(?:insufficient|not strong enough|not conclusive|not guaranteed)\b",
    },
    "future_or_delayed_visibility": {
        "description": "Specified explicit stale/pending/delay/propagation or later-visibility phrases; not a complete semantic taxonomy.",
        "pattern": r"\b(?:stale(?:ness)?|pending|delayed|in[- ]flight|propagating|propagation)\b|\b(?:appear later|become visible|becoming visible|not yet visible|will not complete)\b",
    },
    "visibility_vocabulary": {
        "description": "Visible/visibility/observable/unobservable/unobserved/detectable vocabulary. This can occur in a retry justification and does not by itself acknowledge uncertainty.",
        "pattern": r"\b(?:visible|visibility|observable|unobservable|unobserved|detectable)\b",
    },
}
FLAGS = re.IGNORECASE


def lexical_matches(text: str) -> dict:
    return {
        name: [{"start": match.start(), "end": match.end(), "text": match.group()}
               for match in re.finditer(rule["pattern"], text, FLAGS)]
        for name, rule in RUBRIC.items()
    }


def outcome_group(action: str) -> str:
    if action == "retry":
        return "retry"
    if action in ("wait", "unresolved"):
        return "deferral"
    if action == "stop":
        return "stop"
    raise ValueError("Unexpected decoded action")


def load_explanations() -> tuple[list[dict], dict]:
    manifest_path = ROOT / "protocol" / STUDY / "manifest.jsonl"
    requests_path = ROOT / "runs" / STUDY / "shards" / MODEL / "requests.jsonl"
    report_path = ROOT / "runs" / STUDY / "report.json"
    manifest = read_jsonl(manifest_path)
    requests = read_jsonl(requests_path)
    endpoint_cases = [case for case in manifest if case["requested_model"] == MODEL]
    if [row["case_id"] for row in requests] != [case["case_id"] for case in endpoint_cases]:
        raise ValueError("Requests must retain the full frozen endpoint order")
    if len({row["case_id"] for row in requests}) != len(requests):
        raise ValueError("Duplicate request case ID")
    source_report = read_json_object(report_path)
    by_id = {row["case_id"]: row for row in requests}
    explanations = []
    for case in endpoint_cases:
        if case["representation"] != "coded":
            continue
        request = by_id[case["case_id"]]
        row = {key: case[key] for key in (
            "case_id", "requested_model", "task_id", "label", "representation",
            "mapping_rotation", "order_rotation", "repetition", "transcript_sha256",
            "token_to_action",
        )}
        row.update(status=request["status"], collected_at_utc=request["collected_at_utc"],
                   action=None, selected_token=None, group=None, rationale=None,
                   lexical_matches=None)
        if request["status"] == "complete":
            decision = request["decision"]
            if case["token_to_action"][request["selected_token"]] != decision["action"]:
                raise ValueError("Action decoding mismatch")
            if not isinstance(decision["rationale"], str):
                raise ValueError("Returned rationale must be exact text")
            row.update(action=decision["action"], selected_token=request["selected_token"],
                       group=case["label"] + "/" + outcome_group(decision["action"]),
                       rationale=decision["rationale"],
                       lexical_matches=lexical_matches(decision["rationale"]))
        explanations.append(row)
    for label in ("labeled", "unlabeled"):
        selected = [row for row in explanations if row["label"] == label]
        expected = source_report["groups"][MODEL + "/coded/" + label]
        if len(selected) != expected["planned_responses"] or sum(row["status"] == "complete" for row in selected) != expected["observed_responses"]:
            raise ValueError("Counts disagree with validated collection report")
    sources = {
        str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest()
        for path in (manifest_path, requests_path, report_path, Path(__file__).resolve(),
                     ROOT / "scripts" / "contrast_inference.py")
    }
    return explanations, sources


def summarize(rows: list[dict], outcome_selected: bool = False) -> dict:
    returned = [row for row in rows if row["status"] == "complete"]
    missing = len(rows) - len(returned)
    return {
        "included_cases": len(rows),
        "planned_cases_in_group": None if outcome_selected else len(rows),
        "denominator_scope": (
            "Observed-action subset; missing responses cannot be assigned to an action group."
            if outcome_selected else "All frozen cases in the declared label/task selection."
        ),
        "returned_explanations": len(returned),
        "missing_explanations": missing,
        "actions": dict(sorted(Counter(row["action"] for row in returned).items())),
        "task_counts": dict(sorted(Counter(row["task_id"] for row in returned).items())),
        "indicators": {
            name: {
                "returned_explanations_with_match": sum(bool(row["lexical_matches"][name]) for row in returned),
                "returned_denominator": len(returned),
                "presence_count_bounds_over_included_cases": [
                    sum(bool(row["lexical_matches"][name]) for row in returned),
                    sum(bool(row["lexical_matches"][name]) for row in returned) + missing,
                ],
            } for name in RUBRIC
        },
    }


def representative_quotes(rows: list[dict]) -> list[dict]:
    """Illustrative choices are deterministic and disclosed, never prevalence estimates."""
    selectors = [
        ("First labeled deferral in frozen request order", lambda r: r["group"] == "labeled/deferral"),
        ("First unlabeled deferral in frozen request order", lambda r: r["group"] == "unlabeled/deferral"),
        ("First unlabeled retry in frozen request order", lambda r: r["group"] == "unlabeled/retry"),
        ("First unlabeled retry containing an uncertainty word", lambda r: r["group"] == "unlabeled/retry" and r["lexical_matches"]["uncertainty_word"]),
        ("First unlabeled deferral containing an authority word", lambda r: r["group"] == "unlabeled/deferral" and r["lexical_matches"]["authority_word"]),
    ]
    quotes = []
    for description, predicate in selectors:
        candidates = [row for row in rows if row["status"] == "complete" and predicate(row)]
        if candidates:
            chosen = candidates[0]
            quotes.append({"selection_rule": description, **{
                key: chosen[key] for key in ("case_id", "group", "task_id", "mapping_rotation", "order_rotation", "rationale")
            }})
    return quotes


def analyze() -> tuple[dict, list[dict]]:
    rows, sources = load_explanations()
    returned = [row for row in rows if row["status"] == "complete"]
    labels = {label: summarize([row for row in rows if row["label"] == label])
              for label in ("labeled", "unlabeled")}
    groups = {group: summarize([row for row in returned if row["group"] == group], outcome_selected=True)
              for group in sorted({row["group"] for row in returned})}
    contrasts = {}
    for name, arms in (
        ("all_returned", [labels[label] for label in ("unlabeled", "labeled")]),
        ("returned_deferrals", [groups[label + "/deferral"] for label in ("unlabeled", "labeled")]),
    ):
        counts = [arm["indicators"]["duplicate_or_twice"] for arm in arms]
        terms = [(coefficient, count["returned_explanations_with_match"], count["returned_denominator"])
                 for coefficient, count in zip((1, -1), counts)]
        estimate, interval = mover(terms)
        contrasts[name] = {
            "direction": "unlabeled minus labeled",
            "estimate": estimate, "nominal_95_newcombe_interval": interval,
            "unlabeled_matches_and_denominator": list(terms[0][1:]),
            "labeled_matches_and_denominator": list(terms[1][1:]),
        }
    task_groups = {}
    for label in labels:
        for task in sorted({row["task_id"] for row in rows}):
            task_groups[label + "/" + task] = summarize([
                row for row in rows if row["label"] == label and row["task_id"] == task
            ])
    report = {
        "schema_version": "retrybench-rationale-comparison-v1",
        "analysis_status": "Post-hoc, unblinded, AI-assisted descriptive reading; rules fixed in this version after reading all 255 returned explanations. No new model calls or human validation.",
        "scope": "All planned Sol coded historical-counterbalance cases, both label arms. The duplicate-vocabulary comparison leads with returned deferrals to expose action composition; full-arm and retry counts remain available. Conditioning on observed action is descriptive, not a matched causal comparison.",
        "planned_cases": len(rows), "returned_explanations": len(returned),
        "missing_cases": [{key: row[key] for key in (
            "case_id", "status", "label", "task_id", "mapping_rotation", "order_rotation", "repetition"
        )} for row in rows if row["status"] != "complete"],
        "rubric": RUBRIC,
        "matching": "Python re.IGNORECASE on the exact unmodified rationale. Indicators are nonexclusive Boolean presence per explanation, not occurrence frequencies. Matches store zero-based Python character offsets with exclusive end. Missing explanations have null indicators, never all-false indicators.",
        "by_label": labels, "by_observed_action_group": groups,
        "by_label_and_task": task_groups,
        "duplicate_vocabulary_contrasts": contrasts,
        "contrast_scope": "Post-hoc observed-explanation-only Newcombe reference intervals under independent binomial-call assumptions. Not adjusted for task/format dependence or multiplicity, and not task-population intervals. The missing labeled response is excluded, not imputed. Conditioning on deferral selects on a post-treatment action; these intervals do not establish equivalence or causal mediation.",
        "representative_quotes": representative_quotes(rows),
        "reading": [
            "Duplicate vocabulary occurs in 117/127 labeled deferrals and 97/101 unlabeled deferrals, but in 0/27 unlabeled retries. The lower full-arm unlabeled frequency reflects the observed retry/deferral composition; the conditional reference interval does not resolve a difference among returned deferrals or establish equivalence.",
            "The supplied weak label is repeated in labeled explanations. Literal repetition is retained for audit only and is not evidence for a reasoning mechanism.",
            "The unlabeled retry subset generally justifies retry from noncreation or absence of an observable effect. One retry explanation explicitly acknowledges uncertainty before recommending retry; the texts should not all be described as denying uncertainty.",
            "No returned explanation explicitly discusses deletion or absence of the evidence-contract label. The absence of a literal label word is only lexical evidence; the descriptive reading is not a test of hidden reasoning or a causal mechanism.",
        ],
        "limitations": [
            "Rules were developed after seeing the text and actions, not preregistered or blinded; no significance tests or confirmatory coding claim are made.",
            "The 27-retry versus 127-deferral comparison selects on action and has different task composition. The full 128-returned unlabeled arm and per-task summaries prevent that subset from standing in for all unlabeled responses; they do not remove the selection issue.",
            "Both arms reuse four purposive tasks and many related prompt formats. Rationales may be templated or post-hoc justifications and do not identify internal computation.",
            "Literal matches do not resolve negation, uncertainty, referents, or causal reliance. A visibility word can justify retry or deferral; an authoritative word need not assert authority.",
            "Zero keyword matches do not establish absence of the corresponding concept. The missing labeled response supplies no explanation and is retained as unknown.",
            "Quotes illustrate declared selection rules and are not an additional independent sample. This comparison is separate from the earlier 104-explanation dual-coder study.",
        ],
        "source_sha256": sources,
    }
    return report, rows


def render(report: dict) -> str:
    columns = [("All labeled", report["by_label"]["labeled"]),
               ("All unlabeled", report["by_label"]["unlabeled"])]
    columns += [(name, row) for name, row in report["by_observed_action_group"].items()]
    text = ["# Comparative descriptive reading of Sol coded explanations", "",
            report["analysis_status"], "", report["scope"], "",
            f"Returned explanations: {report['returned_explanations']}/{report['planned_cases']}. "
            "The single missing explanation remains unknown. Full texts and exact matched spans are in explanations.jsonl.", "",
            "## Duplicate vocabulary and action composition", "",
            "| Returned subset | Unlabeled | Labeled | U minus L (pp) | Nominal 95% Newcombe interval (pp) |",
            "|---|---:|---:|---:|---:|"]
    for name in ("returned_deferrals", "all_returned"):
        contrast = report["duplicate_vocabulary_contrasts"][name]
        u, l = [contrast[label + "_matches_and_denominator"] for label in ("unlabeled", "labeled")]
        lo, hi = contrast["nominal_95_newcombe_interval"]
        text.append(f"| {name} | {u[0]}/{u[1]} | {l[0]}/{l[1]} | {100*contrast['estimate']:+.1f} | [{100*lo:+.1f}, {100*hi:+.1f}] |")
    text += ["", report["contrast_scope"], "",
            "## Literal indicator counts (audit detail)", "",
            "Cells count returned explanations with at least one match. Outcome groups overlap their full-arm totals; they are not independent samples.", "",
            "| Indicator | " + " | ".join(f"{name} (n={row['returned_explanations']})" for name, row in columns) + " |",
            "|---|" + "---:|" * len(columns)]
    for name in RUBRIC:
        text.append("| " + name + " | " + " | ".join(str(row["indicators"][name]["returned_explanations_with_match"]) for _, row in columns) + " |")
    text += ["", "The labeled arm has one additional unknown explanation; each full-arm indicator's planned presence count can therefore increase by at most one. Exact bounds and per-task counts are in report.json.", "", "## Descriptive reading", ""]
    text += ["- " + line for line in report["reading"]]
    text += ["", "## Returned task composition", "",
             "The outcome-selected subsets have different task composition; they are not matched causal comparisons.", "",
             "| Group | CI | Issue | Release | Review |", "|---|---:|---:|---:|---:|"]
    for name, row in columns:
        text.append("| " + name + " | " + " | ".join(str(row["task_counts"].get(task, 0)) for task in ("ci-001", "issue-001", "release-001", "review-001")) + " |")
    text += ["", "## Exact illustrative quotations", ""]
    for quote in report["representative_quotes"]:
        text += [f"**{quote['selection_rule']}** — `{quote['case_id']}`, {quote['task_id']}, mapping {quote['mapping_rotation']}, order {quote['order_rotation']}.", "", "> " + quote["rationale"], ""]
    text += ["## Rubric", "", report["matching"], ""]
    for name, rule in RUBRIC.items():
        text += [f"- **{name}:** {rule['description']} Pattern: `{rule['pattern']}`"]
    text += ["", "## Limits", ""]
    text += ["- " + line for line in report["limitations"]]
    text += ["", "## Reproduction", "", "```sh", "PYTHONPATH=src python scripts/analyze_rationale_comparison.py", "```", ""]
    return "\n".join(text)


def main() -> None:
    report, rows = analyze()
    directory = ROOT / "runs/rationale-comparison-v1"
    directory.mkdir(parents=True, exist_ok=True)
    write_json(directory / "report.json", report)
    write_jsonl(directory / "explanations.jsonl", rows)
    (directory / "tables.md").write_text(render(report))
    print(f"Compared {report['returned_explanations']} returned explanations; retained {len(report['missing_cases'])} missing case.")


if __name__ == "__main__":
    main()
