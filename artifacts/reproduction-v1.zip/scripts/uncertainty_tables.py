"""Render response-count reference intervals and all key-condition cells."""
from pathlib import Path
from retrybench.serialization import read_json_object
from followup_tables import table

def count(cell):
    lo,hi=cell['cp95_reference_envelope'];k=cell['events_observed'];n=cell['planned_responses'];m=cell['missing_responses']
    return f'{k}/{n}'+(f' (+{m} missing)' if m else '')+f' [{100*lo:.2f}, {100*hi:.2f}]'

def render():
    r=read_json_object(Path('runs/response-uncertainty-v1/report.json'))
    keys=r['studies']['label-protection-v1'];bridge=r['studies']['historical-bridge-v1'];models=['gpt-5.6-sol','gpt-5.6-terra','gpt-5.6-luna']
    heading='Counts are distinct responses. Brackets give nominal two-sided95% Clopper–Pearson reference limits in percent, assuming independent common-probability binomial calls. Pooled heterogeneous conditions do not establish these assumptions. These are not task-population or episode-safety limits.\n\n'
    pooled=table(['Endpoint','Valid same-key retry','Unsupported: original omitted key','Unsupported: changed key'],[[m]+[count(keys[m+'/all_labels_semantics/'+p]) for p in ('valid','none','changed')] for m in models])
    cells=table(['Endpoint','Label','Lookup semantics','Valid same-key','Omitted original key','Changed key'],[[m,l,se]+[str(keys[f'{m}/{l}/{se}/{p}']['events_observed'])+'/20' for p in ('valid','none','changed')] for m in models for l in ('labeled','unlabeled') for se in ('unstated','stated')])
    rows=[[m,effort,count(bridge[m+'/'+effort+'/weak/not_found'])] for m,effort in [('gpt-5.4-mini-2026-03-17','none'),('gpt-5.4-2026-03-05','none'),('gpt-5.6-sol','none'),('gpt-5.6-sol','low')]]
    report='# Response-level uncertainty tables\n\n'+heading+'## Key-condition headline counts\n\n'+pooled+'\n## All key-condition response cells\n\nAll cells are shown, including floors and valid-protection cells. The event is valid keyed retry in the valid column and unsupported retry in the other columns.\n\n'+cells+'\n## Historical bridge weak counts\n\n'+table(['Endpoint','Reasoning setting','Unsupported retries'],rows)
    for study,cs in r['studies'].items():
        report+='\n## '+study+': all cells and task counts\n\n'+table(['Condition','Event','Count [95% reference limits]'],[[k,v['event'],count(v)] for k,v in cs.items()])
    Path('runs/response-uncertainty-v1/tables.md').write_text(report)
    return pooled,cells,table(['Endpoint','Reasoning setting','Unsupported retries'],rows)

if __name__=='__main__':render();print('Rendered response-interval tables.')
