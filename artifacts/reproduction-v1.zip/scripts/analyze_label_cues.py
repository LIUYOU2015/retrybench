"""Validate the frozen conflicting-label control and reproduce its analysis."""
from pathlib import Path
import hashlib,importlib.util
from collections import Counter
from retrybench.serialization import read_json_object,read_jsonl,write_json,write_jsonl,canonical_json_sha256
from retrybench import model
from response_intervals import summary
from contrast_inference import analyze_terms,holm
from followup_tables import table
STUDY='label-cue-v1'

def analyze():
    pd=Path('protocol')/STUDY;rd=Path('runs')/STUDY;p=read_json_object(pd/'protocol.json');cases=read_jsonl(pd/'manifest.jsonl');ph=canonical_json_sha256(p)
    if canonical_json_sha256(cases)!=p['manifest_sha256']:raise ValueError('manifest mismatch')
    for name,key in [('label_cue_study.py','implementation_sha256'),('followup_studies.py','helper_sha256')]:
        if hashlib.sha256((rd/'collection-code'/name).read_bytes()).hexdigest()!=p[key]:raise ValueError('collector hash mismatch')
    for name,digest in p['source_sha256'].items():
        if hashlib.sha256((Path(model.__file__).parent/name).read_bytes()).hexdigest()!=digest:raise ValueError('use frozen source')
    records={};costs={};provenance={}
    for endpoint in p['models']:
        path=rd/'shards'/endpoint/'requests.jsonl';rs=read_jsonl(path);s=read_json_object(path.parent/'summary.json');cs=[c for c in cases if c['requested_model']==endpoint]
        if not s['attempted_all'] or len(rs)!=len(cs) or [r['case_id'] for r in rs]!=[c['case_id'] for c in cs]:raise ValueError('incomplete/order mismatch')
        if s['protocol_sha256']!=ph or s['model']!=endpoint or s['planned']!=len(cs) or s['attempted']!=len(rs):raise ValueError('summary mismatch')
        for c,r in zip(cs,rs):
            if r['protocol_sha256']!=ph or r['collected_at_utc']<p['recorded_at_utc']:raise ValueError('request provenance mismatch')
            if r['status'] not in ('complete','incomplete','invalid_output','transport_timeout','transport_error'):raise ValueError('unreviewed failed request')
            if r['status'] in ('complete','incomplete','invalid_output'):
                if r['returned_model']!=endpoint and not r['returned_model'].startswith(endpoint+'-'):raise ValueError('wrong endpoint')
                u=r['usage'];i,ca,o=p['rates_per_million'][endpoint]
                if any(type(u.get(k)) is not int or u[k]<0 for k in ('input_tokens','cached_input_tokens','output_tokens','reasoning_tokens')) or u['cached_input_tokens']>u['input_tokens'] or u['reasoning_tokens']>u['output_tokens']:raise ValueError('usage mismatch')
                value=((u['input_tokens']-u['cached_input_tokens'])*i+u['cached_input_tokens']*ca+u['output_tokens']*o)/1e6
                if abs(value-r['cost_usd'])>1e-12:raise ValueError('cost mismatch')
            if r['status']=='complete' and (r['provider_status']!='completed' or r['selected_token'] not in c['allowed_actions'] or r['decision']['action']!=r['selected_token']):raise ValueError('invalid complete action')
            records[c['case_id']]=r
        known=sum(r.get('cost_usd',0) for r in rs);unknown=sum(r.get('unknown_cost_upper_reserve_usd',0) for r in rs)
        if known+unknown>p['endpoint_caps_usd'][endpoint] or abs(known-s['known_cost_usd'])>1e-12 or abs(unknown-s['unknown_cost_upper_reserve_usd'])>1e-12:raise ValueError('cost summary/cap mismatch')
        if sum(r['status']=='complete' for r in rs)!=s['complete'] or sum(r['status']!='complete' for r in rs)!=s['missing']:raise ValueError('summary counts')
        if sum(r['status'].startswith('transport_') for r in rs)>p['max_transport_missing_per_endpoint']+1:raise ValueError('transport limit exceeded')
        costs[endpoint]={'known_cost_usd':known,'unknown_cost_upper_reserve_usd':unknown};provenance[str(path)]=hashlib.sha256(path.read_bytes()).hexdigest()
    actions={k:r['decision']['action'] for k,r in records.items() if r['status']=='complete'};binary={k:int(a=='retry') for k,a in actions.items()}
    def cell(cs):
        a=Counter(actions[c['case_id']] for c in cs if c['case_id'] in actions);missing=sum(c['case_id'] not in actions for c in cs);k=a['retry'];d=a['wait']+a['unresolved'];stop=a['stop']
        return dict(summary(k,len(cs),missing),actions=dict(a),observed_responses=len(cs)-missing,observed_outcomes=3*(len(cs)-missing),outcomes={'false_retry_permission':3*k,'duplicates':2*k,'omissions':d+stop,'unresolved':3*d,'ledger_correct':k+2*(d+stop),'resolved_exact_state':k+2*stop})
    groups={};tasks={};formats={};contrasts={}
    for endpoint in p['models']:
        ecs=[c for c in cases if c['requested_model']==endpoint]
        for label in ('none','weak','unverified','authoritative'):
            cs=[c for c in ecs if c['label']==label];name=endpoint+'/'+label;groups[name]=cell(cs)
            for task in sorted({c['task_id'] for c in cs}):
                tc=[c for c in cs if c['task_id']==task];tasks[name+'/'+task]=cell(tc)
                for order in range(4):formats[name+'/'+task+f'/order{order}']=cell([c for c in tc if c['order_rotation']==order])
            if label!='weak':
                arms=[(1,cs),(-1,[c for c in ecs if c['label']=='weak'])]
                contrasts[name+'_minus_weak']=analyze_terms(arms,binary,['task_id','order_rotation'])
    adjusted=holm({k:v['conditional_p_bounds'][1] for k,v in contrasts.items()})
    for k,value in adjusted.items():contrasts[k]['holm9_worst_case_conditional_p']=value
    spec=importlib.util.spec_from_file_location('cue_frozen_score',rd/'collection-code/followup_studies.py');f=importlib.util.module_from_spec(spec);spec.loader.exec_module(f)
    outcomes=[]
    for c in cases:
        if c['case_id'] in actions:outcomes.extend(f.score(dict(c,condition=c['requested_model']+'/'+c['label']),actions[c['case_id']]))
    for group,g in groups.items():
        rows=[r for r in outcomes if r['condition']==group]
        for metric,count in g['outcomes'].items():
            if sum(r[metric] for r in rows)!=count:raise ValueError('closed-form/simulator mismatch')
    r={'schema_version':'retrybench-label-cue-report-v1','planned_requests':len(cases),'observed_responses':len(actions),'missing_responses':len(cases)-len(actions),'observed_outcomes':len(outcomes),'first_request_utc':min(r['collected_at_utc'] for r in records.values()),'last_request_utc':max(r['collected_at_utc'] for r in records.values()),'known_cost_usd':sum(c['known_cost_usd'] for c in costs.values()),'unknown_cost_upper_reserve_usd':sum(c['unknown_cost_upper_reserve_usd'] for c in costs.values()),'endpoint_costs':costs,'groups':groups,'task_cells':tasks,'format_cells':formats,'contrasts':contrasts,'missing_cases':[dict(case_id=c['case_id'],endpoint=c['requested_model'],label=c['label'],task=c['task_id'],order=c['order_rotation'],status=records[c['case_id']]['status']) for c in cases if c['case_id'] not in actions],'protocol_sha256':ph,'request_sha256':provenance,'interpretation':'Explicit weak guarantees held fixed. authoritative is conflicting metadata, not a real guarantee. All observed responses defer. Floor results do not establish label robustness or equivalence. First-decision synthetic GPT-only control; no additions after outcomes. Newcombe and conditional tests assume independent/exchangeable calls within specified strata; no task-population inference.'}
    write_json(rd/'report.json',r);write_jsonl(rd/'outcomes.jsonl',outcomes)
    rows=[]
    for name,v in groups.items():rows.append([name,str(v['events_observed'])+'/'+str(v['planned_responses']),v['missing_responses'],'/'.join(str(v['actions'].get(a,0)) for a in ('retry','stop','wait','unresolved'))]+[v['outcomes'][m] for m in ('duplicates','omissions','unresolved','ledger_correct','resolved_exact_state')])
    main=table(['Endpoint/label','Retries/planned','Missing','Retry/stop/wait/unresolved','Duplicates','Omissions','Unresolved outcomes','Ledger correct','Resolved exact'],rows)
    body='# Conflicting-label control\n\n'+r['interpretation']+'\n\n'+main
    for title,cs in [('Task cells',tasks),('Task/order cells',formats)]:body+='\n## '+title+'\n\n'+table(['Condition','Retries/planned','Missing','Actions'],[[k,f"{v['events_observed']}/{v['planned_responses']}",v['missing_responses'],str(v['actions'])] for k,v in cs.items()])
    body+='\n## All label contrasts\n\n'+table(['Contrast','Difference bounds','Newcombe95 reference envelope','Conditional p range','Holm9 worst p'],[[k,str(v['difference_bounds']),str(v['mover95_reference_envelope']),str(v['conditional_p_bounds']),str(v['holm9_worst_case_conditional_p'])] for k,v in contrasts.items()])
    (rd/'tables.md').write_text(body);return r,main
if __name__=='__main__':r,t=analyze();print(t);print({k:v for k,v in r.items() if not isinstance(v,(dict,list))})
