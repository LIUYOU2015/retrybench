"""Retrospective labeled canonical order contrasts; no new provider calls."""
from pathlib import Path
import hashlib,json,math
from fractions import Fraction
from collections import Counter
from contrast_inference import analyze_terms,holm
from retrybench.serialization import read_jsonl,write_json
ROOT=Path(__file__).resolve().parents[1]

def analyze():
    manifest=ROOT/'protocol/tier-a-v1/manifest.jsonl';requests=ROOT/'runs/tier-a-v1/requests.jsonl'
    cases=[c for c in read_jsonl(manifest) if c['block']=='canonical' and c['label']=='labeled']
    raw={r['case_id']:r for r in read_jsonl(requests)}
    assert all(raw[c['case_id']]['status']=='complete' for c in cases)
    binary={c['case_id']:int(raw[c['case_id']]['decision']['action']=='retry') for c in cases}
    results={}
    for model in sorted({c['requested_model'] for c in cases}):
        cs=[c for c in cases if c['requested_model']==model]
        arms=[(1,[c for c in cs if c['order_rotation']!=0]),(-1,[c for c in cs if c['order_rotation']==0])]
        r=analyze_terms(arms,binary,['task_id'])
        r['counts']=[dict(events=sum(binary[c['case_id']] for c in rows),n=len(rows)) for _,rows in arms]
        tasks={}
        for task in sorted({c['task_id'] for c in cs}):
            counts=[(sum(binary[c['case_id']] for c in rows if c['task_id']==task),sum(c['task_id']==task for c in rows)) for _,rows in arms]
            d=Fraction(*counts[0])-Fraction(*counts[1]);tasks[task]=dict(other_orders=list(counts[0]),order_zero=list(counts[1]),difference=float(d),sign=1 if d>0 else -1 if d<0 else 0)
        signs=Counter(t['sign'] for t in tasks.values());n=signs[1]+signs[-1];k=min(signs[1],signs[-1]);sign_p=min(1.,2*sum(math.comb(n,i) for i in range(k+1))/2**n) if n else 1.
        r.update(task_cells=tasks,task_sign_p=sign_p);results[model]=r
    adjusted=holm({m:r['conditional_p_bounds'][1] for m,r in results.items()})
    for m in results:results[m]['holm_p']=adjusted[m]
    return dict(schema_version='retrybench-order-effects-v1',planned_labeled_responses=768,observed_labeled_responses=len(cases),contrasts=results,
      scope='Post-hoc other3orders-minus-historicalorder0 within labeled canonical prompts. Six endpoints form retrospective Holm family. This does not account for choosing this contrast after viewing heatmap. Alternatives equally sampled; mixture not all24 permutations. Nominal independent-call Newcombe intervals and task-conditional tests are distinct reference calculations. Four purposive tasks and serving dependence limit inference.',
      source_sha256={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [manifest,requests,Path(__file__),ROOT/'scripts/contrast_inference.py']})

def render(r):
    lines=['# Retrospective canonical order effects','',r['scope'],'', '| Endpoint | Order0 retries | Other3orders retries | Difference (pp) | Nominal95% Newcombe (pp) | Exact task-stratified p | Holm6 p | Task sign p |','|---|---:|---:|---:|---|---:|---:|---:|']
    for m,c in r['contrasts'].items():
        a,b=c['counts'];lo,hi=c['mover95_reference_envelope'];lines.append(f"| {m} | {b['events']}/{b['n']} | {a['events']}/{a['n']} | {100*c['difference_bounds'][0]:+.2f} | [{100*lo:+.2f}, {100*hi:+.2f}] | {c['conditional_p_bounds'][0]:.8g} | {c['holm_p']:.8g} | {c['task_sign_p']:.3g} |")
    return '\n'.join(lines)+'\n'
if __name__=='__main__':
    r=analyze();rd=ROOT/'runs/order-effects-v1';rd.mkdir(exist_ok=True);write_json(rd/'report.json',r);(rd/'tables.md').write_text(render(r));print(render(r))
