"""Rank stability and equal-variant summaries with no missing-action imputation."""
from pathlib import Path
from itertools import product,combinations
from fractions import Fraction
import math,hashlib
from retrybench.serialization import read_json_object,read_jsonl,write_json,write_jsonl
from followup_tables import table
MODELS=['gpt-5.4-mini-2026-03-17','gpt-5.4-2026-03-05','gpt-5.6-sol','gpt-5.6-terra','gpt-5.6-luna']
VARIANTS=['canonical/labeled','canonical/unlabeled','coded/labeled','coded/unlabeled']

def tau_b(x,y):
    if len(x)!=len(y) or len(x)<2:raise ValueError('invalid rank vectors')
    concordant=discordant=tie_x=tie_y=0
    for i,j in combinations(range(len(x)),2):
        a=(x[i]>x[j])-(x[i]<x[j]);b=(y[i]>y[j])-(y[i]<y[j])
        tie_x+=a==0;tie_y+=b==0;concordant+=a*b>0;discordant+=a*b<0
    n0=math.comb(len(x),2);den=(n0-tie_x)*(n0-tie_y)
    return None if den==0 else (concordant-discordant)/math.sqrt(den)

def possible_vectors(groups,models,variant):
    cells=[groups[m+'/'+variant] for m in models]
    return [tuple(Fraction(k,c['planned_responses']) for k,c in zip(ks,cells)) for ks in product(*(range(c['events_observed'],c['events_observed']+c['missing_responses']+1) for c in cells))]

def analyze():
    path=Path('runs/historical-counterbalance-v1/report.json');r=read_json_object(path);groups=r['groups'];analyses={}
    for panel,models in [('matched_none',MODELS),('including_astra_low',MODELS+['gpt-6-astra'])]:
        vectors={v:possible_vectors(groups,models,v) for v in VARIANTS};pairs={}
        for a,b in combinations(VARIANTS,2):
            vals=[tau_b(x,y) for x in vectors[a] for y in vectors[b]];finite=[v for v in vals if v is not None]
            pairs[a+' vs '+b]={'tau_b_bounds':[min(finite),max(finite)],'distinct_count_assignments':len(vals),'undefined_assignments':len(vals)-len(finite)}
        comparisons={}
        for a,b in combinations(models,2):
            bounds=[]
            for v in VARIANTS:
                ac=groups[a+'/'+v];bc=groups[b+'/'+v]
                bounds.append([ac['rate_bounds'][0]-bc['rate_bounds'][1],ac['rate_bounds'][1]-bc['rate_bounds'][0]])
            comparisons[a+' minus '+b]={'variant_difference_bounds':dict(zip(VARIANTS,bounds)),'strict_order_across_every_variant_and_completion':'first_higher' if all(x[0]>0 for x in bounds) else 'second_higher' if all(x[1]<0 for x in bounds) else 'not_strictly_identified','opposite_observed_directions_robust_to_missing':any(x[0]>0 for x in bounds) and any(x[1]<0 for x in bounds)}
        analyses[panel]={'models':models,'pairwise_variant_tau_b':pairs,'endpoint_comparisons':comparisons}
    summaries={}
    for m in MODELS+['gpt-6-astra']:
        cells=[groups[m+'/'+v] for v in VARIANTS];bounds=[c['rate_bounds'] for c in cells]
        summaries[m]={'variant_rate_bounds':dict(zip(VARIANTS,bounds)),'min_rate_bounds':[min(b[0] for b in bounds),min(b[1] for b in bounds)],'max_rate_bounds':[max(b[0] for b in bounds),max(b[1] for b in bounds)],'equal_variant_mean_bounds':[sum(b[i] for b in bounds)/4 for i in (0,1)],'interpretation':'Four macro variants weighted equally; not pooled by 64:256 design allocation. Bounds cover missing actions, not sampling uncertainty.'}
    # A post-hoc rough planning calculation, not observed power or a test of equivalence.
    z975=1.959963984540054;z80=.8416212335729143
    planning={str(n):{'null_se_at_half':math.sqrt(.5/n),'approx_80pct_detectable_difference':(z975+z80)*math.sqrt(.5/n)} for n in (32,128)}
    manifest=Path('protocol/historical-counterbalance-v1/manifest.jsonl');requests=Path('runs/historical-counterbalance-v1/shards/gpt-5.6-sol/requests.jsonl');cs={c['case_id']:c for c in read_jsonl(manifest)}
    selected=[]
    for req in read_jsonl(requests):
        c=cs[req['case_id']]
        if c['representation']=='coded' and c['label']=='unlabeled' and req.get('decision',{}).get('action')=='retry':selected.append({'case_id':req['case_id'],'task_id':c['task_id'],'mapping':c['mapping_rotation'],'order':c['order_rotation'],'rationale':req['decision']['rationale']})
    assert len(selected)==27
    result={'schema_version':'retrybench-interface-stability-v1','analysis_status':'Post-hoc descriptive analysis of four macro variants. No new model calls.','variants':VARIANTS,'rank_interpretation':'Kendall tau-b handles exact rate ties. Enumerate all feasible missing retry counts per endpoint/variant; no missing-as-nonretry imputation. Bounds are not rank confidence intervals and omit API sampling uncertainty. Five matched-none endpoints are primary; Astra-low is a separate descriptive sensitivity panel. Near-tie flips do not establish population ranking reversals.','panels':analyses,'equal_variant_summaries':summaries,'planning_reference':{'assumptions':'Normal approximation, two independent binomial arms near p=.5, two-sided alpha=.05 and 80% target power. No multiplicity, missingness or clustering allowance. Not observed post-hoc power and not a guarantee that n=128 is decisive.','by_per_arm_n':planning},'selected_rationale_count':len(selected),'source_sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (path,manifest,requests)}}
    out=Path('runs/interface-stability-v1');out.mkdir(exist_ok=True);write_json(out/'report.json',result);write_jsonl(out/'sol-coded-retry-rationales.jsonl',selected)
    def rng(v,scale=1):return '['+', '.join(f'{scale*x:.3f}' for x in v)+']'
    text='# Interface stability\n\n'+result['rank_interpretation']+'\n\n'
    for panel,a in analyses.items():text+='## '+panel+'\n\n'+table(['Variant comparison','Kendall tau-b bounds','Feasible pooled-count assignments'],[[k,rng(v['tau_b_bounds']),v['distinct_count_assignments']] for k,v in a['pairwise_variant_tau_b'].items()])+'\n'
    text+='## Equal-variant descriptive summaries\n\nRates in percent. Brackets cover missing actions only.\n\n'+table(['Endpoint','Min','Max','Mean (four equal weights)'],[[m]+[rng(v[k],100) for k in ('min_rate_bounds','max_rate_bounds','equal_variant_mean_bounds')] for m,v in summaries.items()])
    text+='\n## Canonical sample-size planning reference\n\n'+result['planning_reference']['assumptions']+'\n\n'+table(['Per-arm n','Approximate 80% detectable difference (pp)'],[[n,f"{v['approx_80pct_detectable_difference']*100:.2f}"] for n,v in planning.items()])
    (out/'tables.md').write_text(text);return result,text
if __name__=='__main__':r,t=analyze();print(t)
