"""Retrospective same-prompt retest and secondary protected-recovery contrasts."""
from pathlib import Path
import json,hashlib
from contrast_inference import analyze_terms,holm
from retrybench.serialization import read_jsonl,write_json
import tier_a_study as earlier
import candidate_presence_study as later
ROOT=Path(__file__).resolve().parents[1]

def analyze():
    studies=['tier-a-v1','candidate-presence-v1'];cases={};records={};sources=[]
    for study in studies:
        paths=[ROOT/'protocol'/study/'manifest.jsonl',ROOT/'runs'/study/'requests.jsonl'];sources+=paths
        cases[study]=[c for c in read_jsonl(paths[0]) if c['block']=='supplied_key' and c['label']=='labeled']
        records.update({r['case_id']:r for r in read_jsonl(paths[1])})
    old,new=[cases[s] for s in studies]
    comparison=[]
    for c in new:
        if c['candidate']!='absent':continue
        match=next(x for x in old if all(x[k]==c[k] for k in ('requested_model','task_id','original_key_state','repetition')))
        assert earlier.payload(match)==later.payload(c)
        comparison.append({'earlier_case':match['case_id'],'new_case':c['case_id'],'payload_sha256':hashlib.sha256(json.dumps(later.payload(c),sort_keys=True).encode()).hexdigest()})
    def event(c,name):
        r=records[c['case_id']]
        if r['status']!='complete':return None
        d=r['decision'];safe=d['action']=='retry_with_key' and c['original_key'] is not None and d['idempotency_key']==c['original_key']
        return int(safe if name=='protected' else d['action'] in ('retry','retry_with_key') and not safe)
    def contrast(arms,name):
        values={c['case_id']:event(c,name) for _,cs in arms for c in cs if event(c,name) is not None}
        r=analyze_terms(arms,values,['task_id']);r['event']=name
        r['counts']=[dict(events=sum(values.get(c['case_id'],0) for c in cs),planned=len(cs),returned=sum(c['case_id'] in values for c in cs),missing=sum(c['case_id'] not in values for c in cs)) for _,cs in arms]
        r['task_cells']={task:[dict(events=sum(values.get(c['case_id'],0) for c in cs if c['task_id']==task),planned=sum(c['task_id']==task for c in cs),missing=sum(c['task_id']==task and c['case_id'] not in values for c in cs)) for _,cs in arms] for task in sorted({c['task_id'] for _,cs in arms for c in cs})}
        return r
    retest={};progress={}
    for model in later.MODELS:
        for state in ('omitted','present'):
            a=[c for c in new if c['candidate']=='absent' and c['requested_model']==model and c['original_key_state']==state]
            b=[c for c in old if c['requested_model']==model and c['original_key_state']==state]
            retest[model+'/'+state]=contrast([(1,a),(-1,b)],'unsupported')
        a=[c for c in new if c['candidate']=='displayed' and c['requested_model']==model and c['original_key_state']=='present']
        b=[c for c in new if c['candidate']=='absent' and c['requested_model']==model and c['original_key_state']=='present']
        progress[model]=contrast([(1,a),(-1,b)],'protected')
    for family in (retest,progress):
        adj=holm({k:r['conditional_p_bounds'][1] for k,r in family.items()})
        for k in family:family[k]['holm_worst_case_p']=adj[k]
    sources += [Path(__file__),ROOT/'scripts/contrast_inference.py',ROOT/'scripts/tier_a_study.py',ROOT/'scripts/candidate_presence_study.py',ROOT/'scripts/followup_studies.py']
    return dict(schema_version='retrybench-key-retest-v1',scope='Retrospective analyses, no new model calls. Retest compares new absent arms to earlier labeled supplied-key arms; payload equality checked for all 120 planned matched cases, calls not paired statistically. Six retest contrasts form an exploratory Holm family; between-block timing/alias/serving confounds remain. Three protected-recovery contrasts form a separate exploratory Holm family; protected recovery was a predeclared secondary outcome, but this test family was selected after seeing outcomes. Neither replaces or changes the six prespecified primary error tests.',payload_matches=comparison,retest=retest,protected_recovery=progress,source_sha256={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources})

def render(r):
    lines=['# Same-prompt retest and secondary protected recovery','',r['scope'],'','## Absent-candidate retest: new minus earlier labeled','', '| Endpoint / original | Earlier errors / planned | New errors / planned | Difference bounds (pp) | Nominal 95% envelope (pp) | Worst-case Holm6 p |','|---|---:|---:|---|---|---:|']
    def count(c):return f"{c['events']}/{c['planned']}"+(f" +{c['missing']} missing" if c['missing'] else '')
    for k,c in r['retest'].items():
        a,b=c['counts'];d=c['difference_bounds'];ci=c['mover95_reference_envelope'];lines.append(f"| {k} | {count(b)} | {count(a)} | [{100*d[0]:+.2f}, {100*d[1]:+.2f}] | [{100*ci[0]:+.2f}, {100*ci[1]:+.2f}] | {c['holm_worst_case_p']:.7g} |")
    lines+=['','## Original-present protected recovery: displayed minus absent','', '| Endpoint | Absent protected / planned | Displayed protected / planned | Difference bounds (pp) | Nominal 95% envelope (pp) | Worst-case Holm3 p |','|---|---:|---:|---|---|---:|']
    for k,c in r['protected_recovery'].items():
        a,b=c['counts'];d=c['difference_bounds'];ci=c['mover95_reference_envelope'];lines.append(f"| {k} | {count(b)} | {count(a)} | [{100*d[0]:+.2f}, {100*d[1]:+.2f}] | [{100*ci[0]:+.2f}, {100*ci[1]:+.2f}] | {c['holm_worst_case_p']:.7g} |")
    return '\n'.join(lines)+'\n'
if __name__=='__main__':
    r=analyze();rd=ROOT/'runs/key-retest-v1';rd.mkdir(exist_ok=True);write_json(rd/'report.json',r);(rd/'tables.md').write_text(render(r));print(render(r))
