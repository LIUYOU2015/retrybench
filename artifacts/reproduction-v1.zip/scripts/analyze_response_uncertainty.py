"""Post-hoc response-level binomial references for bridge and key controls."""
from pathlib import Path
import hashlib
from collections import Counter
from retrybench.serialization import read_jsonl,write_json
from response_intervals import summary

def analyze():
    output={};provenance={}
    for study in ('historical-bridge-v1','label-protection-v1'):
        pd=Path('protocol')/study;rd=Path('runs')/study
        cases=read_jsonl(pd/'manifest.jsonl');requests={r['case_id']:r for r in read_jsonl(rd/'requests.jsonl')};cells={};groupings={}
        for c in cases:
            if study=='historical-bridge-v1':
                keys=[c['condition']+'/'+c['observed_state'],c['condition']+'/'+c['observed_state']+'/'+c['task_id']]
            else:
                keys=[c['condition'],c['requested_model']+'/all_labels_semantics/'+c['protection'],c['condition']+'/'+c['task_id']]
            for key in keys:groupings.setdefault(key,[]).append(c)
        for key,cs in groupings.items():
            rs=[requests[c['case_id']] for c in cs if requests[c['case_id']]['status']=='complete'];missing=len(cs)-len(rs)
            if study=='historical-bridge-v1':
                event='correct_terminal_retry' if cs[0]['observed_state']=='not_executed' else 'unsupported_retry'
                k=sum(r['decision']['action']=='retry' for r in rs)
            else:
                event='valid_keyed_retry' if cs[0]['protection']=='valid' else 'unsupported_retry'
                k=sum(r['decision']['action']=='retry_with_key' if event=='valid_keyed_retry' else r['decision']['action'] in ('retry','retry_with_key') for r in rs)
            cells[key]=dict(summary(k,len(cs),missing),event=event,actions=dict(Counter(r['decision']['action'] for r in rs)))
        output[study]=cells
        for path in (pd/'manifest.jsonl',rd/'requests.jsonl'):provenance[str(path)]=hashlib.sha256(path.read_bytes()).hexdigest()
    return {'schema_version':'retrybench-response-uncertainty-v1','analysis_status':'Post-hoc response-level reference calculations, added after both studies. Complete task/cell counts are primary; binomial assumptions are not demonstrated by these heterogeneous purposive designs. Not simultaneous intervals and not bounds on episode-level safety.','two_sided_zero80_upper':summary(0,80)['cp95_reference_envelope'][1],'one_sided_zero80_upper':1-.05**(1/80),'studies':output,'source_hashes':provenance}

if __name__=='__main__':
    report=analyze();p=Path('runs/response-uncertainty-v1');p.mkdir(exist_ok=True);write_json(p/'report.json',report);print('Wrote response-level exact binomial reference intervals.')
