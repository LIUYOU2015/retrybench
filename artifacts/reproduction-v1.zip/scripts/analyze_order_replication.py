"""Retrospective canonical order contrasts in two frozen blocks; no API calls.

This analysis was specified after the order heatmap and reviewer comments.
It does not replace earlier reports or turn either block into a preregistration.
"""
from collections import Counter
from fractions import Fraction
from itertools import product
from pathlib import Path
import hashlib
import math

from contrast_inference import analyze_terms, holm
from retrybench.serialization import (
    canonical_json_sha256, read_json_object, read_jsonl, write_json,
)

ROOT = Path(__file__).resolve().parents[1]
STUDIES = ("historical-counterbalance-v1", "tier-a-v1")
OUTPUT = "order-replication-v1"
LABELS = ("labeled", "unlabeled")


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(study):
    directory = ROOT / "protocol" / study
    protocol_path = directory / "protocol.json"
    manifest_path = directory / "manifest.jsonl"
    protocol = read_json_object(protocol_path)
    manifest = read_jsonl(manifest_path)
    assert canonical_json_sha256(manifest) == protocol["manifest_sha256"]
    paths = ([ROOT / "runs" / study / "shards" / m / "requests.jsonl"
              for m in protocol["models"]] if study == STUDIES[0]
             else [ROOT / "runs" / study / "requests.jsonl"])
    records = [r for p in paths for r in read_jsonl(p)]
    assert len({r["case_id"] for r in records}) == len(records)
    raw = {r["case_id"]: r for r in records}
    assert set(raw) == {c["case_id"] for c in manifest}
    for model in protocol["models"]:
        expected = [c["case_id"] for c in manifest if c["requested_model"] == model]
        selected = set(expected)
        assert [r["case_id"] for r in records if r["case_id"] in selected] == expected
    cases = [c for c in manifest if c.get("representation") == "canonical"]
    values = {}
    for c in cases:
        r = raw[c["case_id"]]
        assert r["protocol_sha256"] == canonical_json_sha256(protocol)
        assert r.get("requested_model", c["requested_model"]) == c["requested_model"]
        assert c["mapping_rotation"] == 0
        assert c["transcript_sha256"] == canonical_json_sha256(
            {k: c[k] for k in ("instructions", "prompt")})
        if r["status"] == "complete":
            assert r["provider_status"] == "completed"
            assert r["returned_model"] == c["requested_model"] or r["returned_model"].startswith(c["requested_model"] + "-")
            assert r["decision"]["action"] in ("retry", "stop", "wait", "unresolved")
            if "selected_token" in r:
                assert c["token_to_action"][r["selected_token"]] == r["decision"]["action"]
            values[c["case_id"]] = int(r["decision"]["action"] == "retry")
        else:
            assert "decision" not in r
    return cases, values, raw, [protocol_path, manifest_path] + paths


def counts(cases, values, raw):
    missing = [c for c in cases if c["case_id"] not in values]
    events = sum(values.get(c["case_id"], 0) for c in cases)
    return {
        "retries": events, "planned": len(cases),
        "returned": len(cases) - len(missing), "missing": len(missing),
        "rate_bounds": [events / len(cases), (events + len(missing)) / len(cases)],
        "actions": dict(sorted(Counter(raw[c["case_id"]]["decision"]["action"]
                                       for c in cases if c["case_id"] in values).items())),
        "missing_case_ids": [c["case_id"] for c in missing],
    }


def sign_diagnostics(cases, values):
    tasks = sorted({c["task_id"] for c in cases})
    missing = [c["case_id"] for c in cases if c["case_id"] not in values]
    patterns = set()
    ps = []
    for bits in product((0, 1), repeat=len(missing)):
        filled = {**values, **dict(zip(missing, bits))}
        signs = []
        for task in tasks:
            zero = [c for c in cases if c["task_id"] == task and c["order_rotation"] == 0]
            other = [c for c in cases if c["task_id"] == task and c["order_rotation"] != 0]
            delta = (Fraction(sum(filled[c["case_id"]] for c in other), len(other))
                     - Fraction(sum(filled[c["case_id"]] for c in zero), len(zero)))
            signs.append(1 if delta > 0 else -1 if delta < 0 else 0)
        patterns.add(tuple(signs))
        n = sum(s != 0 for s in signs)
        k = min(signs.count(1), signs.count(-1))
        ps.append(min(1., 2 * sum(math.comb(n, i) for i in range(k + 1)) / 2**n) if n else 1.)
    return {"task_order": tasks, "possible_sign_patterns": [list(x) for x in sorted(patterns)],
            "two_sided_sign_p_bounds": [min(ps), max(ps)]}


def analyze():
    contrasts, interactions, cells, blocks, sources, datasets = {}, {}, {}, {}, [], {}
    for study in STUDIES:
        cases, values, raw, paths = load(study)
        datasets[study] = (cases, values, raw)
        sources.extend(paths)
        models = sorted({c["requested_model"] for c in cases})
        tasks = sorted({c["task_id"] for c in cases})
        n_cell = 2 if study == STUDIES[0] else 8
        assert len(cases) == len(models) * len(tasks) * 2 * 4 * n_cell
        blocks[study] = {
            "planned_canonical_responses": len(cases), "returned_canonical_responses": len(values),
            "missing_canonical_responses": len(cases) - len(values),
            "calls_per_endpoint_task_label_order": n_cell,
            "calls_per_endpoint_label": 4 * 4 * n_cell,
            "collection_first_utc": min(raw[c["case_id"]]["collected_at_utc"] for c in cases),
            "collection_last_utc": max(raw[c["case_id"]]["collected_at_utc"] for c in cases),
        }
        for model in models:
            for label in LABELS:
                cs = [c for c in cases if c["requested_model"] == model and c["label"] == label]
                arms = [(1, [c for c in cs if c["order_rotation"] != 0]),
                        (-1, [c for c in cs if c["order_rotation"] == 0])]
                result = analyze_terms(arms, values, ["task_id"])
                # One declared retrospective inferential family; do not add the MOVER p-value.
                result.pop("mover_p_bounds")
                result.update(event="retry", order_zero=counts(arms[1][1], values, raw),
                              other_three_orders=counts(arms[0][1], values, raw),
                              sign_diagnostics=sign_diagnostics(cs, values))
                key = "/".join((study, model, label))
                contrasts[key] = result
                for task in tasks:
                    for order in range(4):
                        subset = [c for c in cs if c["task_id"] == task and c["order_rotation"] == order]
                        assert len(subset) == n_cell
                        cells[key + "/" + task + "/order" + str(order)] = counts(subset, values, raw)
            cs = [c for c in cases if c["requested_model"] == model]
            terms = []
            for coefficient, label, is_other in ((1, "unlabeled", True), (-1, "unlabeled", False),
                                                 (-1, "labeled", True), (1, "labeled", False)):
                terms.append((coefficient, [c for c in cs if c["label"] == label
                                            and (c["order_rotation"] != 0) == is_other]))
            interaction = analyze_terms(terms, values)
            interaction.pop("mover_p_bounds")
            interaction.update(event="retry", interpretation="Exploratory interval only: (unlabeled other-minus-zero) minus (labeled other-minus-zero). Not a confirmatory interaction test; intervals are nominal, not multiplicity-adjusted.")
            interactions[study + "/" + model] = interaction
    assert len(contrasts) == 24 and len(cells) == 384 and len(interactions) == 12
    adjusted = holm({k: c["conditional_p_bounds"][1] for k, c in contrasts.items()})
    for k, value in adjusted.items():
        contrasts[k]["holm24_worst_case_conditional_p"] = value

    # Compare every endpoint/task/label/order prompt, not only order zero.
    fields = ("instructions", "prompt", "allowed_actions", "token_to_action", "reasoning_effort", "max_output_tokens")
    indices = {}
    for study, (cases, _, _) in datasets.items():
        index = {}
        for c in cases:
            key = (c["requested_model"], c["task_id"], c["label"], c["order_rotation"])
            content = {f: c[f] for f in fields}
            if key in index:
                assert index[key] == content
            index[key] = content
        indices[study] = index
    left, right = [indices[s] for s in STUDIES]
    assert left.keys() == right.keys() and all(left[k] == right[k] for k in left)
    return {
        "schema_version": "retrybench-order-replication-v1", "blocks": blocks,
        "analysis_status": "Retrospective analysis specified after both collections, the later order heatmap, and reviewer comments; no new model calls or public preregistration.",
        "scope": "Other three cyclic orders, equally weighted, minus historical order zero, separately for both labels, both blocks, and all six endpoints. One retrospective 24-comparison Holm family uses worst-case exact conditional p over missing response assignments. This correction does not remove selected-reference, analysis-selection, or prior prompt-exploration concerns. Fresh draws do not randomize the retained historical prompt. Separate calls are not paired by draw index. Four purposive tasks and serving dependence preclude task-population interpretation. The order/label prompts do not spell out weak lookup semantics; the measured event is retry, not proof of knowingly violating an explicit visible contract.",
        "interval_scope": "Nominal independent-call Newcombe intervals with all feasible missing-response assignments; intervals are not simultaneous or inversions of adjusted task-stratified exact tests. Interaction intervals are exploratory four-arm MOVER references only. Task sign diagnostics ignore ties and retain missing-choice ranges.",
        "prompt_equivalence": {"matched_endpoint_task_label_order_cells": len(left),
                               "instructions_and_prompt_utf8_identical": True,
                               "also_matched_fields": list(fields[2:]),
                               "sampling_draws_earlier_later": [2, 8],
                               "limit": "Matching transcript/configuration fields does not establish matching serving state, immutable alias weights, collection time, or full request metadata. Later requests explicitly set service_tier=default; the earlier collector omitted that field."},
        "contrasts": contrasts, "label_by_order_interaction_references": interactions,
        "task_order_cells": cells,
        "source_sha256": {str(p.relative_to(ROOT)): sha(p) for p in sorted(set(sources + [Path(__file__), ROOT / "scripts/contrast_inference.py"]))},
    }


def interval(values, scale=1., precision=2):
    return "[" + ", ".join(f"{scale*x:.{precision}f}" for x in values) + "]"


def cell_text(cell):
    return f"{cell['retries']}/{cell['planned']}" + (f" +{cell['missing']} missing" if cell["missing"] else "")


def render(report):
    lines = ["# Retrospective order contrasts across two canonical blocks", "", report["analysis_status"], "", report["scope"], "", report["interval_scope"], "",
             "Earlier cells contain **2 calls**, later cells **8 calls**, per endpoint/task/label/order. All 192 paired transcript cells are byte-identical across blocks; full request metadata and serving state are not thereby identical.", "",
             "## Order contrasts", "", "Differences are other-three-orders minus historical order zero. Missing is not a non-retry. Ranges preserve planned denominators.", "",
             "| Block / endpoint / label | Order 0 | Other three orders | Difference bounds (pp) | Nominal 95% Newcombe envelope (pp) | Exact conditional p range | Worst-case Holm24 p |", "|---|---|---|---|---|---|---:|"]
    for k, c in report["contrasts"].items():
        p_range = "[" + ", ".join(f"{p:.8g}" for p in c["conditional_p_bounds"]) + "]"
        lines.append(f"| {k} | {cell_text(c['order_zero'])} | {cell_text(c['other_three_orders'])} | {interval(c['difference_bounds'],100)} | {interval(c['mover95_reference_envelope'],100)} | {p_range} | {c['holm24_worst_case_conditional_p']:.8g} |")
    lines += ["", "## Exploratory label-by-order differences of differences", "", "(Unlabeled other-minus-zero) − (labeled other-minus-zero). Interval references only; no new interaction testing family.", "", "| Block / endpoint | Difference bounds (pp) | Nominal 95% MOVER envelope (pp) |", "|---|---|---|"]
    for k, c in report["label_by_order_interaction_references"].items():
        lines.append(f"| {k} | {interval(c['difference_bounds'],100)} | {interval(c['mover95_reference_envelope'],100)} |")
    lines += ["", "## Every task and cyclic order", "", "Each entry is returned retries/planned calls, with missing responses explicit. Cell counts are not eight independent task families.", "", "| Block / endpoint / label / task | Order 0 | Order 1 | Order 2 | Order 3 |", "|---|---|---|---|---|"]
    prefixes = sorted({k.rsplit("/order", 1)[0] for k in report["task_order_cells"]})
    for k in prefixes:
        lines.append("| " + k + " | " + " | ".join(cell_text(report["task_order_cells"][k + "/order" + str(i)]) for i in range(4)) + " |")
    lines += ["", "## Task sign diagnostics", "", "Task order is CI, issue, release, review. +1 is more retry in other orders, −1 less, 0 a tie; missing cases may admit multiple sign patterns.", "", "| Block / endpoint / label | Possible sign patterns | Two-sided sign p bounds |", "|---|---|---|"]
    for k, c in report["contrasts"].items():
        s = c["sign_diagnostics"]
        lines.append(f"| {k} | {s['possible_sign_patterns']} | {interval(s['two_sided_sign_p_bounds'],precision=3)} |")
    return "\n".join(lines) + "\n"


if __name__ == "__main__":
    report = analyze()
    directory = ROOT / "runs" / OUTPUT
    directory.mkdir(exist_ok=True)
    write_json(directory / "report.json", report)
    (directory / "tables.md").write_text(render(report), encoding="utf-8")
    print("Wrote retrospective 24-contrast report, 384 task/order cells, and 12 exploratory interaction references.")
