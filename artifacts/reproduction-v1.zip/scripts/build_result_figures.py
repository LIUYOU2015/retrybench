"""Render deterministic result SVGs from released reports (Matplotlib 3.9.4).

Run from any directory: python scripts/build_result_figures.py --preview
PNG previews are optional and are written to dist/figures, outside the paper.
Missing-action bounds are sensitivity bounds, not sampling intervals.
"""
from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch

ROOT = Path(__file__).resolve().parents[1]
MODELS = [
    ("gpt-5.4-mini-2026-03-17", "Mini"),
    ("gpt-5.4-2026-03-05", "GPT-5.4"),
    ("gpt-5.6-sol", "Sol"),
    ("gpt-5.6-terra", "Terra"),
    ("gpt-5.6-luna", "Luna"),
    ("gpt-6-astra", "Astra · low"),
]
INK = "#263440"
COLORS = {"canonical": "#3E647C", "coded": "#AD582B"}


def configure() -> None:
    plt.rcParams.update({
        "font.family": "DejaVu Sans",
        "font.size": 10,
        "text.color": INK,
        "axes.labelcolor": INK,
        "xtick.color": INK,
        "ytick.color": INK,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.spines.left": False,
        "axes.edgecolor": "#B6C0C7",
        "svg.fonttype": "none",
        "svg.hashsalt": "retrybench-result-figures-v1",
        "savefig.facecolor": "white",
    })


def read_report(relative: str) -> dict:
    return json.loads((ROOT / relative).read_text())


def save(fig, name: str, preview: bool) -> None:
    directory = ROOT / "paper/generated"
    directory.mkdir(parents=True, exist_ok=True)
    fig.savefig(directory / (name + ".svg"), metadata={
        "Date": None, "Creator": "RetryBench deterministic result figures",
    })
    if preview:
        directory = ROOT / "dist/figures"
        directory.mkdir(parents=True, exist_ok=True)
        fig.savefig(directory / (name + ".png"), dpi=170,
                    metadata={"Software": "RetryBench result figures"})
    plt.close(fig)


def effect_text(bounds: list[float]) -> str:
    lo, hi = (100 * value for value in bounds)
    return f"{lo:+.1f}" if lo == hi else f"[{lo:+.1f}, {hi:+.1f}]"


def label_contrasts(preview: bool) -> None:
    report = read_report("runs/contrast-inference-v1/report.json")
    contrasts = report["historical"]["contrasts"]
    expected = {
        f"{model}/{representation}/label_removal"
        for model, _ in MODELS for representation in COLORS
    }
    actual = {key for key, row in contrasts.items()
              if "holm12_worst_case_conditional_p" in row}
    if expected != actual:
        raise ValueError("The figure must include all 12 primary label contrasts")
    fig, ax = plt.subplots(figsize=(11.8, 8.7))
    fig.subplots_adjust(left=.255, right=.81, top=.85, bottom=.205)
    positions, labels = [], []
    for index, (model, display) in enumerate(MODELS):
        base = index * 2.55 + (0.75 if index == 5 else 0)
        for offset, representation in enumerate(COLORS):
            y = base + offset
            row = contrasts[f"{model}/{representation}/label_removal"]
            ci = [100 * x for x in row["mover95_reference_envelope"]]
            bounds = [100 * x for x in row["difference_bounds"]]
            color = COLORS[representation]
            ax.plot(ci, [y, y], color=color, alpha=.62, lw=1.5, zorder=2)
            ax.vlines(ci, y - .10, y + .10, color=color, alpha=.62, lw=1.1)
            if bounds[0] == bounds[1]:
                ax.plot(bounds[0], y, "o", color=color, ms=6, zorder=4)
            else:
                ax.plot(bounds, [y, y], color=color, lw=5,
                        solid_capstyle="butt", zorder=4)
                ax.vlines(bounds, y - .11, y + .11, color=color, lw=1.2,
                          zorder=4)
            ax.text(1.025, y, effect_text(row["difference_bounds"]),
                    transform=ax.get_yaxis_transform(), va="center", fontsize=10)
            positions.append(y)
            labels.append(f"{display}  /  {representation}")
    # Astra uses a different reasoning setting and is not part of the none panel.
    ax.axhspan(12.45, 15.15, color="#F0F3F5", zorder=0)
    ax.axhline(12.45, color="#AFBAC2", lw=.8, ls=(0, (3, 3)), zorder=1)
    ax.axvline(0, color="#5D6870", lw=1, ls=(0, (3, 3)), zorder=1)
    ax.set_yticks(positions, labels)
    ax.tick_params(axis="y", length=0, pad=12, labelsize=9.7)
    ax.set_ylim(-.75, 15.15)
    ax.invert_yaxis()
    ax.set_xlim(-40, 40)
    ax.set_xticks(range(-40, 41, 10))
    ax.xaxis.grid(True, color="#E7EAED", lw=.7)
    ax.set_axisbelow(True)
    ax.set_xlabel("Unlabeled − labeled retry rate (percentage points)", labelpad=12)
    ax.text(1.025, 1.035, "Effect / missing bounds", transform=ax.transAxes,
            fontsize=9.7, ha="left")
    fig.text(.045, .952, "Label sensitivity across the full endpoint panel",
             fontsize=17, weight="bold")
    fig.text(.045, .912,
             "Five endpoints at none reasoning; Astra at low is shown separately. "
             "Canonical: 32 calls per arm. Coded: 128.", fontsize=10.2)
    handles = [
        Line2D([0], [0], color=INK, lw=1.5, label="95% Newcombe reference envelope"),
        Line2D([0], [0], color=INK, lw=5, label="Feasible missing-action bounds"),
        Line2D([0], [0], color=INK, marker="o", lw=0, ms=5,
               label="Fully observed difference"),
    ]
    fig.legend(handles=handles, loc="lower left", bbox_to_anchor=(.04, .072),
               ncol=2, frameon=False, fontsize=9.4, columnspacing=2.5)
    fig.text(.045, .038,
             "Intervals are nominal independent-binomial references, not task-population "
             "coverage; all feasible missing actions are retained.", fontsize=9)
    save(fig, "figure-label-contrasts", preview)


def key_actions(preview: bool) -> None:
    report = read_report("runs/label-protection-v1/report.json")
    if report["missing_responses"] != 0:
        raise ValueError("Key action figure needs an explicit missing segment if data change")
    categories = [
        ("protected", "#257E78", "Keyed retry: protected"),
        ("unprotected", "#CE8244", "Keyed retry: unprotected"),
        ("retry", "#AD3D49", "Raw retry"),
        ("unresolved", "#DCE2E7", "Unresolved"),
    ]
    fig, ax = plt.subplots(figsize=(11.8, 7.7))
    fig.subplots_adjust(left=.26, right=.94, top=.82, bottom=.23)
    positions, labels = [], []
    for index, (model, display) in enumerate(MODELS[2:5]):
        for offset, (protection, name) in enumerate([
            ("valid", "Valid original key"),
            ("none", "Original key omitted"),
            ("changed", "Changed key"),
        ]):
            y = index * 3.65 + offset
            actions = Counter()
            planned = 0
            for condition, row in report["conditions"].items():
                if condition.startswith(model + "/") and condition.endswith("/" + protection):
                    actions.update(row["actions"])
                    planned += row["planned_responses"]
            if planned != 80 or sum(actions.values()) != 80:
                raise ValueError("Expected four complete 20-response key cells")
            if set(actions) - {"retry_with_key", "retry", "unresolved"}:
                raise ValueError("Unexpected action: extend the figure's explicit categories")
            counts = {
                "protected": actions["retry_with_key"] if protection == "valid" else 0,
                "unprotected": actions["retry_with_key"] if protection != "valid" else 0,
                "retry": actions["retry"], "unresolved": actions["unresolved"],
            }
            left = 0
            for category, color, _ in categories:
                count = counts[category]
                if not count:
                    continue
                ax.barh(y, count, left=left, height=.68, color=color,
                        edgecolor="white", linewidth=.75, zorder=3)
                if count >= 5:
                    ax.text(left + count / 2, y, str(count), ha="center", va="center",
                            color=INK if category == "unresolved" else "white",
                            fontsize=10.5, weight="bold", zorder=4)
                elif category == "retry":
                    ax.annotate(f"{count} raw retry", xy=(left + count / 2, y),
                                xytext=(8, y - .54), fontsize=10, color=color,
                                arrowprops={"arrowstyle": "-", "color": color, "lw": .9},
                                va="center", zorder=5)
                else:
                    ax.annotate(str(count), xy=(left + count / 2, y),
                                xytext=(83, y), va="center", fontsize=10,
                                arrowprops={"arrowstyle": "-", "color": "#798791", "lw": .9},
                                zorder=5)
                left += count
            positions.append(y)
            labels.append(f"{display}  /  {name}")
    ax.set_yticks(positions, labels)
    ax.tick_params(axis="y", length=0, pad=12, labelsize=9.6)
    ax.set_xlim(0, 86)
    ax.set_xticks(range(0, 81, 20))
    ax.set_ylim(-.8, 10.1)
    ax.invert_yaxis()
    ax.xaxis.grid(True, color="#E5E9EC", lw=.7)
    ax.set_axisbelow(True)
    ax.set_xlabel("Responses (80 per row)", labelpad=12)
    fig.text(.045, .95, "Key choices separate protected recovery from unsupported retry",
             fontsize=16.3, weight="bold")
    fig.text(.045, .906,
             "Three GPT-5.6 endpoints at none reasoning; each row pools the four "
             "label × lookup-semantics cells.", fontsize=10.3)
    fig.legend(handles=[Patch(facecolor=color, label=label)
                        for _, color, label in categories],
               loc="lower left", bbox_to_anchor=(.04, .087), ncol=2,
               frameon=False, fontsize=10, columnspacing=3)
    fig.text(.045, .044,
             "Only replay with the valid original key is protected. Omitted or changed "
             "keys do not deduplicate the original operation.", fontsize=9.3)
    save(fig, "figure-key-actions", preview)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--preview", action="store_true", help="Also save PNG previews")
    args = parser.parse_args()
    configure()
    label_contrasts(args.preview)
    key_actions(args.preview)
    print("Wrote two deterministic result SVGs" + (" and PNG previews." if args.preview else "."))


if __name__ == "__main__":
    main()
