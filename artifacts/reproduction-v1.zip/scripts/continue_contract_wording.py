"""Outcome-blind transport amendment: retain missing attempts, never replace them."""
from __future__ import annotations
import hashlib
import json
import subprocess
import sys
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

from retrybench.current_models import REQUEST_OVERHEAD_BYTES, score_case
from retrybench.openai_adapter import CostBudget, OpenAIResponsesPolicy, maximum_decision_cost
from retrybench.serialization import canonical_json_sha256, read_json_object, read_jsonl, write_json, write_jsonl


def main():
    protocol_dir = Path('protocol/contract-wording-v2')
    output = Path('runs/contract-wording-v2')
    manifest = read_jsonl(protocol_dir / 'manifest.jsonl')
    protocol = read_json_object(protocol_dir / 'protocol.json')
    provenance = read_json_object(output / 'collection-provenance.json')
    if canonical_json_sha256(manifest) != protocol['manifest_sha256'] or canonical_json_sha256(protocol) != provenance['protocol_sha256']:
        raise ValueError('frozen protocol mismatch')
    for name, digest in provenance['source_sha256'].items():
        if hashlib.sha256((Path('src/retrybench') / name).read_bytes()).hexdigest() != digest:
            raise ValueError('collection implementation changed')
    original = read_jsonl(output / 'private/requests.jsonl')
    if len(original) != 171 or sum(r['status'] == 'complete' for r in original) != 170 or original[-1]['error_type'] != 'timeout':
        raise ValueError('amendment requires the reviewed 170-complete/one-timeout state')
    attempted = {r['case_id'] for r in original}
    remaining = [c for c in manifest if c['case_id'] not in attempted]
    amendment_path = protocol_dir / 'amendment-1.json'
    specification = {
        'schema_version': 'retrybench-contract-wording-transport-amendment-1',
        'manifest_sha256': protocol['manifest_sha256'],
        'original_collection_provenance_sha256': canonical_json_sha256(provenance),
        'continuation_code_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'reason': 'Transport timeout with no returned provider metadata after 170 completed responses. No actions inspected before this amendment.',
        'original_completed_responses': 170,
        'retained_missing_case_ids': [original[-1]['case_id']],
        'remaining_case_ids_in_order': [c['case_id'] for c in remaining],
        'transport_timeout_seconds_before': 90, 'transport_timeout_seconds_after': 300,
        'policy': 'Continue only unattempted frozen cases; never replace the missing response. Stop on any further failure. Preserve original prompts, settings, order, scorer, and contrasts.',
        'analysis': 'Report original fixed denominators, missing-action bounds, known costs and unknown-cost reserve. This is an amended collection, not completion of original frozen v2.',
        'cost_cap_usd_including_unknown_reserve': 20,
    }
    if amendment_path.exists():
        amendment = read_json_object(amendment_path)
        if {k:v for k,v in amendment.items() if k != 'recorded_at_utc'} != specification:
            raise ValueError('amendment changed')
    else:
        amendment = {**specification, 'recorded_at_utc': datetime.now(timezone.utc).isoformat()}
        write_json(amendment_path, amendment)
    amendment_hash = canonical_json_sha256(amendment)
    journal = output / 'private/continuation-requests.jsonl'
    continuation = read_jsonl(journal) if journal.exists() else []
    for record in continuation:
        if record['status'] != 'complete' or record.get('amendment_sha256') != amendment_hash:
            raise ValueError('failed or mismatched continuation record; review required')
    if len({r['case_id'] for r in continuation}) != len(continuation) or not {r['case_id'] for r in continuation} <= {c['case_id'] for c in remaining}:
        raise ValueError('unexpected continuation records')
    failed_case = next(c for c in manifest if c['case_id'] == original[-1]['case_id'])
    unknown_reserve = maximum_decision_cost(failed_case['requested_model'], failed_case['instructions'], failed_case['prompt'] + ' ' * REQUEST_OVERHEAD_BYTES, failed_case['max_output_tokens'])
    budget = CostBudget(20)
    budget.spent_usd = unknown_reserve + sum(r['decision']['cost_usd'] for r in original + continuation if r['status'] == 'complete')
    pending = output / 'private/continuation-pending.json'
    if pending.exists():
        raise ValueError('ambiguous continuation attempt; review required')
    key = subprocess.run(['/usr/bin/security','find-generic-password','-a','retrybench','-s','retrybench-openai-api-key','-w'], capture_output=True, timeout=25)
    if key.returncode or not key.stdout.strip():
        raise ValueError('Keychain lookup failed')
    def transport(api_key, payload):
        request = urllib.request.Request('https://api.openai.com/v1/responses', data=json.dumps(payload).encode(), headers={'Authorization':'Bearer '+api_key,'Content-Type':'application/json'}, method='POST')
        with urllib.request.urlopen(request, timeout=300) as response:
            return json.loads(response.read())
    policy = OpenAIResponsesPolicy(model='gpt-5.6-sol', max_output_tokens=1024, reasoning_effort='none', strict_response_metadata=True, api_key=key.stdout.decode().strip(), transport=transport)
    del key
    completed = {r['case_id'] for r in continuation}
    print('Continuing 261 unattempted cases under recorded amendment; one missing response retained.', flush=True)
    for case in remaining:
        if case['case_id'] in completed:
            continue
        budget.reserve_request(policy.model, case['instructions']+'\n'+case['prompt']+' '*REQUEST_OVERHEAD_BYTES, 1024)
        record = {'case_id':case['case_id'], 'manifest_sha256':protocol['manifest_sha256'], 'collection_provenance_sha256':canonical_json_sha256(provenance), 'amendment_sha256':amendment_hash, 'collected_at_utc':datetime.now(timezone.utc).isoformat()}
        write_json(pending, record)
        try:
            record.update(status='complete', decision=policy.decide_text(case['instructions'],case['prompt'],budget).to_dict(), provider_metadata=policy.last_response_metadata)
        except Exception as exc:
            record.update(status='failed', error_type=type(exc).__name__, cost_may_be_unknown=True, provider_metadata=policy.last_response_metadata)
            with journal.open('a') as handle:handle.write(json.dumps(record,sort_keys=True)+'\n')
            print('Further failure; continuation halted: '+type(exc).__name__, flush=True)
            return 1
        with journal.open('a') as handle:handle.write(json.dumps(record,sort_keys=True)+'\n')
        pending.unlink()
        continuation.append(record)
    policy.api_key = None
    complete = {r['case_id']:r for r in original+continuation if r['status']=='complete'}
    public = []
    for case in manifest:
        if case['case_id'] not in complete:continue
        record = complete[case['case_id']]
        public.append({k:record[k] for k in ('case_id','manifest_sha256','collection_provenance_sha256','collected_at_utc')} | {'amendment_sha256':record.get('amendment_sha256'), 'provider_status':record['provider_metadata']['status'], 'decision':{k:v for k,v in record['decision'].items() if k!='response_id'}})
    write_jsonl(output/'requests.jsonl',public)
    decisions = {r['case_id']:r['decision'] for r in public}
    rows = [row for case in manifest if case['case_id'] in decisions for row in score_case(case,decisions[case['case_id']])]
    write_jsonl(output/'outcomes.jsonl',rows)
    write_json(output/'analysis.json',{'complete':False,'amended_collection':True,'attempted_all_manifest_cases':True,'manifest_sha256':protocol['manifest_sha256'],'amendment_sha256':amendment_hash,'planned_calls':len(manifest),'observed_responses':len(public),'missing_case_ids':[failed_case['case_id']],'scored_observed_outcomes':len(rows),'known_cost_usd':sum(r['decision']['cost_usd'] for r in public),'unknown_cost_upper_reserve_usd':unknown_reserve,'reason':'One unreturned transport-timeout response retained as missing; no replacement.'})
    print('Amended collection finished: 431 observed responses, 1 missing; no replacements.',flush=True)
    return 0


if __name__ == '__main__':
    try:sys.exit(main())
    except Exception as exc:
        print('Stopped safely: '+type(exc).__name__,flush=True)
        sys.exit(1)
