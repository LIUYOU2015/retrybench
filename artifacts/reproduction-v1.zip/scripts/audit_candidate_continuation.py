"""Validate the quota continuation and its combined diagnostic/study budget."""
import hashlib
from pathlib import Path
from retrybench.serialization import canonical_json_sha256,read_json_object,read_jsonl,write_json
ROOT=Path(__file__).resolve().parents[1]

def audit():
    pd=ROOT/'protocol/candidate-presence-v1';rd=ROOT/'runs/candidate-presence-v1'
    a=read_json_object(pd/'quota-continuation.json');p=read_json_object(pd/'protocol.json')
    c=read_json_object(rd/'collection-summary.json');r=read_json_object(rd/'report.json')
    requests=read_jsonl(rd/'requests.jsonl');byid={x['case_id']:x for x in requests}
    sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
    assert a['original_protocol_sha256']==canonical_json_sha256(p)==c['protocol_sha256']
    assert canonical_json_sha256(a)==c['continuation_amendment_sha256']
    assert a['continuation_code_sha256']==sha(ROOT/'scripts/resume_candidate_presence.py')==sha(rd/'collection-code/resume_candidate_presence.py')
    assert a['diagnostic_sha256']==sha(rd/'diagnostic.json')
    assert len(byid)==len(requests)==c['attempted']==r['attempted_requests']
    assert len(a['retained_failures'])==3
    assert all(byid[x['case_id']]==x for x in a['retained_failures'])
    assert c['pending_reserved_usd']==0 and not list((rd/'private').glob('pending-*.json'))
    known=sum(x.get('cost_usd',0) for x in requests)
    unknown=sum(x.get('unknown_cost_upper_reserve_usd',0) for x in requests)
    diagnostic=read_json_object(rd/'diagnostic.json')['unknown_cost_upper_reserve_usd']
    assert diagnostic==a['diagnostic_reserve_usd']==c['diagnostic_reserve_usd']
    assert known+unknown+diagnostic<=a['combined_cap_usd']==p['cap_usd']==1.0
    assert abs(known-c['known_cost_usd'])<1e-9 and abs(unknown-c['unknown_cost_upper_reserve_usd'])<1e-9
    assert r['observed_responses']==c['complete']
    return dict(passed=True,attempted=len(requests),planned=c['planned'],responses=c['complete'],retained_original_failures=3,
      known_cost_usd=known,unknown_study_reserve_usd=unknown,diagnostic_reserve_usd=diagnostic,
      combined_usage_estimate_plus_reserves_usd=known+unknown+diagnostic,cap_usd=1.0,
      files_sha256={str(x.relative_to(ROOT)):sha(x) for x in (pd/'protocol.json',pd/'quota-continuation.json',rd/'requests.jsonl',rd/'diagnostic.json',rd/'report.json',ROOT/'scripts/resume_candidate_presence.py',Path(__file__))})

if __name__=='__main__':
    report=audit();write_json(ROOT/'runs/candidate-presence-v1/continuation-audit.json',report);print(report)
