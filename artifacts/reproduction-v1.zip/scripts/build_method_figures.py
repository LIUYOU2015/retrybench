"""Generate editable standalone SVG method diagrams without a TeX toolchain."""
from html import escape
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

def canvas(width,height,title):
    return [f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}" role="img" aria-label="{escape(title)}">', '<rect width="100%" height="100%" fill="white"/>', '<defs><marker id="arrow" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8 Z" fill="#526477"/></marker></defs>', '<style>text{font-family:Arial,sans-serif;fill:#172b3a;font-size:18px}.edge{fill:none;stroke:#526477;stroke-width:2;marker-end:url(#arrow)}</style>']

def box(parts,x,y,w,h,lines,fill='#eef4f8'):
    parts.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="8" fill="{fill}" stroke="#678095" stroke-width="1.5"/>')
    start=y+h/2-(len(lines)-1)*12
    for i,line in enumerate(lines):parts.append(f'<text x="{x+w/2}" y="{start+i*24}" text-anchor="middle" dominant-baseline="middle">{escape(line)}</text>')

def edge(parts,x1,y1,x2,y2):
    mid=(x1+x2)/2
    parts.append(f'<path class="edge" d="M{x1},{y1} C{mid},{y1} {mid},{y2} {x2},{y2}"/>')

def save(name,parts):
    p=ROOT/'paper/generated'/name;p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text('\n'.join(parts+['</svg>'])+'\n')

p=canvas(1260,410,'One weak observation, three hidden worlds, different retry outcomes')
for x,title in ((140,'Shared observation'),(570,'Hidden execution world'),(1045,'If retried without protection')):
    p.append(f'<text x="{x}" y="27" text-anchor="middle" font-weight="bold">{title}</text>')
box(p,25,172,230,90,['Timeout','Weak NOT_FOUND'])
worlds=[(60,['Terminal non-execution']), (175,['Original still in flight']), (290,['Committed effect','hidden by stale visibility'])]
for y,lines in worlds:
    edge(p,255,217,380,y+45);box(p,380,y,380,90,lines)
    edge(p,760,y+45,875,y+45)
box(p,875,60,340,90,['One intended effect','but the weak read did not','establish retry permission'],'#fff4df')
box(p,875,175,340,90,['Retry commits, then original','commits: duplicate effects'],'#fcebea')
box(p,875,290,340,90,['Original already committed;','retry adds a duplicate'],'#fcebea')
save('figure-hidden-worlds.svg',p)

p=canvas(1420,430,'One response replayed across three hidden schedules and scored against effect ledgers')
box(p,20,160,220,90,['One model-visible case','(fixed transcript)'])
edge(p,240,205,295,205);box(p,295,160,220,90,['One model response'])
for y,lines in [(45,['Terminal non-execution']),(160,['In-flight late commit']),(275,['Stale negative read'])]:
    edge(p,515,205,600,y+45);box(p,600,y,240,90,lines)
    edge(p,840,y+45,920,205)
box(p,920,160,220,90,['Ground-truth','effect ledgers'])
edge(p,1140,205,1180,205);box(p,1180,160,220,90,['Permission and','exact-state scorer'])
p.append('<path class="edge" d="M1290,250 L1290,290"/>')
box(p,1180,290,220,105,['Safety and','one-decision','outcome metrics'])
p.append('<text x="530" y="405" text-anchor="middle">Shared outcomes are counterfactual replays, not additional model calls.</text>')
save('figure-response-replay.svg',p)
print('Generated two standalone method figures.')
