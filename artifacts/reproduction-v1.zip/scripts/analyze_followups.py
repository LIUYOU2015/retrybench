"""Recompute fixed-denominator follow-up reports without model access."""
from __future__ import annotations
import argparse,hashlib,importlib.util,sys
from collections import Counter
from pathlib import Path
from retrybench.serialization import canonical_json_sha256,read_json_object,read_jsonl,write_json,write_jsonl
METRICS=('false_retry_permission','duplicates','omissions','unresolved','ledger_correct','resolved_exact_state','protected_recovery')

def analyze(study):
    pd=Path('protocol')/study;rd=Path('runs')/study
    protocol=read_json_object(pd/'protocol.json');manifest=read_jsonl(pd/'manifest.jsonl');requests=read_jsonl(rd/'requests.jsonl');summary=read_json_object(rd/'collection-summary.json')
    if not summary['attempted_all_manifest_cases'] or len(requests)!=len(manifest):raise ValueError('study incomplete; no complete-study report')
    if canonical_json_sha256(manifest)!=protocol['manifest_sha256'] or summary['protocol_sha256']!=canonical_json_sha256(protocol):raise ValueError('manifest/protocol mismatch')
    if [r['case_id'] for r in requests]!=[c['case_id'] for c in manifest]:raise ValueError('request order mismatch')
    code=rd/'collection-code/followup_studies.py'
    if hashlib.sha256(code.read_bytes()).hexdigest()!=protocol['implementation_sha256']:raise ValueError('implementation mismatch')
    spec=importlib.util.spec_from_file_location('followup_frozen',code);f=importlib.util.module_from_spec(spec);spec.loader.exec_module(f)
    from retrybench import model
    source=Path(model.__file__).parent
    for name,digest in protocol['source_sha256'].items():
        if hashlib.sha256((source/name).read_bytes()).hexdigest()!=digest:raise ValueError('Use preserved collection-source; source mismatch')
    observed={};missing=[]
    for c,r in zip(manifest,requests):
        if r['protocol_sha256']!=canonical_json_sha256(protocol) or r['collected_at_utc']<protocol['recorded_at_utc']:raise ValueError('request provenance mismatch')
        if r['status']=='complete':
            if r['provider_status']!='completed' or r['decision']['action'] not in c['allowed_actions']:raise ValueError('invalid completed response')
            if r['returned_model']!=c['requested_model'] and not r['returned_model'].startswith(c['requested_model']+'-'):raise ValueError('model mismatch')
            observed[c['case_id']]=r['decision']['action']
        elif r['status'] in ('transport_timeout','incomplete','invalid_output'):missing.append(c['case_id'])
        else:raise ValueError('unexpected failure needs amendment')
    known=sum(r.get('cost_usd',0) for r in requests);unknown=sum(r.get('unknown_cost_upper_reserve_usd',0) for r in requests)
    if abs(known-summary['known_cost_usd'])>1e-9 or abs(unknown-summary['unknown_cost_upper_reserve_usd'])>1e-9 or known+unknown>protocol['cap_usd']+1e-9:raise ValueError('cost mismatch')
    if len(observed)!=summary['observed_responses'] or len(missing)!=summary['missing_responses']:raise ValueError('completion counts mismatch')
    possibilities={c['case_id']:[f.score(c,a) for a in ([observed[c['case_id']]] if c['case_id'] in observed else c['allowed_actions'])] for c in manifest}
    def metric_value(row,metric):
        return int(row['action']=='retry_with_key') if metric=='keyed_action_selected' else row[metric]
    def rate_bounds(cases,metric='false_retry_permission',schedule_filter=None):
        sums=[0,0];den=0
        for c in cases:
            versions=[[r for r in rows if schedule_filter is None or r['schedule'] in schedule_filter] for rows in possibilities[c['case_id']]]
            values=[sum(metric_value(r,metric) for r in rows) for rows in versions]
            den+=len(versions[0]);sums[0]+=min(values);sums[1]+=max(values)
        return [s/den for s in sums] if den else None
    conditions={};allrows=[]
    for condition in sorted({c['condition'] for c in manifest}):
        cases=[c for c in manifest if c['condition']==condition];returned=[c for c in cases if c['case_id'] in observed];rows=[r for c in returned for r in possibilities[c['case_id']][0]];allrows+=rows
        states={}
        for state in sorted({c['observed_state'] for c in cases}):
            cell=[c for c in cases if c['observed_state']==state]
            states[state]={'planned_responses':len(cell),'observed_responses':sum(c['case_id'] in observed for c in cell),'actions':dict(Counter(observed[c['case_id']] for c in cell if c['case_id'] in observed))}
        bounds={}
        for metric in METRICS:
            pairs=[[sum(r[metric] for r in option) for option in possibilities[c['case_id']]] for c in cases]
            bounds[metric]=[sum(min(v) for v in pairs),sum(max(v) for v in pairs)]
        conditions[condition]={'planned_responses':len(cases),'observed_responses':len(returned),'missing_responses':len(cases)-len(returned),'actions':dict(Counter(observed[c['case_id']] for c in returned)),'observed_outcomes':len(rows),'outcomes':{k:sum(r[k] for r in rows) for k in METRICS},'fixed_denominator_outcome_bounds':bounds,'frp_rate_bounds':rate_bounds(cases),'terminal_progress_rate_bounds':rate_bounds(cases,'resolved_exact_state',['fail_before_execution']),'state_responses':states}
    comparisons=[]
    if study==f.BRIDGE:
        sol='gpt-5.6-sol/none/weak'
        for right in ('gpt-5.6-sol/low/weak','gpt-5.4-mini-2026-03-17/none/weak','gpt-5.4-2026-03-05/none/weak'):comparisons.append((sol+' minus '+right,sol,right,'false_retry_permission'))
    else:
        for model in sorted({c['requested_model'] for c in manifest}):
            comparisons.append((model+'/label_removal',model+'/unlabeled/unstated/none',model+'/labeled/unstated/none','false_retry_permission'))
            for label in ('labeled','unlabeled'):
                comparisons.append((model+'/'+label+'/semantics_added',model+'/'+label+'/stated/none',model+'/'+label+'/unstated/none','false_retry_permission'))
                for semantics in ('unstated','stated'):
                    comparisons.append((model+'/'+label+'/'+semantics+'/valid_minus_changed_keyed_selection',model+'/'+label+'/'+semantics+'/valid',model+'/'+label+'/'+semantics+'/changed','keyed_action_selected'))
                    comparisons.append((model+'/'+label+'/'+semantics+'/valid_minus_changed_progress',model+'/'+label+'/'+semantics+'/valid',model+'/'+label+'/'+semantics+'/changed','protected_recovery'))
    contrasts={}
    for name,left,right,metric in comparisons:
        family=[]
        for task in sorted({c['task_id'] for c in manifest}):
            lo,hi=rate_bounds([c for c in manifest if c['task_id']==task and c['condition']==left],metric)
            rlo,rhi=rate_bounds([c for c in manifest if c['task_id']==task and c['condition']==right],metric)
            family.append({'task_id':task,'effect_bounds':[lo-rhi,hi-rlo]})
        contrasts[name]={'left':left,'right':right,'metric':metric,'mean_effect_bounds':[sum(t['effect_bounds'][i] for t in family)/len(family) for i in (0,1)],'task_effects':family}
    temporal={}
    if study==f.BRIDGE:
        for folder,modelname in [('confirmation-v2','gpt-5.4-mini-2026-03-17'),('gpt54-replication-v1','gpt-5.4-2026-03-05')]:
            archived=list({r['response_group_id']:r for r in read_jsonl(Path('runs')/folder/'sanitized-outcomes.jsonl') if r['evidence']=='weak' and r['prompt_condition']=='neutral'}.values());families=[]
            for task in sorted({c['task_id'] for c in manifest}):
                old=[r for r in archived if r['task_id']==task];historical=sum(r['decision']['action']=='retry' for r in old)/len(old)
                new=rate_bounds([c for c in manifest if c['task_id']==task and c['condition']==modelname+'/none/weak'])
                families.append({'task_id':task,'historical_rate':historical,'current_rate_bounds':new,'difference_bounds':[x-historical for x in new]})
            temporal[modelname]={'historical_responses':len(archived),'historical_retry_responses':sum(r['decision']['action']=='retry' for r in archived),'mean_difference_bounds':[sum(t['difference_bounds'][i] for t in families)/len(families) for i in (0,1)],'task_effects':families}
    report={'schema_version':'retrybench-followup-report-v1','study':study,'planned_requests':len(manifest),'observed_responses':len(observed),'missing_responses':len(missing),'planned_outcomes':sum(len(c['schedules']) for c in manifest),'observed_outcomes':len(allrows),'known_cost_usd':known,'unknown_cost_upper_reserve_usd':unknown,'first_request_utc':requests[0]['collected_at_utc'],'last_request_utc':requests[-1]['collected_at_utc'],'missing_cases':[{'case_id':c['case_id'],'condition':c['condition'],'task_id':c['task_id'],'repetition':c['repetition'],'status':r['status']} for c,r in zip(manifest,requests) if c['case_id'] in missing],'conditions':conditions,'contrasts':contrasts,'historical_comparisons':temporal,'interpretation':'Descriptive fixed-task effects. Bounds enumerate allowed missing actions within each response, preserve shared-world dependence and planned denominators; marginal bounds cannot be freely combined. No task-population or latent-reasoning inference. Temporal non-replication is not proof of changed weights.','provenance':{'protocol_sha256':canonical_json_sha256(protocol),'implementation_sha256':protocol['implementation_sha256'],'requests_file_sha256':hashlib.sha256((rd/'requests.jsonl').read_bytes()).hexdigest()}}
    return report,allrows

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('study');args=ap.parse_args();report,rows=analyze(args.study)
    root=Path('runs')/args.study;write_json(root/'report.json',report);write_jsonl(root/'outcomes.jsonl',rows);print('Verified '+args.study+' report and outcomes.')
