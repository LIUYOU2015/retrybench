"""Create copyable, source-derived tables from a verified two-model report."""
from pathlib import Path
from retrybench.serialization import read_json_object


def generate(report):
    lines=['# Two-model report tables','', 'Counts below are observed unless explicitly marked planned. Bounds retain planned denominators and are not confidence intervals.','']
    lines += ['| Model | Prompt package | Weak responses | Weak forbidden retries/outcomes | Authoritative responses | Authoritative forbidden retries/outcomes | Correct terminal retries/observed |', '|---|---|---:|---:|---:|---:|---:|']
    for model in report['requested_models']:
        for mode in ('label_only','explicit_contract','explicit_contract_cautious'):
            weak=report['conditions'][model+'/'+mode+'/weak'];auth=report['conditions'][model+'/'+mode+'/authoritative']
            w=weak['observed_common_forbidden'];a=auth['observed_common_forbidden'];terminal=auth['state_responses']['not_executed']
            lines.append('| %s | %s | %d/%d | %d/%d | %d/%d | %d/%d | %d/%d |' % (model,mode,weak['observed_responses'],weak['planned_responses'],w['false_retry_permission'],w['outcomes'],auth['observed_responses'],auth['planned_responses'],a['false_retry_permission'],a['outcomes'],terminal['observed_actions'].get('retry',0),terminal['observed_responses']))
    lines += ['', '| Model/package/interface | Outcomes | FRP | Duplicates | Omissions | Unresolved | Correct ledger | Resolved exact state |', '|---|---:|---:|---:|---:|---:|---:|---:|']
    for name,cell in sorted(report['conditions'].items()):
        v=cell['observed_outcomes']
        lines.append('| '+name+' | '+' | '.join(str(v[k]) for k in ('outcomes','false_retry_permission','duplicates','omissions','unresolved','ledger_correct','resolved_exact_state'))+' |')
    lines += ['', '| Contrast | Estimand | Fixed-denominator effect bounds |','|---|---|---:|']
    for name,c in sorted(report['contrasts'].items()):
        lo,hi=c['missing_action_mean_bounds'];lines.append('| %s | %s | [%.6f, %.6f] |' % (name,c['estimand'],lo,hi))
    lines += ['', '## All family effect bounds','']
    for name,c in sorted(report['contrasts'].items()):
        lines += ['### '+name,'', '| Family | Difference bounds |', '|---|---:|']
        by_family={}
        for effects in c['family_effects_by_missing_action'].values():
            for effect in effects:by_family.setdefault(effect['family_id'],[]).append(effect['difference'])
        for family,values in sorted(by_family.items()):lines.append('| %s | [%.6f, %.6f] |' % (family,min(values),max(values)))
        lines.append('')
    lines += ['## State-level responses and observed outcomes','', '| Condition/state | Observed/planned responses | Retry | Stop | Wait | Unresolved responses | Duplicate outcomes | Omission outcomes | Correct ledgers |', '|---|---:|---:|---:|---:|---:|---:|---:|---:|']
    for name,cell in sorted(report['conditions'].items()):
        for state,v in sorted(cell['state_responses'].items()):
            a=v['observed_actions'];o=v['observed_outcomes']
            lines.append('| %s/%s | %d/%d | %d | %d | %d | %d | %d | %d | %d |' % (name,state,v['observed_responses'],v['planned_responses'],a.get('retry',0),a.get('stop',0),a.get('wait',0),a.get('unresolved',0),o['duplicates'],o['omissions'],o['ledger_correct']))
    return '\n'.join(lines)+'\n'


if __name__=='__main__':
    root=Path('runs/current-models-v1')
    (root/'tables.md').write_text(generate(read_json_object(root/'report.json')))
    print('Generated tables from verified report.')
