"""Recompute the five-arm study cost from its nested historical request schema."""
import hashlib
from pathlib import Path
from retrybench.serialization import read_jsonl,read_json_object,write_json

def analyze():
    path=Path('runs/contract-wording-v2/requests.jsonl');rs=read_jsonl(path);cost=0
    for r in rs:
        u=r['decision']['usage'];value=((u['input_tokens']-u['cached_input_tokens'])*4+u['cached_input_tokens']*.4+u['output_tokens']*20)/1e6
        if abs(value-r['decision']['cost_usd'])>1e-12:raise ValueError('request cost mismatch')
        cost+=value
    report=read_json_object(Path('runs/contract-wording-v2/report.json'))
    if abs(cost-report['known_cost_usd'])>1e-9:raise ValueError('report cost mismatch')
    return {'schema_version':'retrybench-five-arm-cost-audit-v1','observed_requests':len(rs),'usage_path':'requests.jsonl[*].decision.usage','per_request_cost_path':'requests.jsonl[*].decision.cost_usd','frozen_rates_per_million':{'input':4,'cached_input':.4,'output':20},'recomputed_known_cost_usd':cost,'reported_known_cost_usd':report['known_cost_usd'],'unknown_cost_upper_reserve_usd':report['unknown_cost_upper_reserve_usd'],'known_plus_reserved_usd':cost+report['unknown_cost_upper_reserve_usd'],'interpretation':'Usage-price calculation, not an invoice. Timeout charges are unknown and kept separate; no model calls made.','requests_sha256':hashlib.sha256(path.read_bytes()).hexdigest()}

if __name__=='__main__':
    p=Path('runs/cost-audit-v1');p.mkdir(exist_ok=True);write_json(p/'report.json',analyze());print('Verified 430 nested usage records and five-arm cost.')
