"""Render follow-up tables from validated reports; never query a model."""
from pathlib import Path
from collections import Counter
from retrybench.serialization import read_json_object

def table(headers, rows):
    return '\n'.join(['| '+' | '.join(headers)+' |','| '+' | '.join(['---']*len(headers))+' |']+['| '+' | '.join(map(str,r))+' |' for r in rows])+'\n'

def render():
    root=Path('runs');control=read_json_object(root/'label-protection-v1/report.json');bridge=read_json_object(root/'historical-bridge-v1/report.json');rationale=read_json_object(root/'rationale-coding-v1/report.json')
    models=['gpt-5.6-sol','gpt-5.6-terra','gpt-5.6-luna'];brief=[];outcome=[]
    for model in models:
        groups={p:[v for k,v in control['conditions'].items() if k.startswith(model+'/') and k.endswith('/'+p)] for p in ('none','valid','changed')}
        acts={p:Counter() for p in groups}
        for p,cs in groups.items():
            for c in cs:acts[p].update(c['actions'])
        brief.append([model, str(acts['valid']['retry_with_key'])+'/80',str(acts['none']['retry']+acts['none']['retry_with_key'])+'/80',str(acts['changed']['retry']+acts['changed']['retry_with_key'])+'/80'])
        for p,cs in groups.items():
            sums={m:sum(c['outcomes'][m] for c in cs) for m in cs[0]['outcomes']}
            outcome.append([model,p,240]+[sums[m] for m in ('false_retry_permission','duplicates','omissions','unresolved','ledger_correct','resolved_exact_state')])
    main='### Response decisions\n\n'+table(['Endpoint','Valid same-key retry','Unsupported retry: original omitted key','Unsupported retry: changed key'],brief)+'\n### Realized outcomes\n\n'+table(['Endpoint','Key condition','Outcomes','FRP','Duplicates','Omissions','Unresolved','Ledger correct','Resolved exact'],outcome)
    detailed=[]
    for k,v in control['conditions'].items():
        detailed.append([k,'/'.join(str(v['actions'].get(a,0)) for a in ('retry','retry_with_key','stop','wait','unresolved'))]+[v['outcomes'][m] for m in ('false_retry_permission','duplicates','omissions','unresolved','ledger_correct','resolved_exact_state')])
    detail='# Full response and outcome cells\n\nEach cell has 20 responses and 60 correlated outcomes. Actions are retry / retry_with_key / stop / wait / unresolved.\n\n'+table(['Condition','Actions','FRP','Duplicates','Omissions','Unresolved','Ledger correct','Resolved exact'],detailed)
    contrastrows=[]
    for k,v in control['contrasts'].items():
        contrastrows.append([k]+[f"{t['effect_bounds'][0]:.2f}" for t in v['task_effects']]+[f"{v['mean_effect_bounds'][0]:.2f}"])
    detail+='\n# All four-task effects\n\nAll follow-up responses are observed. Effects are descriptive fixed-task differences, not population estimates.\n\n'+table(['Contrast','CI','Issue','Release','Review','Mean'],contrastrows)
    (root/'label-protection-v1/tables.md').write_text(main+'\n'+detail)
    rows=[]
    for model,effort in [('gpt-5.4-mini-2026-03-17','none'),('gpt-5.4-2026-03-05','none'),('gpt-5.6-sol','none'),('gpt-5.6-sol','low')]:
        w=bridge['conditions'][model+'/'+effort+'/weak'];a=bridge['conditions'][model+'/'+effort+'/authoritative']
        rows.append([model,effort,str(w['actions'].get('retry',0))+'/20',str(a['outcomes']['false_retry_permission'])+'/60','/'.join(str(w['outcomes'][m]) for m in ('duplicates','omissions','unresolved','ledger_correct','resolved_exact_state'))])
    mainbridge=table(['Endpoint','Reasoning','Weak retries','Authoritative unsupported retries','Weak outcomes: D/O/U/L/E (n=60)'],rows)
    taskrows=[]
    for i,task in enumerate(('ci-001','issue-001','release-001','review-001')):
        mini=bridge['historical_comparisons']['gpt-5.4-mini-2026-03-17']['task_effects'][i];full=bridge['historical_comparisons']['gpt-5.4-2026-03-05']['task_effects'][i]
        taskrows.append([task,f"{mini['historical_rate']:.2f}",f"{mini['current_rate_bounds'][0]:.2f}",f"{full['historical_rate']:.2f}",f"{full['current_rate_bounds'][0]:.2f}",'0.00','0.00'])
    mainbridge+='\n'+table(['Task','Mini historical','Mini bridge','5.4 historical','5.4 bridge','Sol none','Sol low'],taskrows)
    rows=[]
    for k,v in bridge['conditions'].items():
        for state,s in v['state_responses'].items():rows.append([k,state,s['observed_responses'],'/'.join(str(s['actions'].get(a,0)) for a in ('retry','stop','wait','unresolved'))])
    mainbridge+='\n### State-level actions\n\n'+table(['Condition','Visible state','Responses','Retry/stop/wait/unresolved'],rows)
    rows=[[k,v['observed_outcomes']]+[v['outcomes'][m] for m in ('false_retry_permission','duplicates','omissions','unresolved','ledger_correct','resolved_exact_state')] for k,v in bridge['conditions'].items()]
    mainbridge+='\n### Complete outcome vectors\n\n'+table(['Condition','Outcomes','FRP','Duplicates','Omissions','Unresolved','Ledger correct','Resolved exact'],rows)
    (root/'historical-bridge-v1/tables.md').write_text(mainbridge)
    rows=[]
    for k,v in rationale['cohorts'].items():
        if not v['responses']:continue
        rows.append([k,v['responses']]+[v['adjudicated_counts'].get(c,0) for c in ('uncertainty','visibility_or_pending','absence_justifies_retry','assumed_protection','duplicate_risk','permission_boundary')])
    (root/'rationale-coding-v1/tables.md').write_text(table(['Cohort/subset','N','Uncertainty','Visibility/pending','Absence supports retry','Assumed protection','Duplicate risk','Permission boundary'],rows))

if __name__=='__main__':render();print('Regenerated follow-up and rationale tables.')
