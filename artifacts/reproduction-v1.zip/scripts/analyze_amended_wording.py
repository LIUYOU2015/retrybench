"""Report the amended semantics block with fixed-denominator missing-action bounds.

No model calls. A missing response is never treated as an observed decision.
All four possible actions are scored jointly across its shared hidden worlds.
"""
from __future__ import annotations
import hashlib
import itertools
import sys
from collections import Counter
from pathlib import Path

from retrybench.current_models import score_case
from retrybench.review_diagnostics import family_statistics
from retrybench.serialization import canonical_json_sha256, read_json_object, read_jsonl, write_json
from retrybench.tmlr_analysis import outcome_summary

CONTRASTS = (('weak_explicit','weak_label'),('authoritative_permuted','authoritative_canonical'),('weak_label','no_evidence'))
METRICS = ('false_retry_permission','duplicates','omissions','unresolved','ledger_correct','resolved_exact_state')


def summarize(rows, arm, common=False):
    return outcome_summary([r for r in rows if r['prompt_mode']==arm and (not common or r['schedule']!='fail_before_execution')])


def family_effects(rows, left, right):
    values = []
    for family in sorted({r['family_id'] for r in rows}):
        rates = {}
        for arm in (left,right):
            cell = [r for r in rows if r['family_id']==family and r['prompt_mode']==arm and r['schedule']!='fail_before_execution']
            rates[arm] = sum(r['false_retry_permission'] for r in cell)/len(cell)
        values.append({'family_id':family,'left':rates[left],'right':rates[right],'difference':rates[left]-rates[right]})
    return values


def analyze(protocol_dir, run_dir):
    manifest=read_jsonl(protocol_dir/'manifest.jsonl')
    protocol=read_json_object(protocol_dir/'protocol.json')
    provenance=read_json_object(run_dir/'collection-provenance.json')
    report=read_json_object(run_dir/'analysis.json')
    amendments=[read_json_object(protocol_dir/name) for name in report.get('amendment_files',['amendment-1.json'])]
    amendment=amendments[-1]
    requests=read_jsonl(run_dir/'requests.jsonl')
    rows=read_jsonl(run_dir/'outcomes.jsonl')
    if not report.get('amended_collection') or not report.get('attempted_all_manifest_cases') or report.get('complete'):
        raise ValueError('requires finished amended collection, not a claimed complete frozen run')
    if canonical_json_sha256(manifest)!=protocol['manifest_sha256'] or canonical_json_sha256(protocol)!=provenance['protocol_sha256'] or canonical_json_sha256(amendment)!=report['amendment_sha256']:
        raise ValueError('protocol/amendment provenance mismatch')
    if amendment['original_collection_provenance_sha256'] != canonical_json_sha256(provenance):
        raise ValueError('amendment original-provenance mismatch')
    for previous,current in zip(amendments,amendments[1:]):
        if current.get('previous_amendment_sha256')!=canonical_json_sha256(previous):
            raise ValueError('amendment chain mismatch')
    scoring_root = Path(sys.modules[score_case.__module__].__file__).resolve().parent
    for name,digest in provenance['source_sha256'].items():
        if hashlib.sha256((scoring_root/name).read_bytes()).hexdigest()!=digest:
            raise ValueError('scoring source mismatch; use the preserved collection-source on PYTHONPATH')
    missing_ids=report['missing_case_ids']
    if not 1<=len(missing_ids)<=2 or set(missing_ids)!=set(amendment['retained_missing_case_ids']):
        raise ValueError('amendment does not cover these missing responses')
    missing_cases=[c for c in manifest if c['case_id'] in missing_ids]
    observed_ids={r['case_id'] for r in requests}
    if len(observed_ids)!=len(requests) or observed_ids != {c['case_id'] for c in manifest}-set(missing_ids):
        raise ValueError('observed/missing requests do not partition fixed manifest')
    for r in requests:
        expected_amendment=None
        for segment in amendments:
            if r['case_id'] in segment['remaining_case_ids_in_order']:
                expected_amendment=canonical_json_sha256(segment)
        if r['provider_status']!='completed' or r['manifest_sha256']!=protocol['manifest_sha256'] or r['collection_provenance_sha256']!=canonical_json_sha256(provenance) or r.get('amendment_sha256')!=expected_amendment:
            raise ValueError('request provenance mismatch')
    expected={(c['case_id'],s) for c in manifest if c['case_id'] in observed_ids for s in c['schedules']}
    actual=[(r['response_group_id'],r['schedule']) for r in rows]
    if len(actual)!=len(set(actual)) or set(actual)!=expected:
        raise ValueError('observed outcome coordinates mismatch')
    decisions={r['case_id']:r['decision'] for r in requests}
    if any(r['decision']!=decisions[r['response_group_id']] for r in rows):
        raise ValueError('observed decision mismatch')
    replayed=[r for case in manifest if case['case_id'] in decisions for r in score_case(case,decisions[case['case_id']])]
    if replayed!=rows:
        raise ValueError('observed scoring replay mismatch')
    scenarios={}
    for actions in itertools.product(('retry','stop','wait','unresolved'),repeat=len(missing_cases)):
        scenarios['/'.join(actions)]=rows+[r for case,action in zip(missing_cases,actions) for r in score_case(case,{'action':action,'rationale':'Missing-action bound only; not observed model output.'})]
    arms={}
    for arm in sorted({c['prompt_mode'] for c in manifest}):
        cases=[c for c in manifest if c['prompt_mode']==arm]
        observed=[c for c in cases if c['case_id'] in decisions]
        states={}
        for state in sorted({c['observed_state'] for c in cases}):
            cell=[c for c in cases if c['observed_state']==state]
            states[state]={'planned_responses':len(cell),'observed_responses':sum(c['case_id'] in decisions for c in cell),'observed_actions':dict(sorted(Counter(decisions[c['case_id']]['action'] for c in cell if c['case_id'] in decisions).items())),'observed_outcomes':outcome_summary([r for r in rows if r['prompt_mode']==arm and r['observed_state']==state])}
        scenario_summaries={a:summarize(sr,arm) for a,sr in scenarios.items()}
        common_summaries={a:summarize(sr,arm,True) for a,sr in scenarios.items()}
        terminal=[c for c in cases if c['evidence']=='authoritative' and c['observed_state']=='not_executed']
        arms[arm]={
            'planned_responses':len(cases),'observed_responses':len(observed),'missing_responses':len(cases)-len(observed),
            'observed_actions':dict(sorted(Counter(decisions[c['case_id']]['action'] for c in observed).items())),
            'observed_outcomes':summarize(rows,arm),'observed_common_forbidden':summarize(rows,arm,True),
            'state_responses':states,
            'planned_outcomes':sum(len(c['schedules']) for c in cases),
            'fixed_denominator_outcome_bounds':{m:[min(s[m] for s in scenario_summaries.values()),max(s[m] for s in scenario_summaries.values())] for m in METRICS},
            'common_forbidden_retry_rate_bounds':[min(s['false_retry_permission']/s['outcomes'] for s in common_summaries.values()),max(s['false_retry_permission']/s['outcomes'] for s in common_summaries.values())],
            'authoritative_terminal_planned_responses':len(terminal),
            'authoritative_terminal_observed_responses':sum(c['case_id'] in decisions for c in terminal),
            'authoritative_terminal_observed_correct_retries':sum(decisions[c['case_id']]['action']=='retry' for c in terminal if c['case_id'] in decisions),
        }
    contrasts={}
    for left,right in CONTRASTS:
        effects={a:family_effects(sr,left,right) for a,sr in scenarios.items()}
        means={a:sum(r['difference'] for r in ef)/len(ef) for a,ef in effects.items()}
        lower,upper=min(means.values()),max(means.values())
        value={'missing_action_mean_bounds':[lower,upper],'family_effects_by_missing_action':effects,'mean_by_missing_action':means}
        first_effects=next(iter(effects.values()))
        if all(ef==first_effects for ef in effects.values()):
            value['fully_observed_contrast']=True
            value['descriptive_family_statistics']=family_statistics([r['difference'] for r in first_effects])
        else:
            value['fully_observed_contrast']=False
        contrasts[left+'_minus_'+right]=value
    return {
        'schema_version':'retrybench-amended-wording-report-v1','status':'Amended collection; original frozen block incomplete.',
        'planned_requests':len(manifest),'observed_responses':len(requests),'missing_responses':len(missing_ids),'planned_outcomes':sum(len(c['schedules']) for c in manifest),'observed_outcomes':len(rows),
        'missing_cases':[{k:c[k] for k in ('case_id','family_id','task_id','lexical_frame','prompt_mode','observed_state','repetition')} for c in missing_cases],
        'interpretation':'Original fixed denominators. Missing-action ranges are worst-case identification bounds, not confidence intervals; four actions are scored jointly across shared schedules. Additional bootstrap/sign diagnostics only for fully observed contrasts; purposive families do not supply population coverage.',
        'requested_models':sorted({c['requested_model'] for c in manifest}),'returned_models':sorted({r['decision']['model'] for r in requests}),
        'first_request_utc':min(r['collected_at_utc'] for r in requests),'last_request_utc':max(r['collected_at_utc'] for r in requests),
        'known_cost_usd':report['known_cost_usd'],'unknown_cost_upper_reserve_usd':report['unknown_cost_upper_reserve_usd'],
        'observed_token_usage':{k:sum(r['decision']['usage'][k] for r in requests) for k in ('input_tokens','cached_input_tokens','output_tokens','reasoning_tokens')},
        'source_hashes':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [protocol_dir/'protocol.json',run_dir/'collection-provenance.json',run_dir/'requests.jsonl',run_dir/'outcomes.jsonl']+[protocol_dir/name for name in report.get('amendment_files',['amendment-1.json'])]},
        'arms':arms,'contrasts':contrasts,
    }


if __name__=='__main__':
    report=analyze(Path('protocol/contract-wording-v2'),Path('runs/contract-wording-v2'))
    write_json(Path('runs/contract-wording-v2/report.json'),report)
    print('Wrote amended report with fixed-denominator missing-action bounds.')
