"""Fixed-denominator analysis of the two-model low-reasoning collection."""
from __future__ import annotations
import hashlib
import itertools
import sys
from collections import Counter
from pathlib import Path

from retrybench.current_models import score_case
from retrybench.review_diagnostics import family_statistics
from retrybench.serialization import canonical_json_sha256, read_json_object, read_jsonl, write_json
from retrybench.tmlr_analysis import outcome_summary

METRICS=('false_retry_permission','duplicates','omissions','unresolved','ledger_correct','resolved_exact_state')


def matches(row,condition):
    return (row['requested_model'],row['prompt_mode'],row['evidence'])==condition


def effects(rows,left,right,common=True):
    result=[]
    for family in sorted({r['family_id'] for r in rows}):
        rates=[]
        for condition in (left,right):
            selected=[r for r in rows if r['family_id']==family and matches(r,condition) and (not common or r['schedule']!='fail_before_execution')]
            rates.append(sum(r['false_retry_permission'] for r in selected)/len(selected))
        result.append({'family_id':family,'left':rates[0],'right':rates[1],'difference':rates[0]-rates[1]})
    return result


def analyze(protocol_dir,run_dir):
    manifest=read_jsonl(protocol_dir/'manifest.jsonl')
    protocol=read_json_object(protocol_dir/'protocol.json')
    policy=read_json_object(protocol_dir/'collection-policy.json')
    summary=read_json_object(run_dir/'collection-summary.json')
    requests=read_jsonl(run_dir/'requests.jsonl')
    rows=read_jsonl(run_dir/'outcomes.jsonl')
    resume=None
    if summary.get('resume_amendment_sha256'):
        resume=read_json_object(protocol_dir/'resume-amendment-1.json')
        if canonical_json_sha256(resume)!=summary['resume_amendment_sha256'] or resume['original_collection_policy_sha256']!=canonical_json_sha256(policy):
            raise ValueError('resume amendment mismatch')
        interrupted_index=next(i for i,c in enumerate(manifest) if c['case_id']==resume['interrupted_case_id'])
        if resume['remaining_case_ids_in_order']!=[c['case_id'] for c in manifest[interrupted_index+1:]]:
            raise ValueError('resume suffix differs from frozen manifest')
    script_root=Path(__file__).resolve().parent
    for name,digest in [('collect_current_models.py',policy.get('collector_sha256')),
                        ('resume_current_models.py',resume.get('resume_collector_sha256') if resume else None)]:
        if digest and hashlib.sha256((script_root/name).read_bytes()).hexdigest()!=digest:
            raise ValueError('collector source mismatch')
    if not summary.get('attempted_all_manifest_cases') or [r['case_id'] for r in requests]!=[c['case_id'] for c in manifest]:
        raise ValueError('all cases must be attempted in frozen order')
    if canonical_json_sha256(manifest)!=protocol['manifest_sha256'] or canonical_json_sha256(protocol)!=policy['protocol_sha256'] or canonical_json_sha256(policy)!=summary['collection_policy_sha256']:
        raise ValueError('protocol/policy mismatch')
    source_root=Path(sys.modules[score_case.__module__].__file__).resolve().parent
    for name,digest in policy['source_sha256'].items():
        if hashlib.sha256((source_root/name).read_bytes()).hexdigest()!=digest:
            raise ValueError('scoring source mismatch; use preserved collection-source')
    for r in requests:
        if r['manifest_sha256']!=protocol['manifest_sha256'] or r['collection_policy_sha256']!=canonical_json_sha256(policy) or r['status'] not in ('complete','transport_timeout','transport_interruption'):
            raise ValueError('request provenance mismatch')
        if r['status']=='transport_interruption' and (resume is None or r['case_id']!=resume['interrupted_case_id']):
            raise ValueError('unreviewed interrupted request')
        if resume is not None:
            after=r['case_id'] in resume['remaining_case_ids_in_order']
            amended=after or r['case_id']==resume['interrupted_case_id']
            if r.get('resume_amendment_sha256')!=(canonical_json_sha256(resume) if amended else None):
                raise ValueError('request resume provenance mismatch')
            if after and r['collected_at_utc']<resume['recorded_at_utc']:
                raise ValueError('resumed request predates amendment')
        if r['status']=='complete' and r['provider_status']!='completed':raise ValueError('incomplete provider response')
    decisions={r['case_id']:r['decision'] for r in requests if r['status']=='complete'}
    missing=[c for c in manifest if c['case_id'] not in decisions]
    if len(missing)>4 or len(missing)!=summary['missing_responses'] or len(decisions)!=summary['observed_responses']:
        raise ValueError('collection exceeds prespecified missing-response policy')
    replayed=[r for c in manifest if c['case_id'] in decisions for r in score_case(c,decisions[c['case_id']])]
    if replayed!=rows:raise ValueError('observed scoring replay mismatch')
    known_cost=sum(r['decision']['cost_usd'] for r in requests if r['status']=='complete')
    unknown_reserve=sum(r.get('unknown_cost_upper_reserve_usd',0) for r in requests)
    if abs(known_cost-summary['known_cost_usd'])>1e-10 or abs(unknown_reserve-summary['unknown_cost_upper_reserve_usd'])>1e-10:
        raise ValueError('cost summary mismatch')
    if known_cost+unknown_reserve>policy.get('cost_cap_usd_including_unknown_reservations',float('inf'))+1e-10:
        raise ValueError('collection exceeded cost cap')
    scenarios={}
    for actions in itertools.product(('retry','stop','wait','unresolved'),repeat=len(missing)):
        scenarios['/'.join(actions) or 'fully_observed']=rows+[r for c,a in zip(missing,actions) for r in score_case(c,{'action':a,'rationale':'Missing-action bound only; not observed.'})]
    conditions={}
    for condition in sorted({(c['requested_model'],c['prompt_mode'],c['evidence']) for c in manifest}):
        cases=[c for c in manifest if matches(c,condition)]
        observed=[c for c in cases if c['case_id'] in decisions]
        selected=[r for r in rows if matches(r,condition)]
        common=[r for r in selected if r['schedule']!='fail_before_execution']
        sums=[outcome_summary([r for r in sr if matches(r,condition)]) for sr in scenarios.values()]
        common_sums=[outcome_summary([r for r in sr if matches(r,condition) and r['schedule']!='fail_before_execution']) for sr in scenarios.values()]
        states={}
        for state in sorted({c['observed_state'] for c in cases}):
            cell=[c for c in cases if c['observed_state']==state]
            states[state]={'planned_responses':len(cell),'observed_responses':sum(c['case_id'] in decisions for c in cell),'observed_actions':dict(sorted(Counter(decisions[c['case_id']]['action'] for c in cell if c['case_id'] in decisions).items())),'observed_outcomes':outcome_summary([r for r in selected if r['observed_state']==state])}
        conditions['/'.join(condition)]={
            'planned_responses':len(cases),'observed_responses':len(observed),'missing_responses':len(cases)-len(observed),
            'observed_actions':dict(sorted(Counter(decisions[c['case_id']]['action'] for c in observed).items())),
            'observed_outcomes':outcome_summary(selected),'observed_common_forbidden':outcome_summary(common),
            'fixed_denominator_outcome_bounds':{m:[min(s[m] for s in sums),max(s[m] for s in sums)] for m in METRICS},
            'common_forbidden_retry_rate_bounds':[min(s['false_retry_permission']/s['outcomes'] for s in common_sums),max(s['false_retry_permission']/s['outcomes'] for s in common_sums)],
            'state_responses':states,
        }
    comparisons=[]
    for model in sorted({c['requested_model'] for c in manifest}):
        for mode in sorted({c['prompt_mode'] for c in manifest}):
            comparisons.append((model+'/'+mode+'/weak_minus_authoritative',(model,mode,'weak'),(model,mode,'authoritative'),'original planned interface contrast',True))
            comparisons.append((model+'/'+mode+'/schedule_weighted/weak_minus_authoritative',(model,mode,'weak'),(model,mode,'authoritative'),'original planned interface contrast',False))
        for mode in ('explicit_contract','explicit_contract_cautious'):
            comparisons.append((model+'/'+mode+'_minus_label_only/weak',(model,mode,'weak'),(model,'label_only','weak'),'additional secondary contrast specified before this block',True))
    contrasts={}
    for name,left,right,status,common in comparisons:
        by_action={a:effects(sr,left,right,common) for a,sr in scenarios.items()}
        means={a:sum(f['difference'] for f in ef)/len(ef) for a,ef in by_action.items()}
        first=next(iter(by_action.values()))
        fully=all(ef==first for ef in by_action.values())
        value={'analysis_status':status,'estimand':'common_forbidden_retry_difference' if common else 'full_schedule_weighted_frp_difference','left_condition':list(left),'right_condition':list(right),'missing_action_mean_bounds':[min(means.values()),max(means.values())],'fully_observed_contrast':fully,'family_effects_by_missing_action':by_action}
        if fully:value['descriptive_family_statistics']=family_statistics([f['difference'] for f in first])
        contrasts[name]=value
    return {
        'schema_version':'retrybench-current-models-report-v1','attempted_all_manifest_cases':True,
        'planned_requests':len(manifest),'observed_responses':len(decisions),'missing_responses':len(missing),'planned_outcomes':sum(len(c['schedules']) for c in manifest),'observed_outcomes':len(rows),
        'missing_cases':[{**{k:c[k] for k in ('case_id','requested_model','prompt_mode','family_id','task_id','repetition','observed_state','evidence','lexical_frame')},'failure_type':next(r['status'] for r in requests if r['case_id']==c['case_id'])} for c in missing],
        'interpretation':'Original fixed denominators; joint missing-action bounds are not confidence intervals. Any family bootstrap/sign summaries are additional descriptive diagnostics over purposive families. Low reasoning is a matched setting, not proof of equal computation. Prompt packages change several instructions together.',
        'requested_models':sorted({c['requested_model'] for c in manifest}),'returned_models':sorted({d['model'] for d in decisions.values()}),
        'first_request_utc':requests[0]['collected_at_utc'],'last_request_utc':requests[-1]['collected_at_utc'],
        'known_cost_usd':known_cost,'unknown_cost_upper_reserve_usd':unknown_reserve,
        'observed_token_usage_by_model':{model:{k:sum(d['usage'][k] for d in decisions.values() if d['model']==model) for k in ('input_tokens','cached_input_tokens','output_tokens','reasoning_tokens')} for model in sorted({d['model'] for d in decisions.values()})},
        'source_hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [protocol_dir/'protocol.json',protocol_dir/'collection-policy.json',run_dir/'collection-summary.json',run_dir/'requests.jsonl',run_dir/'outcomes.jsonl']+([protocol_dir/'resume-amendment-1.json'] if resume else [])},
        'conditions':conditions,'contrasts':contrasts,
    }


if __name__=='__main__':
    report=analyze(Path('protocol/current-models-v1'),Path('runs/current-models-v1'))
    write_json(Path('runs/current-models-v1/report.json'),report)
    print('Wrote verified two-model fixed-denominator report.')
