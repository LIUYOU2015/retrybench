"""Validate independent annotations and summarize retrospective rationale coding."""
from pathlib import Path
from collections import Counter
import hashlib
from retrybench.serialization import read_jsonl, read_json_object, write_json, write_jsonl

CODES = ('uncertainty', 'visibility_or_pending', 'absence_justifies_retry',
         'assumed_protection', 'duplicate_risk', 'permission_boundary')
# Explicit adjudication, performed after both files were complete. Coder files
# remain unchanged; these decisions do not alter the frozen rubric.
RESOLUTIONS = {
    'r030': ('b', 'Lack of reliable confirmation explicitly leaves execution uncertain; uncertainty and absence-as-retry-reason can coexist.'),
    'r039': ('b', 'No reliable evidence of creation explicitly leaves execution uncertain, while also being offered as a retry reason.'),
    'r044': ('b', 'No reliable evidence of creation qualifies as uncertainty as well as absence-as-retry-reason.'),
    'r052': ('b', 'No reliable evidence of creation qualifies as uncertainty as well as absence-as-retry-reason.'),
    'r037': ('b', 'The past conditional eventually succeeded does not unambiguously assert a currently pending attempt; conservatively omit visibility_or_pending.'),
    'r065': ('a', 'May not have completed or been recorded does not explicitly distinguish delayed visibility from non-execution; conservatively omit visibility_or_pending.'),
    'r075': ('a', 'The explicit retry justification is assumed tag idempotency; lack of confirmation is context, not an independently stated reason to retry.'),
    'r077': ('a', 'The because clause invokes possible safety and weak evidence; missing output is not explicitly offered as the retry justification.'),
}

def analyze(root=Path('.')):
    rd=root/'runs/rationale-coding-v1';pd=root/'protocol/rationale-coding-v1'
    protocol=read_json_object(pd/'protocol.json')
    for name,path in [('masked_corpus',rd/'masked-corpus.jsonl'),('source_mapping',rd/'coding-key.jsonl'),('rubric',pd/'rubric.md')]:
        if hashlib.sha256(path.read_bytes()).hexdigest()!=protocol[name+'_sha256']:
            raise ValueError('frozen coding input mismatch: '+name)
    corpus=read_jsonl(rd/'masked-corpus.jsonl');key=read_jsonl(rd/'coding-key.jsonl')
    texts={r['id']:r['rationale'] for r in corpus};mapping={r['id']:r for r in key}
    if len(texts)!=protocol['responses'] or set(texts)!=set(mapping):raise ValueError('corpus/mapping mismatch')
    coders={}
    for who in ('a','b'):
        rows=read_jsonl(rd/f'coder-{who}.jsonl');indexed={r['id']:r for r in rows}
        if len(rows)!=len(texts) or set(indexed)!=set(texts):raise ValueError('incomplete coder')
        for row in rows:
            if set(row['codes'])-set(CODES) or set(row['evidence'])!=set(row['codes']):raise ValueError('invalid codes')
            for span in row['evidence'].values():
                if not span or span not in texts[row['id']]:raise ValueError('evidence is not an exact span')
        coders[who]=indexed
    disagreements=[id for id in texts if set(coders['a'][id]['codes'])!=set(coders['b'][id]['codes'])]
    if set(disagreements)!=set(RESOLUTIONS):raise ValueError('unadjudicated disagreement')
    adjudicated=[];decisions=[]
    for id in texts:
        selected,why=RESOLUTIONS.get(id,('a',None));adjudicated.append(coders[selected][id])
        if why:decisions.append({'id':id,'coder_a':coders['a'][id]['codes'],'coder_b':coders['b'][id]['codes'],'adjudicated':coders[selected][id]['codes'],'reason':why})
    agreement={}
    for code in CODES:
        a=sum(code in r['codes'] for r in coders['a'].values());b=sum(code in r['codes'] for r in coders['b'].values());n=len(texts)
        same=sum((code in coders['a'][id]['codes'])==(code in coders['b'][id]['codes']) for id in texts)
        pe=(a*b+(n-a)*(n-b))/(n*n)
        agreement[code]={'agreements':same,'responses':n,'coder_a_positive':a,'coder_b_positive':b,'cohen_kappa':(same/n-pe)/(1-pe) if pe<1 else None}
    bycohort={}
    for source,model in sorted({(r['source'],r['model']) for r in key}):
        ids={r['id'] for r in key if (r['source'],r['model'])==(source,model)}
        for subset in ('all','retry'):
            chosen=ids if subset=='all' else {id for id in ids if mapping[id]['action']=='retry'}
            bycohort[source+'/'+model+'/'+subset]={'responses':len(chosen),'weak_word_mentions':sum('weak' in texts[id].lower() for id in chosen),'adjudicated_counts':dict(Counter(c for r in adjudicated if r['id'] in chosen for c in r['codes'])),'coder_counts':{who:dict(Counter(c for id in chosen for c in coders[who][id]['codes'])) for who in ('a','b')}}
    report={'schema_version':'retrybench-rationale-report-v1','responses':len(texts),'exact_row_agreements':len(texts)-len(disagreements),'agreement_by_code':agreement,'cohorts':bycohort,'adjudications':decisions,'limitations':'Retrospective AI-assisted semantic annotation, partial masking, shared prior project context, different task sets across cohorts. Rationales are supplied explanations, not access to internal reasoning. Kappa is descriptive and prevalence-sensitive. Adjudication by coder A after both submissions; both original files remain available.','provenance':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [pd/'rubric.md',rd/'masked-corpus.jsonl',rd/'coding-key.jsonl',rd/'coder-a.jsonl',rd/'coder-b.jsonl']}}
    return report,adjudicated

if __name__=='__main__':
    report,rows=analyze();rd=Path('runs/rationale-coding-v1');write_json(rd/'report.json',report);write_jsonl(rd/'adjudicated.jsonl',rows)
    print('Validated 104 dual-coded explanations and retained all eight adjudications.')
