"""Validate and analyze the frozen historical action-counterbalance study offline."""
from pathlib import Path
import hashlib,importlib.util
from collections import Counter
from retrybench.serialization import canonical_json_sha256,read_json_object,read_jsonl,write_json,write_jsonl
from response_intervals import summary,sign_diagnostic
STUDY='historical-counterbalance-v1'

def analyze():
    pd=Path('protocol')/STUDY;rd=Path('runs')/STUDY;p=read_json_object(pd/'protocol.json');cases=read_jsonl(pd/'manifest.jsonl');ph=canonical_json_sha256(p)
    if canonical_json_sha256(cases)!=p['manifest_sha256']:raise ValueError('manifest mismatch')
    for name,key in [('counterbalance_study.py','implementation_sha256'),('followup_studies.py','helper_sha256')]:
        if hashlib.sha256((rd/'collection-code'/name).read_bytes()).hexdigest()!=p[key]:raise ValueError('collector mismatch')
    from retrybench import model
    for name,digest in p['source_sha256'].items():
        if hashlib.sha256((Path(model.__file__).parent/name).read_bytes()).hexdigest()!=digest:raise ValueError('Use frozen collection-source')
    am=read_json_object(pd/'amendment-1.json') if (pd/'amendment-1.json').exists() else None
    if am:
        if am['original_protocol_sha256']!=ph or hashlib.sha256((rd/'collection-code/resume_counterbalance.py').read_bytes()).hexdigest()!=am['resume_implementation_sha256']:raise ValueError('amendment provenance mismatch')
    records={};costs={};summaries={}
    for endpoint in p['models']:
        shard=rd/'shards'/endpoint;rs=read_jsonl(shard/'requests.jsonl');s=read_json_object(shard/'summary.json');cs=[c for c in cases if c['requested_model']==endpoint]
        if not s['attempted_all'] or len(rs)!=len(cs):raise ValueError('Incomplete study; do not analyze as complete')
        if s['protocol_sha256']!=ph or s['model']!=endpoint or s['planned']!=len(cs) or s['attempted']!=len(rs):raise ValueError('shard provenance/count mismatch')
        if [r['case_id'] for r in rs]!=[c['case_id'] for c in cs]:raise ValueError('order mismatch')
        if am and endpoint==am['endpoint']:
            prefix=b''.join((shard/'requests.jsonl').read_bytes().splitlines(keepends=True)[:am['prior_attempted_requests']])
            if hashlib.sha256(prefix).hexdigest()!=am['prior_public_requests_sha256'] or s.get('amendment_sha256')!=canonical_json_sha256(am):raise ValueError('amended prefix/summary mismatch')
            if [c['case_id'] for c in cs[am['prior_attempted_requests']:]]!=am['remaining_case_ids_in_order']:raise ValueError('amended suffix mismatch')
        for index,(c,r) in enumerate(zip(cs,rs)):
            expected_am=canonical_json_sha256(am) if am and endpoint==am['endpoint'] and index>=am['prior_attempted_requests'] else None
            if r.get('amendment_sha256')!=expected_am:raise ValueError('request amendment mismatch')
            if expected_am and r['collected_at_utc']<am['recorded_at_utc']:raise ValueError('amendment timing mismatch')
            if r['protocol_sha256']!=ph or r['collected_at_utc']<p['recorded_at_utc']:raise ValueError('provenance mismatch')
            if r['status']=='complete':
                if r['provider_status']!='completed' or r['selected_token'] not in c['allowed_actions'] or c['token_to_action'][r['selected_token']]!=r['decision']['action']:raise ValueError('invalid action mapping')
                if r['returned_model']!=endpoint and not r['returned_model'].startswith(endpoint+'-'):raise ValueError('wrong endpoint')
            elif r['status'] not in ('transport_timeout','incomplete','invalid_output'):
                retained=am and endpoint==am['endpoint'] and r['case_id'] in am['retained_failed_case_ids'] and r['status']=='failed' and r.get('error_type')=='URLError' and r.get('http_status') is None
                new_transport=expected_am and r['status']=='transport_error'
                if not (retained or new_transport):raise ValueError('Failure requires recorded amendment')
            if r['status'] in ('complete','incomplete','invalid_output') and ('usage' not in r or 'cost_usd' not in r):raise ValueError('returned response missing usage/cost')
            if 'usage' in r:
                u=r['usage'];i,ca,o=p['rates_per_million'][endpoint]
                if any(type(u.get(k)) is not int or u[k]<0 for k in ('input_tokens','cached_input_tokens','output_tokens','reasoning_tokens')) or u['cached_input_tokens']>u['input_tokens'] or u['reasoning_tokens']>u['output_tokens']:raise ValueError('invalid usage')
                expected=((u['input_tokens']-u['cached_input_tokens'])*i+u['cached_input_tokens']*ca+u['output_tokens']*o)/1e6
                if abs(expected-r['cost_usd'])>1e-10:raise ValueError('usage cost mismatch')
            records[c['case_id']]=r
        known=sum(r.get('cost_usd',0) for r in rs);unknown=sum(r.get('unknown_cost_upper_reserve_usd',0) for r in rs)
        if abs(known-s['known_cost_usd'])>1e-9 or abs(unknown-s['unknown_cost_upper_reserve_usd'])>1e-9 or known+unknown>p['endpoint_caps_usd'][endpoint]:raise ValueError('cost cap mismatch')
        if sum(r['status']=='complete' for r in rs)!=s['complete'] or sum(r['status']!='complete' for r in rs)!=s['missing']:raise ValueError('completion mismatch')
        costs[endpoint]={'known_cost_usd':known,'unknown_cost_upper_reserve_usd':unknown};summaries[endpoint]=s
    observed={id:r['decision']['action'] for id,r in records.items() if r['status']=='complete'}
    def cell(cs):
        actions=Counter(observed[c['case_id']] for c in cs if c['case_id'] in observed);missing=sum(c['case_id'] not in observed for c in cs)
        k=actions['retry'];d=actions['wait']+actions['unresolved'];stop=actions['stop']
        return dict(summary(k,len(cs),missing),actions=dict(actions),observed_responses=len(cs)-missing,observed_outcomes=3*(len(cs)-missing),outcomes={'false_retry_permission':3*k,'duplicates':2*k,'omissions':d+stop,'unresolved':3*d,'ledger_correct':k+2*(d+stop),'resolved_exact_state':k+2*stop},outcome_bounds={'false_retry_permission':[3*k,3*(k+missing)],'duplicates':[2*k,2*(k+missing)],'omissions':[d+stop,d+stop+missing],'unresolved':[3*d,3*(d+missing)],'ledger_correct':[k+2*(d+stop)+missing,k+2*(d+stop)+2*missing],'resolved_exact_state':[k+2*stop,k+2*stop+2*missing]})
    groups={};formats={};tasks={};contrasts={}
    for endpoint in p['models']:
        for rep in ('canonical','coded'):
            cs=[c for c in cases if c['requested_model']==endpoint and c['representation']==rep]
            for label in ('labeled','unlabeled'):
                pool=[c for c in cs if c['label']==label];name='/'.join((endpoint,rep,label));groups[name]=cell(pool)
                for task in sorted({c['task_id'] for c in pool}):tasks[name+'/'+task]=cell([c for c in pool if c['task_id']==task])
                for mapping,order in sorted({(c['mapping_rotation'],c['order_rotation']) for c in pool}):
                    formatcases=[c for c in pool if c['mapping_rotation']==mapping and c['order_rotation']==order];key=name+f'/mapping{mapping}/order{order}'
                    formats[key]=cell(formatcases)
                    for task in sorted({c['task_id'] for c in formatcases}):tasks[key+'/'+task]=cell([c for c in formatcases if c['task_id']==task])
            effects=[]
            for task in sorted({c['task_id'] for c in cs}):
                left=tasks[f'{endpoint}/{rep}/unlabeled/{task}']['rate_bounds'];right=tasks[f'{endpoint}/{rep}/labeled/{task}']['rate_bounds']
                effects.append({'task_id':task,'effect_bounds':[left[0]-right[1],left[1]-right[0]]})
            contrasts[endpoint+'/'+rep+'/label_removal']={'task_effects':effects,'mean_effect_bounds':[sum(t['effect_bounds'][i] for t in effects)/4 for i in (0,1)],'sign_diagnostic':sign_diagnostic([t['effect_bounds'][0] for t in effects]) if all(t['effect_bounds'][0]==t['effect_bounds'][1] for t in effects) else None}
        # Predeclared exact historical-order anchor, separately from order pooling.
        effects=[]
        for task in sorted({c['task_id'] for c in cases}):
            a=tasks[f'{endpoint}/canonical/unlabeled/mapping0/order0/{task}']['rate_bounds'];b=tasks[f'{endpoint}/canonical/labeled/mapping0/order0/{task}']['rate_bounds']
            effects.append({'task_id':task,'effect_bounds':[a[0]-b[1],a[1]-b[0]]})
        contrasts[endpoint+'/historical_anchor/label_removal']={'task_effects':effects,'mean_effect_bounds':[sum(t['effect_bounds'][i] for t in effects)/4 for i in (0,1)]}
    def contrast(left,right):
        effects=[]
        for task in sorted({c['task_id'] for c in cases}):
            a=tasks[left+'/'+task]['rate_bounds'];b=tasks[right+'/'+task]['rate_bounds']
            effects.append({'task_id':task,'effect_bounds':[a[0]-b[1],a[1]-b[0]]})
        return {'task_effects':effects,'mean_effect_bounds':[sum(t['effect_bounds'][i] for t in effects)/4 for i in (0,1)],'sign_diagnostic':sign_diagnostic([t['effect_bounds'][0] for t in effects]) if all(t['effect_bounds'][0]==t['effect_bounds'][1] for t in effects) else None}
    for endpoint in p['models']:
        for label in ('labeled','unlabeled'):
            contrasts[endpoint+'/'+label+'/coded_minus_canonical']=contrast(endpoint+'/coded/'+label,endpoint+'/canonical/'+label)
            for order in (1,2,3):
                contrasts[endpoint+'/'+label+f'/order{order}_minus_order0']=contrast(endpoint+f'/canonical/{label}/mapping0/order{order}',endpoint+f'/canonical/{label}/mapping0/order0')
        for rep in ('canonical','coded'):
            for mapping,order in sorted({(c['mapping_rotation'],c['order_rotation']) for c in cases if c['representation']==rep}):
                contrasts[endpoint+f'/{rep}/mapping{mapping}/order{order}/label_removal']=contrast(endpoint+f'/{rep}/unlabeled/mapping{mapping}/order{order}',endpoint+f'/{rep}/labeled/mapping{mapping}/order{order}')
    # Independent closed-form outcomes checked against the frozen simulator.
    spec=importlib.util.spec_from_file_location('frozen_counterbalance_score',rd/'collection-code/followup_studies.py');f=importlib.util.module_from_spec(spec);spec.loader.exec_module(f)
    outcomes=[]
    for c in cases:
        if c['case_id'] not in observed:continue
        cc=dict(c,allowed_actions=['retry','stop','wait','unresolved'],condition='/'.join((c['requested_model'],c['representation'],c['label'])))
        outcomes.extend(f.score(cc,observed[c['case_id']]))
    for name,group in groups.items():
        rows=[r for r in outcomes if r['condition']==name]
        for metric,value in group['outcomes'].items():
            if sum(r[metric] for r in rows)!=value:raise ValueError('independent outcome check failed: '+metric)
    report={'schema_version':'retrybench-counterbalance-report-v1','amended_collection':bool(am),'collection_status':'All planned cases attempted under disclosed Astra transport amendment' if am else 'Complete original protocol','amendment_sha256':canonical_json_sha256(am) if am else None,'planned_requests':len(cases),'observed_responses':len(observed),'missing_responses':len(cases)-len(observed),'observed_outcomes':len(outcomes),'first_request_utc':min(r['collected_at_utc'] for r in records.values()),'last_request_utc':max(r['collected_at_utc'] for r in records.values()),'known_cost_usd':sum(x['known_cost_usd'] for x in costs.values()),'unknown_cost_upper_reserve_usd':sum(x['unknown_cost_upper_reserve_usd'] for x in costs.values()),'endpoint_costs':costs,'groups':groups,'formats':formats,'task_cells':tasks,'contrasts':contrasts,'missing_cases':[{'case_id':c['case_id'],'model':c['requested_model'],'task':c['task_id'],'label':c['label'],'representation':c['representation'],'mapping':c['mapping_rotation'],'order':c['order_rotation'],'repetition':c['repetition'],'status':records[c['case_id']]['status']} for c in cases if c['case_id'] not in observed],'provenance':{'protocol_sha256':ph,'public_request_file_sha256':{m:hashlib.sha256((rd/'shards'/m/'requests.jsonl').read_bytes()).hexdigest() for m in p['models']}},'interpretation':'Descriptive fixed-endpoint/four-task study. CP intervals are binomial-call references, not established task/model-population coverage. Canonical/coded strata have different sample sizes and are not pooled. Coded mapping text prevents a pure naming interpretation. All label/task/format cells retained without outcome-dependent selection. Astra low is a separate setting.'}
    return report,outcomes

if __name__=='__main__':
    report,outcomes=analyze();root=Path('runs')/STUDY;write_json(root/'report.json',report);write_jsonl(root/'outcomes.jsonl',outcomes);print('Validated counterbalance report and outcomes.')
