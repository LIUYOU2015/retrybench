"""Render the canonical action-order grid from frozen manifest/response pairs.

No model calls. Each count is checked against eight planned, completed draws.
The figure reports retry decisions, not explicit-contract violations.
"""
from pathlib import Path
import json, collections
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
root = Path(__file__).resolve().parents[1]
m={x['case_id']:x for x in map(json.loads,(root/'protocol/tier-a-v1/manifest.jsonl').read_text().splitlines())}
c=collections.Counter();n=collections.Counter()
for x in map(json.loads,(root/'runs/tier-a-v1/requests.jsonl').read_text().splitlines()):
 p=m[x['case_id']]
 if p['block']!='canonical':continue
 assert x['status']=='complete'
 k=(p['requested_model'],p['task_id'],p['label'],p['order_rotation']);n[k]+=1;c[k]+=x['decision']['action']=='retry'
models=[('gpt-5.4-mini-2026-03-17','Mini (none)'),('gpt-5.4-2026-03-05','GPT-5.4 (none)'),('gpt-5.6-sol','Sol (none)'),('gpt-5.6-terra','Terra (none)'),('gpt-5.6-luna','Luna (none)'),('gpt-6-astra','Astra (low)')]
tasks=['ci-001','issue-001','release-001','review-001']; out={}
plt.rcParams.update({'svg.hashsalt':'retrybench-canonical-order-v1','font.family':'DejaVu Sans','font.size':10})
fig,axs=plt.subplots(3,2,figsize=(10,8.5),layout='constrained')
for ax,(model,title) in zip(axs.flat,models):
 a=np.array([[c[model,t,l,o] for l in ['labeled','unlabeled'] for o in range(4)] for t in tasks]);assert all(n[model,t,l,o]==8 for t in tasks for l in ['labeled','unlabeled'] for o in range(4))
 out[model]=a.tolist(); im=ax.imshow(a,cmap='YlOrRd',vmin=0,vmax=8,aspect='auto')
 ax.set_title(title,fontweight='bold');ax.set_xticks(range(8),['L0','L1','L2','L3','U0','U1','U2','U3']);ax.set_yticks(range(4),['CI','Issue','Release','Review']);ax.axvline(3.5,color='white',lw=3)
 for i in range(4):
  for j in range(8): ax.text(j,i,f'{a[i,j]}/8',ha='center',va='center',color='white' if a[i,j]>=6 else '#202020',fontsize=9)
 ax.tick_params(length=0)
 for spine in ax.spines.values():spine.set_visible(False)
fig.colorbar(im,ax=axs,shrink=.7,label='Retry responses (8 calls per cell)',ticks=[0,2,4,6,8])
fig.suptitle('Canonical retry counts by task, label, and action order',fontsize=14,fontweight='bold')
fig.savefig(root/'paper/generated/figure-canonical-order-heatmap.svg',metadata={'Date':None,'Description':'All1536 later canonical calls. Each cell8responses; L=labeled U=unlabeled, cyclic orders0-3. Counts derived by joining exact case IDs.'})
plt.close(fig)
