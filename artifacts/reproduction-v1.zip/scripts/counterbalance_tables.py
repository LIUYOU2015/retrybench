"""Source-derived main and supplement tables for the counterbalanced study."""
from pathlib import Path
from retrybench.serialization import read_json_object
from followup_tables import table

def count(cell,interval=True):
    k=cell['events_observed'];n=cell['planned_responses'];m=cell['missing_responses']
    text=f'{k}/{n}'+(f' +{m} missing' if m else '')
    if interval:
        lo,hi=cell['cp95_reference_envelope'];text+=f' [{100*lo:.1f}, {100*hi:.1f}]'
    return text

def effect(bounds):return f'{bounds[0]:+.3f}' if bounds[0]==bounds[1] else f'[{bounds[0]:+.3f}, {bounds[1]:+.3f}]'

def render():
    root=Path('runs/historical-counterbalance-v1');r=read_json_object(root/'report.json');models=list(r['endpoint_costs'])
    anchor=table(['Endpoint','Labeled historical order','Unlabeled same order'],[[m]+[count(r['formats'][f'{m}/canonical/{label}/mapping0/order0']) for label in ('labeled','unlabeled')] for m in models])
    main=table(['Endpoint','Representation','Labeled retry count','Unlabeled retry count','Unlabeled − labeled'],[[m,rep]+[count(r['groups'][f'{m}/{rep}/{label}']) for label in ('labeled','unlabeled')]+[effect(r['contrasts'][f'{m}/{rep}/label_removal']['mean_effect_bounds'])] for m in models for rep in ('canonical','coded')])
    tasks=table(['Endpoint','Representation','CI: labeled → unlabeled','Issue: labeled → unlabeled','Release: labeled → unlabeled','Review: labeled → unlabeled'],[[m,rep]+[' → '.join(count(r['task_cells'][f'{m}/{rep}/{label}/{task}'],False) for label in ('labeled','unlabeled')) for task in ('ci-001','issue-001','release-001','review-001')] for m in models for rep in ('canonical','coded')])
    intro='Counts use planned distinct-response denominators. “+m missing” identifies unobserved actions rather than treating them as non-retries. Brackets next to counts are nominal two-sided95% exact-binomial reference limits (or missing-action envelopes), in percent. Effect brackets are missing-action identification bounds, not confidence intervals. Canonical and coded strata remain separate. All conditions are weak not_found.\n\n'
    out='# Historical counterbalance results\n\n'+intro+'## Exact historical-order anchors\n\n'+anchor+'\n## Balanced representation strata\n\n'+main+'\n## All four-task label counts\n\n'+tasks+'\n## Full format cells\n\n'
    out+=table(['Endpoint/representation/label/mapping/order','Retry count [reference limits]','Retry/stop/wait/unresolved','Duplicates/omissions/unresolved/ledger/resolved'],[[k,count(v),'/'.join(str(v['actions'].get(a,0)) for a in ('retry','stop','wait','unresolved')),'/'.join(str(v['outcomes'][a]) for a in ('duplicates','omissions','unresolved','ledger_correct','resolved_exact_state'))] for k,v in r['formats'].items()])
    out+='\n## Complete task/format cells\n\n'+table(['Condition/task','Retry count [reference limits]'],[[k,count(v)] for k,v in r['task_cells'].items()])
    out+='\n## All specified and exploratory contrasts\n\n'+table(['Contrast','Equal-task effect','CI','Issue','Release','Review'],[[k,effect(v['mean_effect_bounds'])]+[effect(t['effect_bounds']) for t in v['task_effects']] for k,v in r['contrasts'].items()])
    (root/'tables.md').write_text(out)
    return anchor,main,tasks

if __name__=='__main__':render();print('Rendered all counterbalance cells and contrasts.')
