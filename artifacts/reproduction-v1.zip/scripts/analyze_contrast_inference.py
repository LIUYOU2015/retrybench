"""Post-hoc difference intervals and task/format-stratified conditional tests."""
from pathlib import Path
import hashlib
from retrybench.serialization import read_jsonl,read_json_object,write_json
from contrast_inference import analyze_terms,holm
from followup_tables import table

STUDY='historical-counterbalance-v1'
def historical():
    manifest=Path('protocol')/STUDY/'manifest.jsonl';cases=read_jsonl(manifest)
    paths=list((Path('runs')/STUDY/'shards').glob('*/requests.jsonl'))
    outcomes={r['case_id']:int(r['decision']['action']=='retry') for p in paths for r in read_jsonl(p) if r['status']=='complete'}
    old=read_json_object(Path('runs')/STUDY/'report.json');contrasts={}
    for name,previous in old['contrasts'].items():
        parts=name.split('/');endpoint=parts[0];cs=[c for c in cases if c['requested_model']==endpoint];strata=None
        if parts[-1]=='label_removal':
            if parts[1]=='historical_anchor':cs=[c for c in cs if c['representation']=='canonical' and c['order_rotation']==0]
            else:
                cs=[c for c in cs if c['representation']==parts[1]]
                if len(parts)>3:cs=[c for c in cs if c['mapping_rotation']==int(parts[2][-1]) and c['order_rotation']==int(parts[3][-1])]
            left=[c for c in cs if c['label']=='unlabeled'];right=[c for c in cs if c['label']=='labeled'];strata=['task_id','order_rotation','mapping_rotation']
        else:
            cs=[c for c in cs if c['label']==parts[1]]
            if parts[-1]=='coded_minus_canonical':left=[c for c in cs if c['representation']=='coded'];right=[c for c in cs if c['representation']=='canonical'];strata=['task_id','order_rotation']
            else:
                cs=[c for c in cs if c['representation']=='canonical'];left=[c for c in cs if c['order_rotation']==int(parts[-1][5])];right=[c for c in cs if c['order_rotation']==0];strata=['task_id']
        result=analyze_terms([(1,left),(-1,right)],outcomes,strata)
        assert all(abs(a-b)<1e-12 for a,b in zip(result['difference_bounds'],previous['mean_effect_bounds'])),name
        contrasts[name]=result
    headline={k:v for k,v in contrasts.items() if len(k.split('/'))==3 and k.split('/')[1] in ('canonical','coded')}
    adjusted=holm({k:v['conditional_p_bounds'][1] for k,v in headline.items()})
    for k,v in adjusted.items():contrasts[k]['holm12_worst_case_conditional_p']=v
    interactions={}
    for endpoint in sorted({c['requested_model'] for c in cases}):
        arms=[]
        for coef,rep,label in [(1,'coded','unlabeled'),(-1,'coded','labeled'),(-1,'canonical','unlabeled'),(1,'canonical','labeled')]:
            arms.append((coef,[c for c in cases if c['requested_model']==endpoint and c['representation']==rep and c['label']==label]))
        interactions[endpoint]=analyze_terms(arms,outcomes)
    adjusted=holm({k:v['mover_p_bounds'][1] for k,v in interactions.items()})
    for k,v in adjusted.items():interactions[k]['holm6_worst_case_mover_p']=v
    return dict(contrasts=contrasts,interactions=interactions,source_hashes={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [manifest,*paths]})

def key_labels():
    study='label-protection-v1';cs=read_jsonl(Path('protocol')/study/'manifest.jsonl');rs=read_jsonl(Path('runs')/study/'requests.jsonl')
    actions={r['case_id']:r['decision']['action'] for r in rs if r['status']=='complete'};result={}
    for model in sorted({c['requested_model'] for c in cs}):
        for sem in ('unstated','stated'):
            for protection in ('none','valid','changed'):
                cases=[c for c in cs if c['requested_model']==model and c['semantics']==sem and c['protection']==protection]
                event={c['case_id']:int(actions[c['case_id']]=='retry_with_key' if protection=='valid' else actions[c['case_id']] in ('retry','retry_with_key')) for c in cases if c['case_id'] in actions}
                arms=[(coef,[c for c in cases if c['label']==label]) for coef,label in [(1,'unlabeled'),(-1,'labeled')]]
                result[f'{model}/{sem}/{protection}']=dict(analyze_terms(arms,event,['task_id']),event='valid_keyed_retry' if protection=='valid' else 'unsupported_retry_or_retry_with_key')
    return result

def key_all_contrasts():
    study='label-protection-v1';cases=read_jsonl(Path('protocol')/study/'manifest.jsonl');records=read_jsonl(Path('runs')/study/'requests.jsonl')
    actions={r['case_id']:r['decision']['action'] for r in records if r['status']=='complete'}
    old=read_json_object(Path('runs')/study/'report.json')['contrasts'];results={}
    for name,previous in old.items():
        parts=name.split('/');cs=[c for c in cases if c['requested_model']==parts[0]]
        if parts[-1]=='label_removal':
            cs=[c for c in cs if c['semantics']=='unstated' and c['protection']=='none'];left=[c for c in cs if c['label']=='unlabeled'];right=[c for c in cs if c['label']=='labeled'];event='unsupported_retry_or_retry_with_key'
        elif parts[-1]=='semantics_added':
            cs=[c for c in cs if c['label']==parts[1] and c['protection']=='none'];left=[c for c in cs if c['semantics']=='stated'];right=[c for c in cs if c['semantics']=='unstated'];event='unsupported_retry_or_retry_with_key'
        else:
            cs=[c for c in cs if c['label']==parts[1] and c['semantics']==parts[2]];left=[c for c in cs if c['protection']=='valid'];right=[c for c in cs if c['protection']=='changed'];event='keyed_action_selected' if parts[-1].endswith('selection') else 'protected_recovery'
        values={}
        for c in left+right:
            if c['case_id'] not in actions:continue
            a=actions[c['case_id']]
            values[c['case_id']]=int(a in ('retry','retry_with_key') if event.startswith('unsupported') else a=='retry_with_key' and (event!='protected_recovery' or c['protection']=='valid'))
        result=dict(analyze_terms([(1,left),(-1,right)],values,['task_id']),event=event)
        assert all(abs(a-b)<1e-12 for a,b in zip(result['difference_bounds'],previous['mean_effect_bounds'])),name
        if event=='protected_recovery':result['interpretation']='Protected recovery is structurally impossible with changed key; this contrast is partly mechanical and does not isolate action selection.'
        results[name]=result
    return results

def format_range(xs,scale=100):return '['+', '.join(f'{x*scale:.2f}' for x in xs)+']'
def render(r):
    cols=['Endpoint/representation','Difference bounds (pp)','95% Newcombe reference envelope (pp)','Exact stratified p range','Holm12 worst-case p'];rows=[]
    for k,v in r['historical']['contrasts'].items():
        if 'holm12_worst_case_conditional_p' in v:rows.append([k,format_range(v['difference_bounds']),format_range(v['mover95_reference_envelope']),str(v['conditional_p_bounds']),f"{v['holm12_worst_case_conditional_p']:.5g}"])
    main=table(cols,rows)
    interactions=table(['Endpoint','Coded−canonical label effect (pp)','95% MOVER reference envelope (pp)','Reference p range','Holm6 worst-case p'],[[k,format_range(v['difference_bounds']),format_range(v['mover95_reference_envelope']),str(v['mover_p_bounds']),f"{v['holm6_worst_case_mover_p']:.5g}"] for k,v in r['historical']['interactions'].items()])
    body='# Difference intervals and interaction diagnostics\n\n'+r['interpretation']+'\n\n## Historical label contrasts\n\n'+main+'\n## Risk-difference interactions\n\n'+interactions
    for title,cs in [('All historical contrasts',r['historical']['contrasts']),('All key-study label contrasts',r['key_label_contrasts']),('All original key-study contrasts',r['key_original_contrasts'])]:
        body+='\n## '+title+'\n\n'+table(['Contrast','Difference bounds (pp)','95% Newcombe reference envelope (pp)','Exact conditional p range'],[[k,format_range(v['difference_bounds']),format_range(v['mover95_reference_envelope']),str(v.get('conditional_p_bounds'))] for k,v in cs.items()])
    return body,main,interactions

def analyze():
    result={'schema_version':'retrybench-contrast-inference-v1','analysis_status':'Post-hoc, specified after historical/key results and reviewer feedback. No new model calls.','interpretation':'Intervals use Wilson-MOVER (Newcombe for two arms), with feasible missing-action assignments enumerated. They are approximate independent-binomial references, not demonstrated coverage for heterogeneous or dependent API calls. Exact doubled-tail conditional tests stratify label contrasts by task×order×mapping, and key contrasts by task; calls are not paired by repetition number. These test conditional odds-ratio=1, not the equal-task risk-difference estimand. Risk-difference interaction is (coded U−L)−(canonical U−L); its MOVER p is obtained by interval inversion. Holm uses worst-case p bounds in separate12-label/6-interaction families. All other comparisons are exploratory, unadjusted. No task-population inference.','historical':historical(),'key_label_contrasts':key_labels(),'key_original_contrasts':key_all_contrasts()}
    out=Path('runs/contrast-inference-v1');out.mkdir(exist_ok=True);write_json(out/'report.json',result);body,_,_=render(result);(out/'tables.md').write_text(body)
    return result
if __name__=='__main__':r=analyze();print(render(r)[1]);print(render(r)[2])
