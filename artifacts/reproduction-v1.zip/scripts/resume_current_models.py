"""Collect the already prepared two-model, low-reasoning prompt-package block.

Operational policy is frozen before requests: record timeouts as missing, never
replace them, and stop on a fifth timeout or any other failure. No outcome-based
stopping or case selection is used.
"""
from __future__ import annotations
import hashlib
import json
import shutil
import socket
import subprocess
import sys
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

from retrybench.current_models import build_manifest, score_case, REQUEST_OVERHEAD_BYTES
from retrybench.openai_adapter import CostBudget, OpenAIResponsesPolicy, maximum_decision_cost
from retrybench.serialization import canonical_json_sha256, read_json_object, read_jsonl, write_json, write_jsonl


def main():
    protocol_dir=Path('protocol/current-models-v1')
    output=Path('runs/current-models-v1')
    cases=read_jsonl(protocol_dir/'manifest.jsonl')
    protocol=read_json_object(protocol_dir/'protocol.json')
    if cases!=build_manifest() or canonical_json_sha256(cases)!=protocol['manifest_sha256']:
        raise ValueError('frozen manifest differs')
    source_root=Path('src/retrybench')
    output.mkdir(parents=True,exist_ok=True)
    private=output/'private';private.mkdir(exist_ok=True)
    specification={
        'schema_version':'retrybench-current-models-collection-policy-v1',
        'protocol_sha256':canonical_json_sha256(protocol),'manifest_sha256':protocol['manifest_sha256'],
        'collector_sha256':hashlib.sha256(Path('scripts/collect_current_models.py').read_bytes()).hexdigest(),
        'source_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(source_root.glob('*.py'))},
        'transport_timeout_seconds':300,'max_retained_timeouts':4,'cost_cap_usd_including_unknown_reservations':19,
        'operational_deviation':'Before any collection in this block, amend the prepared stopping rule: retain up to four unreturned transport timeouts as missing, never retry/replace them, continue original order; stop on fifth timeout or any other error. Prompts/settings/scoring unchanged. Motivated by prior block transport failures, not outcomes in this block.',
        'analysis':'Original model/prompt-specific equal-family weak-minus-authoritative contrasts and complete outcome vectors; fixed denominators and missing-action bounds. Additional pre-collection secondary contrasts compare explicit-contract and explicit-contract-cautious weak-interface rates against label-only. No pure generation attribution against historical none-reasoning data.',
        'preflights_excluded':True,
    }
    policy_path=protocol_dir/'collection-policy.json'
    if policy_path.exists():
        collection=read_json_object(policy_path)
        if {k:v for k,v in collection.items() if k!='recorded_at_utc'}!=specification:
            raise ValueError('collection policy or implementation changed')
    else:
        collection={**specification,'recorded_at_utc':datetime.now(timezone.utc).isoformat()}
        write_json(policy_path,collection)
    collection_hash=canonical_json_sha256(collection)
    snapshot=output/'collection-source/retrybench';snapshot.mkdir(parents=True,exist_ok=True)
    for p in sorted(source_root.glob('*.py')):
        dest=snapshot/p.name
        if dest.exists() and dest.read_bytes()!=p.read_bytes():raise ValueError('source snapshot changed')
        if not dest.exists():shutil.copyfile(p,dest)
    journal=private/'requests.jsonl'
    records=read_jsonl(journal) if journal.exists() else []
    pending=private/'pending.json'
    amendment_path=protocol_dir/'resume-amendment-1.json'
    if amendment_path.exists():
        amendment=read_json_object(amendment_path)
        if amendment['resume_collector_sha256']!=hashlib.sha256(Path(__file__).read_bytes()).hexdigest():raise ValueError('resume collector changed')
        if pending.exists():raise ValueError('another interrupted request requires review')
    else:
        if not pending.exists() or len(records)!=277 or any(r['status']!='complete' for r in records):raise ValueError('unexpected interruption state')
        interrupted=read_json_object(pending)
        case=cases[len(records)]
        if interrupted['case_id']!=case['case_id'] or interrupted['collection_policy_sha256']!=collection_hash:raise ValueError('interrupted case is not next frozen request')
        amendment={
            'schema_version':'retrybench-current-models-resume-amendment-1',
            'recorded_at_utc':datetime.now(timezone.utc).isoformat(),
            'original_collection_policy_sha256':collection_hash,
            'resume_collector_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'interrupted_case_id':case['case_id'],
            'preserved_pending_sha256':hashlib.sha256(pending.read_bytes()).hexdigest(),
            'completed_before_interruption':277,
            'remaining_case_ids_in_order':[c['case_id'] for c in cases[len(records)+1:]],
            'reason':'Previous collector no longer running; pending request has no recorded response. Processing and billing are unknown. No live actions inspected before this recovery amendment.',
            'policy':'Retain interrupted request as missing without replacement; count it toward the existing maximum of four missing transport responses; preserve prompts, order, source, model settings, timeout, and cumulative $19 cap.'
        }
        write_json(amendment_path,amendment)
        interrupted.update(status='transport_interruption',unknown_cost_upper_reserve_usd=maximum_decision_cost(case['requested_model'],case['instructions'],case['prompt']+' '*REQUEST_OVERHEAD_BYTES,case['max_output_tokens']),resume_amendment_sha256=canonical_json_sha256(amendment))
        with journal.open('a') as handle:handle.write(json.dumps(interrupted,sort_keys=True)+'\n')
        pending.rename(private/'pending-interruption-1.json')
        records.append(interrupted)
    amendment_hash=canonical_json_sha256(amendment)
    if any(r['collection_policy_sha256']!=collection_hash or r['status'] not in ('complete','transport_timeout','transport_interruption') for r in records):raise ValueError('invalid resume journal')
    done={r['case_id'] for r in records}
    if len(done)!=len(records) or not done<={c['case_id'] for c in cases}:raise ValueError('unexpected request IDs')
    budget=CostBudget(19)
    budget.spent_usd=sum(r['decision']['cost_usd'] if r['status']=='complete' else r['unknown_cost_upper_reserve_usd'] for r in records)
    timeouts=sum(r['status']!='complete' for r in records)
    if timeouts>4:raise ValueError('timeout limit already exceeded')
    key=subprocess.run(['/usr/bin/security','find-generic-password','-a','retrybench','-s','retrybench-openai-api-key','-w'],capture_output=True,timeout=25)
    if key.returncode or not key.stdout.strip():raise ValueError('Keychain lookup failed')
    def transport(api_key,payload):
        request=urllib.request.Request('https://api.openai.com/v1/responses',data=json.dumps(payload).encode(),headers={'Authorization':'Bearer '+api_key,'Content-Type':'application/json'},method='POST')
        with urllib.request.urlopen(request,timeout=300) as response:return json.loads(response.read())
    policies={m:OpenAIResponsesPolicy(model=m,reasoning_effort='low',max_output_tokens=4096,api_key=key.stdout.decode().strip(),transport=transport,strict_response_metadata=True) for m in sorted({c['requested_model'] for c in cases})}
    del key
    print('Resuming unattempted frozen cases; one interrupted request retained as missing, cumulative $19 cap.',flush=True)
    for case in cases:
        if case['case_id'] in done:continue
        policy=policies[case['requested_model']]
        reserve=maximum_decision_cost(policy.model,case['instructions'],case['prompt']+' '*REQUEST_OVERHEAD_BYTES,4096)
        budget.reserve_request(policy.model,case['instructions']+'\n'+case['prompt']+' '*REQUEST_OVERHEAD_BYTES,4096)
        record={'case_id':case['case_id'],'manifest_sha256':protocol['manifest_sha256'],'collection_policy_sha256':collection_hash,'collected_at_utc':datetime.now(timezone.utc).isoformat(),'resume_amendment_sha256':amendment_hash}
        write_json(pending,record)
        try:
            decision=policy.decide_text(case['instructions'],case['prompt'],budget).to_dict()
            record.update(status='complete',decision=decision,provider_metadata=policy.last_response_metadata)
        except (TimeoutError,socket.timeout):
            timeouts+=1;budget.spent_usd+=reserve
            record.update(status='transport_timeout',unknown_cost_upper_reserve_usd=reserve)
        except Exception as exc:
            record.update(status='failed',error_type=type(exc).__name__,provider_metadata=policy.last_response_metadata)
        with journal.open('a') as handle:handle.write(json.dumps(record,sort_keys=True)+'\n')
        pending.unlink();records.append(record)
        if record['status']=='failed' or timeouts>4:
            print('Collection halted for review; failure policy reached.',flush=True);return 1
        if len(records)%24==0:print(json.dumps({'attempted':len(records),'planned':len(cases),'retained_timeouts':timeouts,'spent_plus_unknown_reserve_usd':round(budget.spent_usd,6)}),flush=True)
    for policy in policies.values():policy.api_key=None
    public=[]
    for record in records:
        row={k:record[k] for k in ('case_id','manifest_sha256','collection_policy_sha256','collected_at_utc','status')}
        row['resume_amendment_sha256']=record.get('resume_amendment_sha256')
        if record['status']=='complete':row.update(provider_status=record['provider_metadata']['status'],decision={k:v for k,v in record['decision'].items() if k!='response_id'})
        else:row['unknown_cost_upper_reserve_usd']=record['unknown_cost_upper_reserve_usd']
        public.append(row)
    write_jsonl(output/'requests.jsonl',public)
    decisions={r['case_id']:r['decision'] for r in public if r['status']=='complete'}
    write_jsonl(output/'outcomes.jsonl',[r for c in cases if c['case_id'] in decisions for r in score_case(c,decisions[c['case_id']])])
    write_json(output/'collection-summary.json',{'attempted_all_manifest_cases':True,'resume_amendment_sha256':amendment_hash,'planned_requests':len(cases),'observed_responses':len(decisions),'missing_responses':timeouts,'collection_policy_sha256':collection_hash,'known_cost_usd':sum(r['decision']['cost_usd'] for r in public if r['status']=='complete'),'unknown_cost_upper_reserve_usd':sum(r.get('unknown_cost_upper_reserve_usd',0) for r in public)})
    print('Fixed-manifest collection finished.',flush=True)
    return 0


if __name__=='__main__':
    try:sys.exit(main())
    except Exception as exc:
        print('Stopped safely: '+type(exc).__name__,flush=True);sys.exit(1)
