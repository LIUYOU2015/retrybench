# RetryBench reproduction artifact v1

Frozen experimental inputs and offline analysis code supporting **RetryBench:
Retry Decisions and Protected Recovery Across GPT Interfaces**, author revision
October 16, 2026, by You Liu, Yue Liu, and Quanchao Lu.

## Reproduce

Use Python 3.9 (the validated environment). Extract this archive into a new
directory and run from its root:

```sh
python3 -m venv .venv
.venv/bin/python -m pip install '.[langgraph,langchain,figures]'
.venv/bin/python verify.py
```

Installation downloads dependencies. Verification uses frozen responses and
offline simulation; no API key, paid inference, or live collection is needed.
It checks every file against FILE-HASHES.json, runs scientific tests, executes
the 27 analysis commands in ANALYSIS-COMMANDS.json, and checks 49 regenerated
outputs against EXPECTED-OUTPUTS.json. Results are written to verification.json
and verification.log. Use a fresh extraction to repeat the full integrity check.

## Find the evidence

- `runs/tier-a-v1/`: canonical actions, key conditions, and collection snapshots.
- `runs/candidate-presence-v1/`: supplied-key control, including missing cases.
- `runs/key-retest-v1/`: key retest and secondary recovery analyses.
- `runs/order-replication-v1/`: expanded retrospective order comparisons.
- `runs/historical-counterbalance-v1/`: earlier counterbalanced collection.
- `runs/label-cue-v1/` and `runs/label-protection-v1/`: explicit-contract controls.
- `protocol/`: collection specifications and frozen request manifests.
- `src/`, `scripts/`, and collection-source directories: analysis implementation
  and collection-time semantics. Preserve the per-command PYTHONPATH values.

Other archived runs support historical comparisons, uncertainty calculations,
and framework replay. Synthetic replay outcomes are correlated alternatives,
not additional independent model responses. Missing and invalid responses are
retained. These experiments do not establish production failure rates or
episode-level safety. The supplied-key control changes output requirements as
well as candidate presentation; it is not a pure candidate-display intervention.

This archive reproduces the frozen scientific results. It does not rebuild the
paper PDF or reproduce future live endpoint responses. Manuscript presentation
and documentation-navigation tests are outside this archive's scope.

[Revised manuscript](https://huggingface.co/spaces/uuhugg/retrybench-demo/blob/main/retrybench-author-revision-2026-10-16.pdf)
· [Repository](https://github.com/LIUYOU2015/retrybench)
· [Demo](https://huggingface.co/spaces/uuhugg/retrybench-demo)

Code and included artifacts retain the existing PolyForm Noncommercial 1.0.0
license. See LICENSE and CITATION.cff. Collection scripts are included for
provenance; do not run them as part of offline reproduction.
