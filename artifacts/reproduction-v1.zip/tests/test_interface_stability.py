"""Check tie handling and missing-action rank bounds independently of plots."""
import json
import math
import sys
import unittest
from fractions import Fraction
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from analyze_interface_stability import possible_vectors, tau_b


class InterfaceStabilityTests(unittest.TestCase):
    def test_tau_handles_order_reversal_and_ties(self):
        self.assertEqual(tau_b([1, 2, 3], [1, 2, 3]), 1)
        self.assertEqual(tau_b([1, 2, 3], [3, 2, 1]), -1)
        self.assertAlmostEqual(tau_b([1, 1, 2], [1, 2, 3]), 2 / math.sqrt(6))
        self.assertIsNone(tau_b([1, 1, 1], [1, 2, 3]))
        with self.assertRaises(ValueError):
            tau_b([1, 2], [1])

    def test_missing_actions_can_change_ties_without_imputation(self):
        groups = {
            'a/v': dict(planned_responses=2, events_observed=0, missing_responses=1),
            'b/v': dict(planned_responses=4, events_observed=2, missing_responses=0),
        }
        self.assertEqual(possible_vectors(groups, ['a', 'b'], 'v'), [
            (Fraction(0), Fraction(1, 2)),
            (Fraction(1, 2), Fraction(1, 2)),
        ])

    def test_equal_variant_and_response_weights_have_different_orders(self):
        report = json.loads((ROOT / 'runs/interface-stability-v1/report.json').read_text())
        groups = json.loads((ROOT / 'runs/historical-counterbalance-v1/report.json').read_text())['groups']
        summaries = report['equal_variant_summaries']
        mini, terra = 'gpt-5.4-mini-2026-03-17', 'gpt-5.6-terra'
        self.assertGreater(summaries[terra]['equal_variant_mean_bounds'][0],
                           summaries[mini]['equal_variant_mean_bounds'][1])
        def pooled(model, include_missing):
            cells = [groups[model + '/' + v] for v in report['variants']]
            return sum(c['events_observed'] + include_missing * c['missing_responses']
                       for c in cells) / sum(c['planned_responses'] for c in cells)
        self.assertGreater(pooled(mini, False), pooled(terra, True))
        for summary in summaries.values():
            for index in (0, 1):
                mean = sum(v[index] for v in summary['variant_rate_bounds'].values()) / 4
                self.assertEqual(summary['equal_variant_mean_bounds'][index], mean)


if __name__ == '__main__':
    unittest.main()
