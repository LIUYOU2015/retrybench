import json
import unittest
from pathlib import Path

from retrybench.review_diagnostics import analyze, family_statistics


ROOT = Path(__file__).resolve().parents[1]


class ReviewDiagnosticsTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.report = analyze(ROOT)

    def test_all_diagnostics_recompute(self):
        saved = json.loads((ROOT / 'runs/review-diagnostics-v1/analysis.json').read_text())
        self.assertEqual(saved, self.report)

    def test_ties_are_excluded_from_sign_test(self):
        stat = family_statistics([1, 1, 0, 0])
        self.assertEqual(stat['ties'], 2)
        self.assertEqual(stat['exact_two_sided_sign_p_excluding_ties'], .5)
        self.assertEqual(stat['cluster_percentile_95_interval'], [0, 1])
        self.assertEqual(family_statistics([1] * 8)['exact_two_sided_sign_p_excluding_ties'], 1/128)

    def test_response_counts_do_not_count_replays_as_calls(self):
        table = self.report['blocks']['confirmation-v2']['response_table']
        self.assertEqual(table['neutral/weak/not_found']['responses'], 20)
        self.assertEqual(table['neutral/weak/not_found']['unsupported_retry_responses'], 17)
        self.assertEqual(table['neutral/authoritative/not_executed']['correct_retry_responses'], 20)
        self.assertEqual(sum(x['responses'] for x in table.values()), 160)

    def test_archived_decisions_match_logical_schedules(self):
        replay = self.report['logical_replay']
        self.assertEqual(replay['matched_outcomes'], 768)
        self.assertEqual(replay['pending_at_observation'], 248)
        self.assertEqual(replay['pending_at_retry_admission'], 53)

    def test_common_world_contrast_uses_matched_eligibility(self):
        mini = self.report['blocks']['confirmation-v2']
        self.assertAlmostEqual(mini['common_forbidden_statistics']['mean'], 34/40 - 3/40)
        self.assertAlmostEqual(mini['interface_statistics']['mean'], .8)
        for block in ('gpt54-replication-v1', 'task-robustness-v1'):
            report = self.report['blocks'][block]
            self.assertEqual(report['common_forbidden_family_effects'], report['family_effects'])

    def test_cost_ranking_can_reverse(self):
        policies = self.report['prior_sensitivity']['results']['terminal_heavy']
        retry = policies['always_retry']['loss_by_duplicate_cost']
        stop = policies['always_stop']['loss_by_duplicate_cost']
        self.assertLess(retry['1'], stop['1'])
        self.assertGreater(retry['10'], stop['10'])


if __name__ == '__main__':
    unittest.main()
