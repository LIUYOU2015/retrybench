"""Exercise missing-data and semantic-code integrity without provider access."""
import importlib.util,json,os,shutil,sys,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from retrybench.serialization import read_jsonl,read_json_object,write_json,write_jsonl,canonical_json_sha256
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
import analyze_counterbalance as ac

class CounterbalanceAnalysisTests(unittest.TestCase):
    def test_missing_response_remains_one_shared_choice_and_bad_mapping_rejected(self):
        study='historical-counterbalance-v1'
        with tempfile.TemporaryDirectory() as temporary:
            root=Path(temporary);shutil.copytree(ROOT/'protocol'/study,root/'protocol'/study)
            shutil.copytree(ROOT/'runs'/study/'collection-code',root/'runs'/study/'collection-code')
            (root/'protocol'/study/'amendment-1.json').unlink(missing_ok=True)
            p=read_json_object(root/'protocol'/study/'protocol.json');cs=read_jsonl(root/'protocol'/study/'manifest.jsonl');ph=canonical_json_sha256(p)
            missing=next(c for c in cs if c['representation']=='canonical' and c['label']=='labeled' and c['order_rotation']==0)
            for model in p['models']:
                rs=[]
                for c in cs:
                    if c['requested_model']!=model:continue
                    r={'case_id':c['case_id'],'protocol_sha256':ph,'collected_at_utc':p['recorded_at_utc']}
                    if c['case_id']==missing['case_id']:r.update(status='transport_timeout',unknown_cost_upper_reserve_usd=.01)
                    else:r.update(status='complete',provider_status='completed',returned_model=model,selected_token=next(t for t,a in c['token_to_action'].items() if a=='unresolved'),decision={'action':'unresolved','rationale':'Synthetic test fixture only.'},cost_usd=0,usage={'input_tokens':0,'cached_input_tokens':0,'output_tokens':0,'reasoning_tokens':0})
                    rs.append(r)
                shard=root/'runs'/study/'shards'/model;shard.mkdir(parents=True)
                write_jsonl(shard/'requests.jsonl',rs);write_json(shard/'summary.json',{'protocol_sha256':ph,'model':model,'planned':len(rs),'attempted':len(rs),'missing':sum(r['status']!='complete' for r in rs),'attempted_all':True,'complete':sum(r['status']=='complete' for r in rs),'known_cost_usd':0,'unknown_cost_upper_reserve_usd':.01 if model==missing['requested_model'] else 0})
            old=Path.cwd()
            try:
                os.chdir(root)
                report,rows=ac.analyze()
                self.assertEqual(report['missing_responses'],1);self.assertEqual(len(rows),1919*3)
                group=report['groups'][missing['requested_model']+'/canonical/labeled']
                self.assertEqual(group['planned_responses'],32)
                self.assertEqual(group['rate_bounds'],[0,1/32])
                self.assertEqual(group['outcome_bounds']['duplicates'],[0,2])
                self.assertEqual(group['outcome_bounds']['ledger_correct'],[63,64])
                self.assertEqual(group['outcome_bounds']['unresolved'],[93,96])
                shard=root/'runs'/study/'shards'/p['models'][0]/'requests.jsonl';rs=read_jsonl(shard);row=next(r for r in rs if r['status']=='complete');row['selected_token']='NONEXISTENT'
                write_jsonl(shard,rs)
                with self.assertRaisesRegex(ValueError,'action mapping'):ac.analyze()
            finally:os.chdir(old)

if __name__=='__main__':unittest.main()
