import copy, importlib, json, sys, unittest
from collections import Counter
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
import candidate_presence_study as study

class CandidatePresenceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.cases=study.build_manifest()
    def test_balanced_interleaving(self):
        self.assertEqual(len(self.cases),240)
        self.assertEqual(len({c['case_id'] for c in self.cases}),240)
        for m in study.MODELS:
            cs=[c for c in self.cases if c['requested_model']==m]
            self.assertEqual(len(cs),80)
            for i in range(0,80,4):
                block=cs[i:i+4]
                self.assertEqual(len({(c['task_id'],c['repetition']) for c in block}),1)
                self.assertEqual({(c['candidate'],c['original_key_state']) for c in block},{(a,b) for a in ('absent','displayed') for b in ('omitted','present')})
    def test_only_candidate_line_differs_with_same_schema(self):
        absent={(c['requested_model'],c['task_id'],c['repetition'],c['original_key_state']):c for c in self.cases if c['candidate']=='absent'}
        for c in self.cases:
            if c['candidate']!='displayed':continue
            a=absent[c['requested_model'],c['task_id'],c['repetition'],c['original_key_state']]
            self.assertEqual(c['prompt'].replace('Candidate recovery key: key-B.\n',''),a['prompt'])
            x,y=study.payload(c),study.payload(a)
            self.assertEqual(x['text'],y['text'])
            self.assertEqual(c['instructions'],a['instructions'])
            self.assertEqual(c['allowed_actions'],a['allowed_actions'])
            self.assertEqual(c['reasoning_effort'],'none')
            self.assertEqual(c['max_output_tokens'],256)
    def test_exact_key_and_joint_replay_gold(self):
        for c in self.cases:
            for key in ('key-A','key-B','key-A ','invented'):
                d={'action':'retry_with_key','idempotency_key':key}
                safe=c['original_key_state']=='present' and key=='key-A'
                self.assertEqual(study.protected(c,d),safe)
                out=study.score(c,d)
                self.assertEqual(sum(x['false_retry_permission'] for x in out),0 if safe else 3)
                self.assertEqual(sum(x['duplicates'] for x in out),0 if safe else 2)
                self.assertEqual(sum(x['protected_recovery'] for x in out),3 if safe else 0)
    def test_deferral_preserves_original_and_misses_bounded_progress(self):
        for c in self.cases[:4]:
            out=study.score(c,{'action':'unresolved','idempotency_key':None})
            self.assertEqual([sum(x[k] for x in out) for k in ('false_retry_permission','omissions','unresolved','ledger_correct','resolved_exact_state')],[0,1,3,2,0])
    def test_real_returned_key_is_used_even_when_candidate_displayed(self):
        c=next(c for c in self.cases if c['candidate']=='displayed' and c['original_key_state']=='present')
        raw={'id':'synthetic-fixture','status':'completed','model':c['requested_model'],'usage':{'input_tokens':100,'output_tokens':30,'input_tokens_details':{'cached_tokens':0},'output_tokens_details':{'reasoning_tokens':0}},'output':[{'content':[{'type':'output_text','text':json.dumps({'action':'retry_with_key','rationale':'reuse','idempotency_key':'key-A'})}]}]}
        result=study.decode(c,raw);self.assertEqual(result['status'],'complete');self.assertTrue(study.protected(c,result['decision']))
        raw['output'][0]['content'][0]['text']=json.dumps({'action':'retry_with_key','rationale':'bad','idempotency_key':None})
        self.assertEqual(study.decode(c,raw)['status'],'invalid_output')
        raw['status']='incomplete';self.assertEqual(study.decode(c,raw)['status'],'incomplete')

if __name__=='__main__':unittest.main()
