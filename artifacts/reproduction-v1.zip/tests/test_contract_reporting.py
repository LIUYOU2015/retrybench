import json
import runpy
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from retrybench.current_models import prepare, run
from retrybench.openai_adapter import OpenAIResponsesPolicy
from retrybench.serialization import canonical_json_sha256, read_jsonl, write_json, write_jsonl


ROOT = Path(__file__).resolve().parents[1]
analyze = runpy.run_path(str(ROOT / 'scripts/analyze_contract_wording.py'))['analyze']
analyze_amended = runpy.run_path(str(ROOT / 'scripts/analyze_amended_wording.py'))['analyze']
analyze_current = runpy.run_path(str(ROOT / 'scripts/analyze_current_models.py'))['analyze']


def all_stop_policy(**kwargs):
    def transport(api_key, payload):
        return {
            'id': 'synthetic-only', 'model': payload['model'], 'status': 'completed',
            'usage': {'input_tokens': 100, 'output_tokens': 30},
            'output': [{'content': [{'type': 'output_text', 'text': json.dumps({'action': 'stop', 'rationale': 'test only'})}]}],
        }
    return OpenAIResponsesPolicy(api_key='test-only', transport=transport, **kwargs)


class ContractReportingTests(unittest.TestCase):
    def test_released_current_report_reproduces_with_preserved_source(self):
        report_path=ROOT/'runs/current-models-v1/report.json'
        if not report_path.exists():
            self.skipTest('two-model study has not been released in this checkout')
        code="from pathlib import Path; import json,runpy; analyze=runpy.run_path('scripts/analyze_current_models.py')['analyze']; print(json.dumps(analyze(Path('protocol/current-models-v1'),Path('runs/current-models-v1')),sort_keys=True))"
        env=dict(os.environ,PYTHONPATH=str(ROOT/'runs/current-models-v1/collection-source'))
        result=subprocess.run([sys.executable,'-c',code],cwd=ROOT,env=env,capture_output=True,text=True,check=True)
        self.assertEqual(json.loads(result.stdout),json.loads(report_path.read_text()))

    def test_released_amended_report_reproduces_with_preserved_source(self):
        report_path=ROOT/'runs/contract-wording-v2/report.json'
        if not report_path.exists():
            self.skipTest('live study has not been released in this checkout')
        code="from pathlib import Path; import json,runpy; analyze=runpy.run_path('scripts/analyze_amended_wording.py')['analyze']; print(json.dumps(analyze(Path('protocol/contract-wording-v2'),Path('runs/contract-wording-v2')),sort_keys=True))"
        env=dict(os.environ,PYTHONPATH=str(ROOT/'runs/contract-wording-v2/collection-source'))
        result=subprocess.run([sys.executable,'-c',code],cwd=ROOT,env=env,capture_output=True,text=True,check=True)
        self.assertEqual(json.loads(result.stdout),json.loads(report_path.read_text()))

    def test_two_model_report_preserves_missing_weak_group_and_manifest_order(self):
        with tempfile.TemporaryDirectory() as directory:
            protocol, output = Path(directory) / 'protocol', Path(directory) / 'run'
            prepare(protocol)
            with patch('retrybench.current_models.OpenAIResponsesPolicy', side_effect=all_stop_policy):
                run(protocol,output,19)
            provenance=json.loads((output/'collection-provenance.json').read_text())
            policy={'protocol_sha256':provenance['protocol_sha256'],'source_sha256':provenance['source_sha256']}
            write_json(protocol/'collection-policy.json',policy)
            case=next(c for c in read_jsonl(protocol/'manifest.jsonl') if c['requested_model']=='gpt-6-astra' and c['prompt_mode']=='label_only' and c['evidence']=='weak')
            requests=read_jsonl(output/'requests.jsonl')
            for r in requests:
                r.update(status='complete',collection_policy_sha256=canonical_json_sha256(policy))
                if r['case_id']==case['case_id']:
                    r.update(status='transport_timeout',unknown_cost_upper_reserve_usd=.25)
                    r.pop('decision')
            write_jsonl(output/'requests.jsonl',requests)
            write_jsonl(output/'outcomes.jsonl',[r for r in read_jsonl(output/'outcomes.jsonl') if r['response_group_id']!=case['case_id']])
            write_json(output/'collection-summary.json',{'attempted_all_manifest_cases':True,'collection_policy_sha256':canonical_json_sha256(policy),'missing_responses':1,'observed_responses':767,'known_cost_usd':sum(r['decision']['cost_usd'] for r in requests if r['status']=='complete'),'unknown_cost_upper_reserve_usd':.25})
            report=analyze_current(protocol,output)
            bounds=report['contrasts']['gpt-6-astra/label_only/weak_minus_authoritative']['missing_action_mean_bounds']
            self.assertEqual(bounds,[0,1/32])
            package=report['contrasts']['gpt-6-astra/explicit_contract_minus_label_only/weak']['missing_action_mean_bounds']
            self.assertEqual(package,[-1/32,0])
            self.assertEqual(report['observed_outcomes'],1149)
            requests[0],requests[1]=requests[1],requests[0]
            write_jsonl(output/'requests.jsonl',requests)
            with self.assertRaisesRegex(ValueError,'frozen order'):
                analyze_current(protocol,output)

    def test_missing_weak_response_retains_fixed_denominator_and_shared_action(self):
        with tempfile.TemporaryDirectory() as directory:
            protocol, output = Path(directory) / 'protocol', Path(directory) / 'run'
            prepare(protocol, 'contract-wording')
            with patch('retrybench.current_models.OpenAIResponsesPolicy', side_effect=all_stop_policy):
                run(protocol, output, 20)
            case = next(c for c in read_jsonl(protocol/'manifest.jsonl') if c['prompt_mode']=='weak_explicit')
            provenance = json.loads((output/'collection-provenance.json').read_text())
            amendment = {'retained_missing_case_ids':[case['case_id']], 'remaining_case_ids_in_order':[], 'original_collection_provenance_sha256':canonical_json_sha256(provenance)}
            write_json(protocol/'amendment-1.json', amendment)
            write_jsonl(output/'requests.jsonl', [r for r in read_jsonl(output/'requests.jsonl') if r['case_id']!=case['case_id']])
            write_jsonl(output/'outcomes.jsonl', [r for r in read_jsonl(output/'outcomes.jsonl') if r['response_group_id']!=case['case_id']])
            write_json(output/'analysis.json', {'complete':False,'amended_collection':True,'attempted_all_manifest_cases':True,'amendment_sha256':canonical_json_sha256(amendment),'missing_case_ids':[case['case_id']],'known_cost_usd':0,'unknown_cost_upper_reserve_usd':.1})
            report = analyze_amended(protocol,output)
            bounds = report['contrasts']['weak_explicit_minus_weak_label']['missing_action_mean_bounds']
            self.assertEqual(bounds[0],0)
            self.assertAlmostEqual(bounds[1],1/48)
            self.assertFalse(report['contrasts']['weak_explicit_minus_weak_label']['fully_observed_contrast'])
            outcomes = report['arms']['weak_explicit']['fixed_denominator_outcome_bounds']
            self.assertEqual(outcomes['duplicates'],[0,2])
            self.assertEqual(outcomes['omissions'],[47,48])
            self.assertEqual(outcomes['unresolved'],[0,3])
            self.assertEqual(report['observed_outcomes'],717)
            rows = read_jsonl(output/'outcomes.jsonl')
            rows[0]['false_retry_permission'] = not rows[0]['false_retry_permission']
            write_jsonl(output/'outcomes.jsonl',rows)
            with self.assertRaisesRegex(ValueError,'observed scoring replay mismatch'):
                analyze_amended(protocol,output)

    def test_all_stop_is_not_mistaken_for_successful_terminal_recovery(self):
        with tempfile.TemporaryDirectory() as directory:
            protocol, output = Path(directory) / 'protocol', Path(directory) / 'run'
            prepare(protocol, 'contract-wording')
            with patch('retrybench.current_models.OpenAIResponsesPolicy', side_effect=all_stop_policy):
                run(protocol, output, 20)
            report = analyze(protocol, output)
            self.assertEqual(report['fresh_calls'], 432)
            self.assertEqual(report['scored_outcomes'], 720)
            for arm in report['arms'].values():
                self.assertEqual(arm['common_forbidden']['false_retry_permission'], 0)
                self.assertEqual(arm['outcomes']['omissions'], 48)
            authoritative = report['arms']['authoritative_canonical']
            self.assertEqual(authoritative['authoritative_terminal_responses'], 48)
            self.assertEqual(authoritative['authoritative_terminal_correct_retries'], 0)
            self.assertEqual(authoritative['state_responses']['not_executed']['outcomes']['omissions'], 48)
            path = output / 'outcomes.jsonl'
            path.write_text('\n'.join(path.read_text().splitlines()[:-1]) + '\n')
            with self.assertRaisesRegex(ValueError, 'scored outcomes differ'):
                analyze(protocol, output)


if __name__ == '__main__':
    unittest.main()
