"""Ensure the comparison retains both arms, missingness, and literal evidence."""
import json
from pathlib import Path
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from analyze_rationale_comparison import lexical_matches, load_explanations


class RationaleComparisonTests(unittest.TestCase):
    def test_full_arms_preserve_exact_text_and_unknown_case(self):
        rows, _ = load_explanations()
        requests = {r['case_id']: r for r in map(json.loads, (ROOT / 'runs/historical-counterbalance-v1/shards/gpt-5.6-sol/requests.jsonl').read_text().splitlines())}
        self.assertEqual(len(rows), 256)
        self.assertEqual(len({r['case_id'] for r in rows}), 256)
        self.assertEqual(sum(r['rationale'] is not None for r in rows), 255)
        self.assertEqual(sum(r['group'] == 'labeled/deferral' for r in rows), 127)
        self.assertEqual(sum(r['group'] == 'unlabeled/deferral' for r in rows), 101)
        self.assertEqual(sum(r['group'] == 'unlabeled/retry' for r in rows), 27)
        for row in rows:
            source = requests[row['case_id']]
            if source['status'] != 'complete':
                self.assertIsNone(row['rationale'])
                self.assertIsNone(row['lexical_matches'])
                continue
            self.assertEqual(row['rationale'], source['decision']['rationale'])
            for matches in row['lexical_matches'].values():
                for match in matches:
                    self.assertEqual(row['rationale'][match['start']:match['end']], match['text'])

    def test_literal_indicators_do_not_claim_semantic_polarity(self):
        text = 'WEAK contract; not authoritative. No duplication is possible, although the state is uncertain.'
        matches = lexical_matches(text)
        for key in ('weak_word', 'contract_word', 'non_authoritative_phrase', 'duplicate_or_twice', 'uncertainty_word'):
            self.assertTrue(matches[key], key)
        # Negated duplication is still a vocabulary match, not an inference of risk.
        self.assertEqual(matches['duplicate_or_twice'][0]['text'], 'duplication')
        self.assertEqual(matches['stale_word'], [])
        self.assertEqual(lexical_matches('weakness')['weak_word'], [])


if __name__ == '__main__':
    unittest.main()
