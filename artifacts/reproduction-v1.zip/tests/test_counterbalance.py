import importlib.util
import unittest
from collections import Counter
from pathlib import Path
from retrybench.serialization import read_jsonl

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('cb',ROOT/'scripts/counterbalance_study.py')
cb=importlib.util.module_from_spec(spec);spec.loader.exec_module(cb)

class CounterbalanceDesignTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.cases=cb.build_manifest()
    def test_exact_anchor_and_only_label_deletion(self):
        old={c['task_id']:c for c in read_jsonl(ROOT/'protocol/historical-bridge-v1/manifest.jsonl') if c['evidence']=='weak'}
        pairs={}
        for c in self.cases:
            key=(c['requested_model'],c['task_id'],c['representation'],c['mapping_rotation'],c['order_rotation'],c['repetition'])
            pairs.setdefault(key,{})[c['label']]=c
            if c['label']=='labeled' and c['representation']=='canonical' and c['order_rotation']==0:
                self.assertEqual(c['prompt'],old[c['task_id']]['prompt'])
                self.assertEqual(c['instructions'],old[c['task_id']]['instructions'])
        for pair in pairs.values():
            self.assertEqual(pair['labeled']['prompt'].replace('Evidence contract: weak.\n',''),pair['unlabeled']['prompt'])
    def test_independently_balanced_tokens_and_positions(self):
        self.assertEqual(len(self.cases),1920)
        self.assertEqual(len({c['case_id'] for c in self.cases}),1920)
        for model in cb.MODELS:
            cells=[c for c in self.cases if c['requested_model']==model]
            self.assertEqual(len(cells),320)
            for label in ('labeled','unlabeled'):
                coded=[c for c in cells if c['label']==label and c['representation']=='coded']
                for action in cb.ACTIONS:
                    pairs=Counter((next(t for t,a in c['token_to_action'].items() if a==action),c['allowed_actions'].index(next(t for t,a in c['token_to_action'].items() if a==action))) for c in coded)
                    self.assertEqual(len(pairs),16)
                    self.assertEqual(set(pairs.values()),{8})
    def test_schema_and_semantic_decode_match_every_format(self):
        f=cb.helper()
        for c in self.cases:
            payload=f.payload(c)
            self.assertEqual(payload['text']['format']['schema']['properties']['action']['enum'],c['allowed_actions'])
            self.assertEqual(set(c['token_to_action'].values()),set(cb.ACTIONS))
            self.assertEqual(payload['max_output_tokens'],256)
            self.assertEqual(payload['reasoning']['effort'],'low' if c['requested_model']=='gpt-6-astra' else 'none')
            self.assertFalse(payload['store'])
            self.assertNotIn('schedules',payload)
            for token in c['allowed_actions']:
                import json
                raw={'id':'synthetic','status':'completed','model':c['requested_model'],'usage':{'input_tokens':10,'output_tokens':10},'output':[{'content':[{'type':'output_text','text':json.dumps({'action':token,'rationale':'Synthetic fixture'})}]}]}
                decoded=f.decode(c,raw)
                self.assertEqual(c['token_to_action'][decoded['decision']['action']],c['token_to_action'][token])

if __name__=='__main__':unittest.main()
