"""Pre-collection invariants for the supplied-key and canonical extension."""
import copy,json,sys,unittest,tempfile,fcntl
from unittest.mock import patch
from collections import Counter
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
import tier_a_study as study

class TierATests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.cases=study.build_manifest()
    def case(self,state='present'):
        return next(c for c in self.cases if c['block']=='supplied_key' and c['original_key_state']==state)
    def test_design_and_exact_canonical_transcripts(self):
        self.assertEqual(Counter(c['block'] for c in self.cases),{'canonical':1536,'supplied_key':240})
        self.assertEqual(len({c['case_id'] for c in self.cases}),1776)
        old=[json.loads(x) for x in (ROOT/'protocol/historical-counterbalance-v1/manifest.jsonl').read_text().splitlines()]
        transcripts={(c['requested_model'],c['task_id'],c['label'],c['order_rotation']):c['transcript_sha256'] for c in old if c['representation']=='canonical'}
        for c in self.cases:
            if c['block']=='canonical':self.assertEqual(c['transcript_sha256'],transcripts[c['requested_model'],c['task_id'],c['label'],c['order_rotation']])
            else:
                self.assertNotIn('Candidate key',c['prompt']);self.assertNotIn('displayed candidate',c['prompt'])
                self.assertEqual(c['semantics'],'stated')
    def test_exact_key_identity_controls_replay(self):
        for state in ('present','omitted'):
            c=self.case(state)
            for key in ('key-A','key-B','Key-A','key-A '):
                rows=study.score(c,{'action':'retry_with_key','idempotency_key':key})
                safe=state=='present' and key=='key-A'
                self.assertEqual(sum(r['false_retry_permission'] for r in rows),0 if safe else 3)
                self.assertEqual(sum(r['duplicates'] for r in rows),0 if safe else 2)
                self.assertEqual(sum(r['resolved_exact_state'] for r in rows),3 if safe else 1)
    def test_bare_retry_and_deferral_horizons(self):
        c=self.case()
        for action,expected in [('retry',(3,2,0,0,1)),('wait',(0,0,1,3,0)),('unresolved',(0,0,1,3,0)),('stop',(0,0,1,0,2))]:
            rows=study.score(c,{'action':action,'idempotency_key':None})
            self.assertEqual(tuple(sum(r[k] for r in rows) for k in ('false_retry_permission','duplicates','omissions','unresolved','resolved_exact_state')),expected)
    def test_missing_keys_include_both_protected_and_unprotected(self):
        for state in ('present','omitted'):
            c=self.case(state);values={sum(r['false_retry_permission'] for r in study.score(c,d)) for d in study.possible_decisions(c)}
            self.assertEqual(values,{0,3})
            keyed=[d for d in study.possible_decisions(c) if d['action']=='retry_with_key']
            self.assertEqual(any(study.protected(c,d) for d in keyed),state=='present')
    def test_decode_invalid_cross_fields_and_retains_usage(self):
        c=self.case()
        def raw(d):return dict(id='fake',model=c['requested_model'],status='completed',usage={'input_tokens':100,'output_tokens':30},output=[{'content':[{'type':'output_text','text':json.dumps(d)}]}])
        for action,key,status in [('retry_with_key','key-A','complete'),('retry_with_key','different','complete'),('retry_with_key',None,'invalid_output'),('retry_with_key','','invalid_output'),('retry_with_key',' ','complete'),('wait','key-A','invalid_output'),('wait',None,'complete')]:
            result=study.decode(c,raw(dict(action=action,idempotency_key=key,rationale='test')))
            self.assertEqual(result['status'],status);self.assertIn('cost_usd',result)
            if status=='invalid_output':self.assertNotIn('decision',result)
        malformed=study.decode(c,raw(dict(action='wait',rationale='missing key field')))
        self.assertEqual(malformed['status'],'invalid_output');self.assertNotIn('decision',malformed)
        r=raw(dict(action='wait',idempotency_key=None,rationale='test'));r['status']='incomplete'
        self.assertEqual(study.decode(c,r)['status'],'incomplete')
    def test_second_process_lock_prevents_collection(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);private=root/'runs'/study.STUDY/'private';private.mkdir(parents=True)
            with (private/'collector.lock').open('a') as held:
                fcntl.flock(held,fcntl.LOCK_EX|fcntl.LOCK_NB)
                with patch.object(study,'ROOT',root),patch.object(study,'_collect') as collect:
                    with self.assertRaises(BlockingIOError):study.collect()
                    collect.assert_not_called()
    def test_payload_and_reservation(self):
        for c in self.cases:
            p=study.payload(c);self.assertFalse(p['store']);self.assertEqual(p['service_tier'],'default')
            self.assertEqual(p['max_output_tokens'],256)
            self.assertNotIn('temperature',p);self.assertNotIn('seed',p)
            self.assertGreater(study.reserve(c),256*study.RATES[c['requested_model']][2]/1e6)
            self.assertEqual('idempotency_key' in p['text']['format']['schema']['properties'],c['block']=='supplied_key')

if __name__=='__main__':unittest.main()
