"""Independent effect-count checks and provenance validation for collected follow-ups."""
import copy
import importlib.util
import json
import tempfile
import unittest
from collections import Counter
from pathlib import Path
from retrybench.serialization import read_jsonl, read_json_object

ROOT=Path(__file__).resolve().parents[1]

def script(name):
    spec=importlib.util.spec_from_file_location(name,ROOT/'scripts'/(name+'.py'))
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module

class FollowupReportingTests(unittest.TestCase):
    def test_all_observed_outcomes_match_independent_effect_count_equations(self):
        # No simulator/scorer call: derive effects from the original schedule,
        # response action and whether the original/candidate keys actually match.
        for study in ('historical-bridge-v1','label-protection-v1'):
            manifest={r['case_id']:r for r in read_jsonl(ROOT/'protocol'/study/'manifest.jsonl')}
            requests={r['case_id']:r for r in read_jsonl(ROOT/'runs'/study/'requests.jsonl')}
            outcomes=read_jsonl(ROOT/'runs'/study/'outcomes.jsonl')
            self.assertEqual(len(outcomes),sum(len(c['schedules']) for c in manifest.values()))
            self.assertEqual(len({(r['response_group_id'],r['schedule']) for r in outcomes}),len(outcomes))
            for row in outcomes:
                c=manifest[row['response_group_id']];action=requests[c['case_id']]['decision']['action']
                original=int(row['schedule']!='fail_before_execution')
                retry=action in ('retry','retry_with_key')
                protected=action=='retry_with_key' and c.get('protection')=='valid'
                effects=int(original or retry) if protected else original+int(retry)
                unresolved=action in ('wait','unresolved')
                permitted=protected or (c['evidence']=='authoritative' and c['observed_state']=='not_executed')
                expected={'effect_count':effects,'duplicates':int(effects>1),'omissions':int(effects==0),'unresolved':int(unresolved),'ledger_correct':int(effects==1),'resolved_exact_state':int(effects==1 and not unresolved),'false_retry_permission':int(retry and not permitted),'protected_recovery':int(protected and effects==1 and not unresolved)}
                self.assertEqual(row['action'],action)
                for metric,value in expected.items():
                    with self.subTest(study=study,case=c['case_id'],world=row['schedule'],metric=metric):self.assertEqual(row[metric],value)
            report=read_json_object(ROOT/'runs'/study/'report.json')
            for condition,cell in report['conditions'].items():
                rs=[r for r in outcomes if r['condition']==condition]
                cases=[c for c in manifest.values() if c['condition']==condition]
                self.assertEqual(cell['actions'],dict(Counter(requests[c['case_id']]['decision']['action'] for c in cases)))
                for metric in cell['outcomes']:self.assertEqual(cell['outcomes'][metric],sum(r[metric] for r in rs))
            rates=read_json_object(ROOT/'protocol'/study/'protocol.json')['rates_per_million']
            costs=[]
            for id,r in requests.items():
                i,ca,o=rates[manifest[id]['requested_model']];u=r['usage']
                cost=((u['input_tokens']-u['cached_input_tokens'])*i+u['cached_input_tokens']*ca+u['output_tokens']*o)/1e6
                self.assertAlmostEqual(cost,r['cost_usd']);costs.append(cost)
            self.assertAlmostEqual(sum(costs),report['known_cost_usd'])

    def test_rationale_adjudication_regenerates_and_rejects_invalid_evidence(self):
        analyzer=script('analyze_rationales');report,rows=analyzer.analyze(ROOT)
        self.assertEqual(report,read_json_object(ROOT/'runs/rationale-coding-v1/report.json'))
        self.assertEqual(rows,read_jsonl(ROOT/'runs/rationale-coding-v1/adjudicated.jsonl'))
        import shutil
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            for base in ('protocol','runs'):
                shutil.copytree(ROOT/base/'rationale-coding-v1',root/base/'rationale-coding-v1')
            path=root/'runs/rationale-coding-v1/coder-a.jsonl'
            labels=read_jsonl(path);labels[0]['evidence'][labels[0]['codes'][0]]='FABRICATED EXACT QUOTATION'
            path.write_text('\n'.join(json.dumps(r) for r in labels)+'\n')
            with self.assertRaisesRegex(ValueError,'exact span'):analyzer.analyze(root)

if __name__=='__main__':unittest.main()
