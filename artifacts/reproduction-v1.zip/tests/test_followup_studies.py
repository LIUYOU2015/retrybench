import json,runpy,unittest
from pathlib import Path
from retrybench.serialization import read_jsonl
ROOT=Path(__file__).resolve().parents[1]
f=runpy.run_path(str(ROOT/'scripts/followup_studies.py'))

class FollowupStudyTests(unittest.TestCase):
    def test_bridge_matches_archived_transcripts_and_crossed_conditions(self):
        cases=f['build_bridge']();old=read_jsonl(ROOT/'protocol/confirmation-v2-manifest.jsonl')
        self.assertEqual(len(cases),320)
        self.assertEqual(len({c['case_id'] for c in cases}),320)
        lookup={r['response_group_id']:r for r in old}
        for c in cases:
            r=lookup[c['historical_response_group_id']]
            for k in ('instructions','prompt','transcript_sha256'):self.assertEqual(c[k],r[k])
            self.assertEqual(c['max_output_tokens'],256)
            self.assertEqual(f['payload'](c)['text']['format']['schema']['properties']['action']['enum'],['retry','stop','wait','unresolved'])
        for m,e in { (c['requested_model'],c['reasoning_effort']) for c in cases }:
            subset=[c for c in cases if (c['requested_model'],c['reasoning_effort'])==(m,e)]
            self.assertEqual(len(subset),80)
            self.assertEqual(sum(c['evidence']=='weak' for c in subset),20)
    def test_controls_label_removal_changes_only_one_line(self):
        cases=f['build_controls']();self.assertEqual(len(cases),720)
        groups={}
        for c in cases:groups.setdefault((c['requested_model'],c['task_id'],c['repetition'],c['semantics'],c['protection']),{})[c['label']]=c
        for pair in groups.values():
            self.assertEqual(pair['labeled']['prompt'].replace('Evidence contract: weak.\n',''),pair['unlabeled']['prompt'])
    def test_key_protection_is_executed_and_does_not_transfer_to_changed_key(self):
        cases=f['build_controls']()
        for protection in ('none','valid','changed'):
            c=next(c for c in cases if c['protection']==protection)
            rows=f['score'](c,'retry_with_key')
            self.assertEqual(sum(r['duplicates'] for r in rows),0 if protection=='valid' else 2)
            self.assertEqual(sum(r['false_retry_permission'] for r in rows),0 if protection=='valid' else 3)
            self.assertEqual(sum(r['protected_recovery'] for r in rows),3 if protection=='valid' else 0)
            self.assertEqual(sum(r['omissions'] for r in f['score'](c,'wait')),1)
            self.assertEqual(sum(r['resolved_exact_state'] for r in f['score'](c,'wait')),0)
            self.assertEqual(sum(r['duplicates'] for r in f['score'](c,'retry')),2)
    def test_incomplete_response_keeps_usage_but_no_action(self):
        c=f['build_bridge']()[0]
        response={'id':'synthetic-only','model':c['requested_model'],'status':'incomplete','usage':{'input_tokens':20,'output_tokens':256,'output_tokens_details':{'reasoning_tokens':256}},'output':[]}
        r=f['decode'](c,response)
        self.assertEqual(r['status'],'incomplete');self.assertGreater(r['cost_usd'],0);self.assertNotIn('decision',r)

if __name__=='__main__':unittest.main()
