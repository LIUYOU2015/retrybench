import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from retrybench.current_models import build_manifest, prepare, run, score_case
from retrybench.contract_wording import build_wording_manifest
from retrybench.openai_adapter import CostBudget, OpenAIResponseError, OpenAIResponsesPolicy


def fake_policy(**kwargs):
    def transport(api_key, payload):
        return {
            "id": "synthetic-test-only", "model": payload["model"], "status": "completed",
            "output": [{"content": [{"type": "output_text", "text": json.dumps({"action": "retry", "rationale": "test fixture"})}]}],
            "usage": {"input_tokens": 100, "output_tokens": 30},
        }
    return OpenAIResponsesPolicy(api_key="test-key", transport=transport, **kwargs)


class CurrentModelsTests(unittest.TestCase):
    def test_wording_control_balances_tokens_and_runs_offline(self):
        cases = build_wording_manifest()
        self.assertEqual(len(cases), 432)
        self.assertEqual(sum(len(c['schedules']) for c in cases), 720)
        for state in ('not_executed', 'in_flight', 'committed'):
            tokens = [c['visible_state'] for c in cases if c['task_id'] == cases[0]['task_id'] and c['prompt_mode'] == 'authoritative_permuted' and c['observed_state'] == state]
            self.assertEqual(sorted(tokens), ['S1', 'S2', 'S3'])
        with tempfile.TemporaryDirectory() as directory:
            protocol, output = Path(directory) / 'protocol', Path(directory) / 'run'
            prepared = prepare(protocol, 'contract-wording')
            self.assertLess(prepared['cost_upper_estimate_usd'], 20)
            with patch('retrybench.current_models.OpenAIResponsesPolicy', side_effect=fake_policy):
                run(protocol, output, 20)
            report = json.loads((output / 'analysis.json').read_text())
            self.assertEqual(report['fresh_calls'], 432)
            self.assertEqual(len(report['arm_contrasts']), 3)
            self.assertEqual(len(report['state_response_summaries']), 9)
            self.assertTrue(all(len(c['family_effects']) == 8 for c in report['arm_contrasts'].values()))

    def test_manifest_count_sharing_and_explicit_contracts(self):
        cases = build_manifest()
        self.assertEqual(len(cases), 768)
        self.assertEqual(len({c["case_id"] for c in cases}), 768)
        self.assertEqual(sum(len(c["schedules"]) for c in cases), 1152)
        for case in cases:
            self.assertEqual(case["reasoning_effort"], "low")
            self.assertEqual(len(case["schedules"]), 3 if case["evidence"] == "weak" else 1)
            if case["prompt_mode"] != "label_only":
                self.assertIn("no provider idempotency key", case["prompt"])
            for schedule in case["schedules"]:
                self.assertNotIn(schedule, case["prompt"])

    def test_shared_weak_retry_exposes_two_harms(self):
        case = next(c for c in build_manifest() if c["evidence"] == "weak")
        rows = score_case(case, {"action": "retry"})
        self.assertEqual(sum(r["duplicate_effect"] for r in rows), 2)
        self.assertEqual(sum(r["false_retry_permission"] for r in rows), 3)

    def test_complete_fake_run_and_resume_do_not_duplicate_calls(self):
        with tempfile.TemporaryDirectory() as directory:
            protocol, output = Path(directory) / "protocol", Path(directory) / "run"
            prepare(protocol)
            with patch("retrybench.current_models.OpenAIResponsesPolicy", side_effect=fake_policy):
                run(protocol, output, 10.0)
                first = (output / "requests.jsonl").read_bytes()
                run(protocol, output, 10.0)
                self.assertEqual(first, (output / "requests.jsonl").read_bytes())
            report = json.loads((output / "analysis.json").read_text())
            self.assertTrue(report["complete"])
            self.assertEqual(report["fresh_calls"], 768)
            self.assertEqual(len(report["family_contrasts"]), 6)
            self.assertTrue(all(len(x["families"]) == 8 for x in report["family_contrasts"].values()))
            self.assertNotIn("synthetic-test-only", (output / "requests.jsonl").read_text())
            self.assertIn("synthetic-test-only", (output / "private/requests.jsonl").read_text())

    def test_interrupted_request_refuses_paid_retry(self):
        with tempfile.TemporaryDirectory() as directory:
            protocol, output = Path(directory) / "protocol", Path(directory) / "run"
            prepare(protocol)
            output.mkdir()
            (output / "private").mkdir()
            (output / "private/pending-request.json").write_text('{}')
            with patch("retrybench.current_models.OpenAIResponsesPolicy", side_effect=fake_policy):
                with self.assertRaisesRegex(ValueError, "interrupted request"):
                    run(protocol, output, 1.0)

    def test_resume_rejects_protocol_or_implementation_drift(self):
        with tempfile.TemporaryDirectory() as directory:
            protocol, output = Path(directory) / "protocol", Path(directory) / "run"
            prepare(protocol, "contract-wording")
            with patch("retrybench.current_models.OpenAIResponsesPolicy", side_effect=fake_policy):
                run(protocol, output, 20)
            protocol_path = protocol / "protocol.json"
            original = protocol_path.read_text()
            changed = json.loads(original)
            changed["primary_analysis"] = "changed after collection"
            protocol_path.write_text(json.dumps(changed))
            with patch("retrybench.current_models.OpenAIResponsesPolicy") as policy:
                with self.assertRaisesRegex(ValueError, "provenance mismatch"):
                    run(protocol, output, 20)
                policy.assert_not_called()
            protocol_path.write_text(original)
            journal = output / "private/requests.jsonl"
            original_journal = journal.read_text()
            records = [json.loads(line) for line in original_journal.splitlines()]
            for incorrect_hash in (None, "different collection"):
                if incorrect_hash is None:
                    records[0].pop("collection_provenance_sha256")
                else:
                    records[0]["collection_provenance_sha256"] = incorrect_hash
                journal.write_text("".join(json.dumps(r) + "\n" for r in records))
                with patch("retrybench.current_models.OpenAIResponsesPolicy") as policy:
                    with self.assertRaisesRegex(ValueError, "request collection provenance mismatch"):
                        run(protocol, output, 20)
                    policy.assert_not_called()
            journal.write_text(original_journal)
            provenance_path = output / "collection-provenance.json"
            provenance = json.loads(provenance_path.read_text())
            provenance["source_sha256"]["scoring.py"] = "different implementation"
            provenance_path.write_text(json.dumps(provenance))
            with patch("retrybench.current_models.OpenAIResponsesPolicy") as policy:
                with self.assertRaisesRegex(ValueError, "provenance mismatch"):
                    run(protocol, output, 20)
                policy.assert_not_called()

    def test_gpt6_rejects_historical_none_reasoning(self):
        with self.assertRaisesRegex(ValueError, "low or higher"):
            OpenAIResponsesPolicy(model="gpt-6-astra", reasoning_effort="none", api_key="test-key")

    def test_strict_collection_rejects_incomplete_or_missing_provenance(self):
        for mutation in ("incomplete", "usage", "model", "id"):
            def transport(api_key, payload):
                response = {
                    "id": "response-test", "model": payload["model"], "status": "completed",
                    "usage": {"input_tokens": 100, "output_tokens": 30},
                    "output": [{"content": [{"type": "output_text", "text": '{"action":"retry","rationale":"test"}'}]}],
                }
                if mutation == "incomplete":
                    response["status"] = "incomplete"
                else:
                    response.pop(mutation)
                return response
            policy = OpenAIResponsesPolicy(model="gpt-6-astra", reasoning_effort="low", api_key="test-key", transport=transport, strict_response_metadata=True)
            budget = CostBudget(1.0)
            with self.subTest(mutation=mutation), self.assertRaises(OpenAIResponseError):
                policy.decide_text("test", "test", budget)
            if mutation == "incomplete":
                self.assertGreater(budget.spent_usd, 0)
            self.assertIsNotNone(policy.last_response_metadata)

    def test_nonfinite_spending_cap_is_rejected(self):
        for cap in (float('nan'), float('inf'), -1, 0):
            with self.subTest(cap=cap), self.assertRaises(ValueError):
                CostBudget(cap)


if __name__ == "__main__":
    unittest.main()
