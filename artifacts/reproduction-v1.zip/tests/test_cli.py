import contextlib
import io
import json
import tempfile
import unittest
from pathlib import Path

from retrybench.cli import _require_paid_run, main


class CLITests(unittest.TestCase):
    def test_deterministic_run_writes_requested_outputs(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            outcomes = root / "outcomes.jsonl"
            summary = root / "summary.json"
            stdout = io.StringIO()
            with contextlib.redirect_stdout(stdout):
                exit_code = main(
                    [
                        "run",
                        "--output",
                        str(outcomes),
                        "--summary",
                        str(summary),
                        "--policies",
                        "always_stop",
                        "--evidence",
                        "weak",
                        "--schedules",
                        "fail_before_execution",
                    ]
                )

            self.assertEqual(exit_code, 0)
            self.assertEqual(len(outcomes.read_text().splitlines()), 4)
            report = json.loads(summary.read_text(encoding="utf-8"))
            self.assertEqual(report["overall"]["episodes"], 4)
            self.assertEqual(json.loads(stdout.getvalue()), report)

    def test_paid_run_requires_explicit_enable_flag(self):
        with self.assertRaisesRegex(SystemExit, "--execute-paid-test"):
            _require_paid_run(False, "--execute-paid-test", 0.5, 1.0)


if __name__ == "__main__":
    unittest.main()
