import hashlib
import json
import tempfile
import unittest
from pathlib import Path

from retrybench.serialization import (
    canonical_json_sha256,
    read_json_object,
    read_jsonl,
    write_json,
    write_jsonl,
)


class SerializationTests(unittest.TestCase):
    def test_canonical_hash_is_key_order_independent(self):
        left = {"b": 2, "a": {"value": "✓"}}
        right = {"a": {"value": "✓"}, "b": 2}
        expected = hashlib.sha256(
            json.dumps(
                left,
                sort_keys=True,
                separators=(",", ":"),
                ensure_ascii=False,
            ).encode("utf-8")
        ).hexdigest()
        self.assertEqual(canonical_json_sha256(left), expected)
        self.assertEqual(canonical_json_sha256(right), expected)

    def test_json_and_jsonl_round_trip(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            object_path = root / "nested" / "value.json"
            rows_path = root / "nested" / "rows.jsonl"
            value = {"z": 1, "a": [1, 2]}
            rows = [{"id": 1}, {"id": 2}]

            write_json(object_path, value)
            write_jsonl(rows_path, rows)

            self.assertEqual(read_json_object(object_path), value)
            self.assertEqual(read_jsonl(rows_path), rows)
            self.assertTrue(object_path.read_bytes().endswith(b"\n"))
            self.assertTrue(rows_path.read_bytes().endswith(b"\n"))

    def test_readers_reject_non_object_values(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            object_path = root / "value.json"
            rows_path = root / "rows.jsonl"
            object_path.write_text("[]", encoding="utf-8")
            rows_path.write_text("[]\n", encoding="utf-8")

            with self.assertRaises(ValueError):
                read_json_object(object_path)
            with self.assertRaises(ValueError):
                read_jsonl(rows_path)


if __name__ == "__main__":
    unittest.main()
