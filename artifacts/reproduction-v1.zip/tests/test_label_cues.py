"""Frozen cue design and shared-world missingness validation without API calls."""
import sys,shutil,os,tempfile,unittest
from pathlib import Path
from collections import defaultdict,Counter
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
import label_cue_study as study
import analyze_label_cues as analysis
from retrybench.serialization import read_jsonl,read_json_object,write_json,write_jsonl,canonical_json_sha256

class LabelCueTests(unittest.TestCase):
    def test_only_label_changes_and_actions_are_balanced(self):
        cs=study.build_manifest();self.assertEqual(len(cs),768);self.assertEqual(len({c['case_id'] for c in cs}),768)
        pairs=defaultdict(list)
        for c in cs:
            self.assertEqual(c['reasoning_effort'],'none');self.assertEqual(c['max_output_tokens'],256)
            self.assertEqual(c['evidence'],'weak');self.assertIn(study.LOOKUP_CONTRACT,c['prompt'])
            key=(c['requested_model'],c['task_id'],c['order_rotation'],c['repetition'])
            pairs[key].append(c['prompt'].replace('Evidence contract: '+c['label']+'.\n',''))
        self.assertEqual(len(pairs),192)
        for prompts in pairs.values():self.assertEqual(len(set(prompts)),1)
        for model in study.MODELS:
            for label in ('none','weak','unverified','authoritative'):
                selected=[c for c in cs if c['requested_model']==model and c['label']==label]
                self.assertEqual(Counter(c['allowed_actions'].index('retry') for c in selected),{0:16,1:16,2:16,3:16})
    def test_missing_is_one_choice_and_invalid_complete_action_rejected(self):
        sid='label-cue-v1'
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);shutil.copytree(ROOT/'protocol'/sid,root/'protocol'/sid);shutil.copytree(ROOT/'runs'/sid/'collection-code',root/'runs'/sid/'collection-code')
            p=read_json_object(root/'protocol'/sid/'protocol.json');cs=read_jsonl(root/'protocol'/sid/'manifest.jsonl');ph=canonical_json_sha256(p);missing=cs[0]
            for model in p['models']:
                rows=[]
                for c in cs:
                    if c['requested_model']!=model:continue
                    r=dict(case_id=c['case_id'],protocol_sha256=ph,collected_at_utc=p['recorded_at_utc'])
                    if c['case_id']==missing['case_id']:r.update(status='transport_timeout',unknown_cost_upper_reserve_usd=.01)
                    else:r.update(status='complete',provider_status='completed',returned_model=model,selected_token='unresolved',decision={'action':'unresolved','rationale':'Synthetic fixture'},cost_usd=0,usage={'input_tokens':0,'cached_input_tokens':0,'output_tokens':0,'reasoning_tokens':0})
                    rows.append(r)
                dest=root/'runs'/sid/'shards'/model;dest.mkdir(parents=True)
                write_jsonl(dest/'requests.jsonl',rows);m=sum(r['status']!='complete' for r in rows)
                write_json(dest/'summary.json',dict(protocol_sha256=ph,model=model,planned=len(rows),attempted=len(rows),attempted_all=True,complete=len(rows)-m,missing=m,known_cost_usd=0,unknown_cost_upper_reserve_usd=.01 if m else 0))
            old=Path.cwd()
            try:
                os.chdir(root);r,_=analysis.analyze();self.assertEqual(r['observed_outcomes'],767*3);self.assertEqual(r['missing_responses'],1)
                v=r['groups'][missing['requested_model']+'/'+missing['label']];self.assertEqual(v['rate_bounds'],[0,1/64])
                dest=root/'runs'/sid/'shards'/p['models'][0]/'requests.jsonl';rows=read_jsonl(dest);next(r for r in rows if r['status']=='complete')['selected_token']='invalid';write_jsonl(dest,rows)
                with self.assertRaisesRegex(ValueError,'invalid complete action'):analysis.analyze()
            finally:os.chdir(old)
if __name__=='__main__':unittest.main()
