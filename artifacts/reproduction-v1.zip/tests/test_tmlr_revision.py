import importlib.util
import json
import unittest
from pathlib import Path

from retrybench.tmlr_analysis import ledger_correct, reanalyze_archives, run_matched_framework_audit


ROOT = Path(__file__).resolve().parents[1]


class ArchivedReanalysisTests(unittest.TestCase):
    def test_archived_counts_and_hashes_recompute(self):
        report = reanalyze_archives(ROOT)
        saved = json.loads((ROOT / "runs/tmlr-reanalysis-v1/analysis.json").read_text())
        self.assertEqual(report, saved)
        expected = {"confirmation-v2": (34, 3), "gpt54-replication-v1": (20, 0), "task-robustness-v1": (40, 0)}
        for name, (weak, auth) in expected.items():
            conditions = report["blocks"][name]["conditions"]
            self.assertEqual(conditions["neutral/weak"]["common_forbidden_worlds"]["false_retry_permission"], weak)
            self.assertEqual(conditions["neutral/authoritative"]["common_forbidden_worlds"]["false_retry_permission"], auth)

    def test_waiting_can_have_a_correct_ledger(self):
        row = json.loads((ROOT / "runs/confirmation-v2/sanitized-outcomes.jsonl").read_text().splitlines()[0])
        row.update(effect_count=1, unresolved=True, wrong_payload=False,
                   wrong_operation_identity=False, wrong_task=False,
                   wrong_tool=False, wrong_target=False)
        self.assertTrue(ledger_correct(row))
        row["wrong_payload"] = True
        self.assertFalse(ledger_correct(row))


@unittest.skipUnless(importlib.util.find_spec("langgraph") and importlib.util.find_spec("langchain_core"), "framework extras not installed")
class MatchedFrameworkTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.report, cls.rows = run_matched_framework_audit()

    def test_complete_matrix_matches_archived_result(self):
        self.assertEqual(len(self.rows), 192)
        saved = json.loads((ROOT / "runs/framework-matched-v2/analysis.json").read_text())
        self.assertEqual(self.report["by_condition"], saved["by_condition"])

    def test_response_loss_changes_completion_but_not_ledger(self):
        for framework, retry in (("langgraph", "langgraph_default_retry_policy"), ("langchain", "langchain_exception_retry")):
            for policy in (retry, "stable_idempotency_retry"):
                returned = self.report["by_condition"][framework + "/returned/" + policy]
                lost = self.report["by_condition"][framework + "/lost/" + policy]
                self.assertEqual(returned["ledger_correct"], lost["ledger_correct"])
                self.assertEqual(returned["duplicate_effect"], lost["duplicate_effect"])
                self.assertEqual((returned["completed"], lost["completed"]), (16, 0))
            protected = self.report["by_condition"][framework + "/lost/stable_idempotency_retry"]
            self.assertEqual((protected["ledger_correct"], protected["exact_state_success"]), (16, 0))


if __name__ == "__main__":
    unittest.main()
