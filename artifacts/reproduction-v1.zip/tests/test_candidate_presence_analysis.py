import json,sys,tempfile,shutil,importlib.util,unittest
from unittest.mock import patch
from pathlib import Path
repo=Path(__file__).resolve().parents[1];sys.path.insert(0,str(repo/'scripts'));sys.path.insert(0,str(repo/'src'))
import analyze_candidate_presence as a
import candidate_presence_study as collector
from retrybench.serialization import canonical_json_sha256,write_json,write_jsonl,read_json_object,read_jsonl

class CandidateAnalysisTests(unittest.TestCase):
 def test_offline_full_pipeline_and_unknown_key_bounds(self):
  with tempfile.TemporaryDirectory(prefix='candidate-offline-fixture-') as td, patch.object(a,'ROOT',Path(td)):
   root=Path(td);pd=root/'protocol/candidate-presence-v1';rd=root/'runs/candidate-presence-v1';pd.mkdir(parents=True);rd.mkdir(parents=True)
   cases=collector.build_manifest()
   code_names=['candidate_presence_study.py','analyze_candidate_presence.py','followup_studies.py','counterbalance_study.py','contrast_inference.py','response_intervals.py']
   import hashlib
   digest=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
   p=dict(manifest_sha256=canonical_json_sha256(cases),recorded_at_utc='2000-01-01',models=collector.MODELS,rates_per_million=collector.RATES,cap_usd=1,collection_code_sha256={name:digest(repo/'scripts'/name) for name in code_names},source_sha256={p.name:digest(p) for p in (repo/'src/retrybench').glob('*.py')})
   write_json(pd/'protocol.json',p);write_jsonl(pd/'manifest.jsonl',cases)
   (rd/'collection-code').mkdir()
   for name in code_names:shutil.copyfile(repo/'scripts'/name,rd/'collection-code'/name)
   (root/'scripts').mkdir()
   for name in ('contrast_inference.py','response_intervals.py'):shutil.copyfile(repo/'scripts'/name,root/'scripts'/name)
   p=read_json_object(pd/'protocol.json');cases=read_jsonl(pd/'manifest.jsonl');ph=canonical_json_sha256(p)
   records=[]
   for c in cases:
    d={'action':'wait','rationale':'OFFLINE FIXTURE, NOT MODEL EVIDENCE'}
    if c['block']=='supplied_key':d['idempotency_key']=None
    records.append(dict(case_id=c['case_id'],requested_model=c['requested_model'],protocol_sha256=ph,collected_at_utc=p['recorded_at_utc'],status='complete',provider_status='completed',returned_model=c['requested_model'],decision=d,usage={'input_tokens':0,'output_tokens':0,'cached_input_tokens':0,'reasoning_tokens':0},cost_usd=0))
   write_jsonl(rd/'requests.jsonl',records);write_json(rd/'collection-summary.json',dict(protocol_sha256=ph,attempted=len(records),planned=len(records),complete=len(records),attempted_all=True,known_cost_usd=0,unknown_cost_upper_reserve_usd=0))
   a.ROOT=root;r,rows=a.analyze()
   assert len(rows)==720 and r['observed_responses']==240 and r['missing_responses']==0
   assert all(g['outcomes']['unresolved']==3*g['planned_responses'] for g in r['groups'].values())
   assert all(g['terminal_progress']==0 for g in r['groups'].values())
   assert all(c['holm_worst_case_conditional_p']==1 for c in r['candidate_contrasts'].values())
   # One missing original-present key response spans protected and unprotected outcomes.
   idx=next(i for i,c in enumerate(cases) if c['block']=='supplied_key' and c['original_key_state']=='present')
   records[idx].pop('decision');records[idx]['status']='invalid_output';write_jsonl(rd/'requests.jsonl',records)
   summary=read_json_object(rd/'collection-summary.json');summary['complete']-=1;write_json(rd/'collection-summary.json',summary)
   r,rows=a.analyze();g=r['groups'][cases[idx]['condition']]
   assert g['outcome_bounds']['false_retry_permission']==[0,3]
   assert g['outcome_bounds']['protected_recovery']==[0,3]
   assert g['terminal_progress_bounds']==[0,1]


if __name__=='__main__':unittest.main()
