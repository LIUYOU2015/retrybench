import importlib.util,math,unittest
from pathlib import Path
spec=importlib.util.spec_from_file_location('ri',Path(__file__).resolve().parents[1]/'scripts/response_intervals.py');ri=importlib.util.module_from_spec(spec);spec.loader.exec_module(ri)
class ExactReferenceIntervalTests(unittest.TestCase):
    def test_zero_and_full_count_closed_forms(self):
        for n in (2,5,8,20,32,80,128,320):
            zero=ri.exact_interval(0,n);full=ri.exact_interval(n,n)
            self.assertEqual(zero[0],0)
            self.assertAlmostEqual(zero[1],1-.025**(1/n),places=12)
            self.assertAlmostEqual(full[0],.025**(1/n),places=12)
            self.assertEqual(full[1],1)
        self.assertAlmostEqual(ri.exact_interval(0,80)[1],.0450640350676923)
    def test_nist_published_reference_example(self):
        lo,hi=ri.exact_interval(8,30)
        self.assertAlmostEqual(lo,.122795,places=6)
        self.assertAlmostEqual(hi,.458894,places=6)
    def test_interior_inverts_both_binomial_tails(self):
        for k,n in ((1,80),(10,20),(55,80),(60,80),(78,80)):
            lo,hi=ri.exact_interval(k,n)
            self.assertAlmostEqual(1-ri.cdf(k-1,n,lo),.025,places=10)
            self.assertAlmostEqual(ri.cdf(k,n,hi),.025,places=10)
    def test_missing_envelope_and_sign_test_resolution(self):
        self.assertEqual(ri.summary(0,20,2)['rate_bounds'],[0,.1])
        self.assertEqual(ri.summary(0,20,2)['cp95_reference_envelope'],[ri.exact_interval(0,20)[0],ri.exact_interval(2,20)[1]])
        self.assertEqual(ri.sign_diagnostic([1,1,1,1])['two_sided_p'],.125)
        self.assertEqual(ri.sign_diagnostic([1,1,0,0])['two_sided_p'],.5)
        self.assertEqual(ri.sign_diagnostic([0,0,0,0])['ties'],4)
if __name__=='__main__':unittest.main()
