import sys,unittest,math
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from contrast_inference import mover,mover_p,wilson,conditional_p,analyze_terms,holm

class ContrastInferenceTests(unittest.TestCase):
    def test_wilson_boundary_and_two_sample_symmetry(self):
        z=1.959963984540054
        self.assertAlmostEqual(wilson(0,80)[1],z*z/(80+z*z),places=12)
        estimate,ci=mover([(1,20,32),(-1,25,32)])
        self.assertAlmostEqual(estimate,-5/32)
        self.assertTrue(-.361<ci[0]<-.359 and .066<ci[1]<.068)
        _,mirror=mover([(1,25,32),(-1,20,32)])
        self.assertAlmostEqual(ci[0],-mirror[1]);self.assertAlmostEqual(ci[1],-mirror[0])
    def test_conditional_convolution_known_single_and_two_strata(self):
        # All three events assigned to arm1: two-sided probability2/C(6,3).
        self.assertAlmostEqual(conditional_p(((3,3,0,3),)),.1)
        self.assertAlmostEqual(conditional_p(((3,3,0,3),(3,3,0,3))),.005)
        self.assertEqual(conditional_p(((0,3,0,3),)),1)
    def test_missing_envelope_contains_each_assignment(self):
        cases=[dict(case_id=str(i),task_id='t') for i in range(8)]
        arms=[(1,cases[:4]),(-1,cases[4:])];obs={str(i):int(i==0) for i in range(7)}
        result=analyze_terms(arms,obs,['task_id']);self.assertEqual(result['missing_assignments'],2)
        for action in (0,1):
            one=analyze_terms(arms,dict(obs,**{'7':action}),['task_id'])
            self.assertLessEqual(result['mover95_reference_envelope'][0],one['mover95_reference_envelope'][0])
            self.assertGreaterEqual(result['mover95_reference_envelope'][1],one['mover95_reference_envelope'][1])
            self.assertLessEqual(result['conditional_p_bounds'][0],one['conditional_p_bounds'][0])
            self.assertGreaterEqual(result['conditional_p_bounds'][1],one['conditional_p_bounds'][1])
    def test_interaction_test_matches_interval_inversion_and_rejects_overlap(self):
        terms=[(1,27,128),(-1,0,128),(-1,2,32),(1,0,32)]
        p=mover_p(terms);_,ci=mover(terms,confidence=1-p)
        self.assertAlmostEqual(ci[0],0,places=10)
        with self.assertRaises(ValueError):analyze_terms([(1,[{'case_id':'a'}]),(-1,[{'case_id':'a'}])],{'a':0})
    def test_holm_stepdown(self):
        self.assertEqual(holm({'a':.01,'b':.04,'c':.03}),{'a':.03,'c':.06,'b':.06})

if __name__=='__main__':unittest.main()
