"""Verify frozen inputs, run offline tests, and regenerate 49 scientific outputs."""
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parent

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    manifest = json.loads((ROOT / 'FILE-HASHES.json').read_text())
    for name, expected in manifest.items():
        if digest(ROOT / name) != expected:
            raise RuntimeError('File checksum mismatch: ' + name)
    env = {k: v for k, v in os.environ.items()
           if not any(t in k.upper() for t in ('API_KEY', 'ACCESS_TOKEN', 'AUTH_TOKEN'))}
    env.update(PYTHONDONTWRITEBYTECODE='1', MPLBACKEND='Agg')
    commands = [['src', ['-m', 'unittest', 'discover', '-s', 'tests', '-v']]]
    commands += json.loads((ROOT / 'ANALYSIS-COMMANDS.json').read_text())
    logs = []
    test_count = 0
    for pythonpath, args in commands:
        env['PYTHONPATH'] = str(ROOT / pythonpath)
        print('Running: ' + ' '.join(args), flush=True)
        result = subprocess.run([sys.executable, *args], cwd=ROOT, env=env,
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        logs.append(result.stdout.replace(str(ROOT), '<artifact>'))
        (ROOT / 'verification.log').write_text('\n'.join(logs))
        if args[:2] == ['-m', 'unittest']:
            if '\nOK\n' not in result.stdout:
                raise RuntimeError('Tests must pass without skips: ' + result.stdout[-2000:])
            test_count = int(re.search(r'Ran (\d+) tests? in', result.stdout).group(1))
        if result.returncode:
            raise RuntimeError(result.stdout[-8000:])
    outputs = json.loads((ROOT / 'EXPECTED-OUTPUTS.json').read_text())
    changed = [n for n, h in outputs.items() if digest(ROOT / n) != h]
    if changed:
        raise RuntimeError('Outputs differ: ' + ', '.join(changed))
    report = dict(status='passed', files_checked=len(manifest),
                  byte_identical_outputs=len(outputs), python=sys.version,
                  commands=len(commands), tests_passed=test_count, test_skips=0, live_model_calls=0)
    (ROOT / 'verification.json').write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(report, indent=2))

if __name__ == '__main__':
    main()
